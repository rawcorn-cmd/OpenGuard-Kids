# 🛡️ HƯỚNG DẪN SỬ DỤNG CHI TIẾT — HỆ THỐNG OGK ENTERPRISE SUITE v2.0
**(Open Guardian Kid — Công Cụ Đồng Hành & Quản Lý Sử Dụng Máy Tính Trẻ Em)**

---

## 1. TỔNG QUAN HỆ THỐNG & CẤU TRÚC THƯ MỤC

**OGK Enterprise Suite v2.0** là hệ thống phần mềm thương mại hoàn chỉnh theo mô hình **Client–Server kết hợp Đồng bộ Thời gian thực**, được thiết kế theo triết lý **"Công cụ đồng hành minh bạch, không phải phần mềm theo dõi lén"** và tuân thủ **Nghị định 13/2023/NĐ-CP** về Bảo vệ dữ liệu cá nhân.

### Cấu trúc các tệp chính trong thư mục giải nén:
| Tên tệp / Thư mục | Chức năng chính | Quyền chạy khuyến nghị |
| :--- | :--- | :--- |
| **`0_TRUNG_TAM_DIEU_KHIEN.bat`** | **Bàn điều khiển trung tâm (Master Launcher)**: Mở giao diện quản lý tất cả thành phần chỉ từ 1 cửa sổ duy nhất. | Chuột phải -> **Run as administrator** |
| **`1_CHAY_SERVER.bat`** | Khởi động Máy chủ Trung tâm (`OGK-Server`) và Web Dashboard Phụ huynh tại cổng `8080`. | Chạy bình thường (User) |
| **`2_GHEP_DOI_AGENT.bat`** | Công cụ ghép đôi máy tính của trẻ với tài khoản phụ huynh bằng mã 8 ký tự. | Chạy bình thường (User) |
| **`3_CHAY_AGENT_SERVICE.bat`** | Dịch vụ bảo vệ nền (`OGK-Agent`): Chạy DNS Proxy cổng `53`, IPC cổng `58000`, quét tiến trình SHA-256, đếm giờ và cưỡng chế hạn mức. | Chuột phải -> **Run as administrator** |
| **`4_CHAY_TRAY_UI.bat`** | Giao diện Bạn Đồng Hành Gấu Nhỏ (`Child Tray UI`) cho bé: Đồng bộ ngầm `1.5s`, xem giờ còn lại, xin thêm giờ, báo chặn nhầm, làm nhiệm vụ. | Chạy bình thường (User) |
| **`KHOI_PHUC_MANG_GOC.bat`** | **Cứu hộ mạng 1-Click**: Trả DNS card mạng Windows về DHCP tự động, dọn sạch các dòng chặn trong file `hosts` và xóa cache DNS (`ipconfig /flushdns`). | Chuột phải -> **Run as administrator** |
| **`tools_dns_tester/`** | Bộ công cụ **DNS Proxy Tester độc lập** có giao diện Windows riêng để kiểm thử nhanh tính năng bắt gói tin DNS cổng 53 và chặn trang web. | Chuột phải vào `CHAY_DNS_PROXY_ADMIN.bat` -> **Run as administrator** |
| **`verify_real_world.py`** | Kịch bản kiểm thử tự động 29/29 tiêu chí kỹ thuật và thương mại của đồ án. | `python verify_real_world.py` |

---

## 2. YÊU CẦU HỆ THỐNG & CHUẨN BỊ

1. **Hệ điều hành**: Windows 10 / Windows 11 (64-bit).
2. **Python**: Đã cài đặt **Python 3.10 trở lên** (khi cài Python nhớ tích chọn **"Add Python to PATH"**).
3. **Tự động cài đặt thư viện**: Khi bạn chạy `1_CHAY_SERVER.bat` lần đầu tiên, hệ thống sẽ tự động tạo môi trường ảo (`venv`) và cài đặt đầy đủ các thư viện cần thiết (`fastapi`, `uvicorn`, `requests`, `psutil`, `pystray`, `Pillow`, `jinja2`...).
4. **Chế độ An toàn Kiểm thử (Safe Mode)**:
   * Mặc định hệ thống đang bật **`SAFE_DEMO_MODE = True`** để khi bạn test tính năng "Khóa màn hình" trên máy tính cá nhân của mình, máy chỉ hiện thông báo/âm thanh mô phỏng chứ **không khóa cứng màn hình Windows thật** (`LockWorkStation`), giúp bạn dễ dàng thao tác khi thuyết trình và chấm đồ án.

---

## 3. HƯỚNG DẪN KHỞI ĐỘNG HỆ THỐNG (2 CÁCH)

### Cách 1: Khởi động nhanh qua Trung tâm Điều khiển (Khuyên dùng)
1. Nhấp chuột phải vào file **`0_TRUNG_TAM_DIEU_KHIEN.bat`** -> Chọn **Run as administrator** (Chạy với quyền Quản trị viên).
2. Cửa sổ **OGK Enterprise Suite - Trung Tâm Điều Khiển Tổng Hợp** sẽ hiện ra (hỗ trợ kéo giãn kích thước tự do).
3. Nhấn lần lượt các nút trên giao diện:
   * **Bước 1**: Nhấn **`▶ Khởi Động Server & Mở Web`** -> Đợi khoảng 2–3 giây để Server khởi tạo Database và tự động mở trình duyệt tại `http://localhost:8080`.
   * **Bước 2**: Nhấn **`🛡️ Bật Dịch Vụ Bảo Vệ (Admin)`** để chạy Agent nền và DNS Proxy.
   * **Bước 3**: Nhấn **`🐻 Mở Giao Diện Cho Bé`** để mở ứng dụng Bạn Đồng Hành Gấu Nhỏ cho trẻ.

### Cách 2: Khởi động từng thành phần riêng lẻ
Nếu muốn quan sát log terminal của từng tiến trình riêng biệt:
1. Chạy **`1_CHAY_SERVER.bat`** (đợi dòng chữ `Uvicorn running on http://0.0.0.0:8080`).
2. Chuột phải vào **`3_CHAY_AGENT_SERVICE.bat`** -> chọn **Run as administrator**.
3. Chạy **`4_CHAY_TRAY_UI.bat`** để mở giao diện của bé.

---

## 4. THÔNG TIN ĐĂNG NHẬP WEB DASHBOARD PHỤ HUYNH

* **Địa chỉ truy cập**: [http://localhost:8080](http://localhost:8080)
* **Email mặc định**: `phuhuynh@ogk.vn`
* **Mật khẩu mặc định**: `MatKhauPhuHuynh2026!`
* *(Mẹo: Tại trang đăng nhập, bạn có thể nhấn nút **"Điền nhanh tài khoản Demo"** rồi bấm **"Đăng Nhập"**).*

---

## 5. HƯỚNG DẪN SỬ DỤNG & KIỂM THỬ CHI TIẾT 8 TÍNH NĂNG TRỌNG TÂM

### 5.1. Ghép đôi thiết bị mới bằng mã 8 ký tự (Chuẩn Nghị định 13/2023)
* **Mặc định**: Hệ thống đã ghép đôi sẵn một thiết bị mẫu (`Laptop-BeAn-Demo`) để bạn có thể test ngay lập tức mà không cần cấu hình.
* **Nếu muốn thực hành quy trình ghép đôi mới**:
  1. Trên Web Dashboard Phụ huynh, chọn menu **`🔗 Ghép đôi thiết bị`** ở thanh bên trái.
  2. Nhấn nút **`🔑 Tạo Mã Ghép Đôi 8 Ký Tự`** -> Hệ thống sinh ra một mã gồm 8 ký tự (ví dụ: `LYD4EB3K`), có hiệu lực trong 10 phút.
  3. Chạy file **`2_GHEP_DOI_AGENT.bat`** (hoặc bấm nút số 2 trong Trung tâm điều khiển), nhập mã 8 ký tự vừa tạo và nhấn Enter.
  4. Máy tính của bé sẽ nhận `device_id` và `access_token` riêng, đồng thời trạng thái trên Web Dashboard chuyển sang **`● Đang trực tuyến (Online)`**.

---

### 5.2. Theo dõi ứng dụng đang hoạt động thời gian thực (Live Active Apps)
Tính năng này cho phép cả phụ huynh và bé biết chính xác những ứng dụng nào đang mở trên máy tính theo thời gian thực (cập nhật mỗi `1.5 – 3 giây`):
* **Trên Web Dashboard Phụ huynh**:
  1. Tại tab **`📊 Tổng quan & App đang chạy`** (hoặc tab **`🛡️ Lọc App & DNS Proxy`**), quan sát bảng **`🟢 Theo dõi ứng dụng đang hoạt động thời gian thực (Live Active Apps)`**.
  2. Bảng hiển thị chi tiết: **Tên tiến trình (`.exe`)**, **PID**, **Dung lượng RAM (MB)**, **Thời gian đã dùng hôm nay**, **Hạn mức / ngày**, và **Trạng thái**.
  3. **Thao tác nhanh 1-Click**: Ngay tại dòng ứng dụng đang chạy, phụ huynh có thể bấm:
     * **`⏱️ Đặt giới hạn giờ`**: Đặt số phút tối đa được phép mở ứng dụng đó trong ngày.
     * **`🚫 Chặn ngay`**: Đưa ứng dụng vào danh sách cấm và đóng tiến trình trên máy bé mà không cần phải tự gõ tên file `.exe`.
* **Trên Giao diện Bạn Đồng Hành của Bé (`Tray UI`)**:
  1. Bấm nút **`🟢 Theo Dõi Ứng Dụng Đang Hoạt Động`** trên giao diện chính của bé.
  2. Cửa sổ danh sách ứng dụng đang mở sẽ hiện ra, tự động làm mới mỗi 2 giây để bé tự giác theo dõi thời gian học và chơi.

---

### 5.3. Phân chia hạn mức thời gian riêng cho từng ứng dụng & Chặn bằng SHA-256
Ngoài tổng thời gian sử dụng máy trong ngày, phụ huynh có thể giới hạn thời gian cho từng phần mềm/trò chơi cụ thể (ví dụ: tổng thời gian dùng máy là 120 phút, nhưng `roblox.exe` hay `discord.exe` chỉ được dùng tối đa 45 phút/ngày):
1. Vào menu **`🛡️ Lọc App & DNS Proxy`** trên Web Dashboard.
2. Tại mục **Kiểm soát Ứng dụng**, nhấn **`+ Thêm quy tắc App`** (hoặc bấm **`⏱️ Đặt giới hạn giờ`** từ bảng ứng dụng đang chạy):
   * **Tên tiến trình (`.exe`)**: Nhập tên file thực thi, ví dụ `roblox.exe` hoặc `discord.exe`.
   * **Mã băm SHA-256**: Để `*` nếu muốn áp dụng theo tên, hoặc dán mã SHA-256 của file `.exe` để **chặn tuyệt đối kể cả khi trẻ đổi tên file `roblox.exe` thành `word.exe`**.
   * **Hành động**: Chọn **`✅ Cho phép chạy`**.
   * **Hạn mức phút/ngày**: Nhập số phút tối đa được phép dùng trong ngày (ví dụ: `45` phút; nhập `0` nếu không giới hạn riêng).
3. Nhấn **`Lưu quy tắc`** -> Hệ thống tự động ký chữ ký số **HMAC-SHA256** và đồng bộ xuống máy của bé.
4. Trên giao diện **Tray UI của bé**, khung **"HẠN MỨC THỜI GIAN TỪNG ỨNG DỤNG CHO PHÉP"** sẽ hiển thị thanh tiến trình của ứng dụng đó. Khi dùng hết 45 phút, Agent sẽ tự động đóng ứng dụng đó nhưng vẫn cho phép bé dùng các phần mềm học tập khác!

---

### 5.4. Đồng bộ 2 chiều: Xin thêm giờ, Báo chặn nhầm & Tự động mở khóa Web/App
Hệ thống hỗ trợ luồng tương tác 2 chiều hoàn toàn tự động (kể cả khi cửa sổ Tray UI của bé đang thu nhỏ dưới khay hệ thống):

#### A. Luồng 1: Bé xin mở khóa trang web hoặc ứng dụng bị chặn
1. Trên giao diện **Tray UI của bé**, nhấn nút **`🛡️ Báo Chặn Nhầm Web / App`**.
2. Nhập tên trang web đang bị chặn (ví dụ: `facebook.com` hoặc `tiktok.com`) và lời nhắn cho ba mẹ (ví dụ: *"Con cần xem video bài giảng vật lý trên nhóm lớp"*), sau đó nhấn **`📨 Gửi Báo Cáo Cho Ba Mẹ`**.
3. Trên **Web Dashboard Phụ huynh**, mục **`💬 Yêu cầu của bé`** sẽ hiện chấm đỏ thông báo mới.
4. Phụ huynh mở tab **`💬 Yêu cầu của bé`** và nhấn nút **`✓ Duyệt & Mở chặn ngay`**.
5. **Kết quả đồng bộ tự động**:
   * Server **tự động chuyển quy tắc của `facebook.com` trong danh sách chặn sang trạng thái `Cho phép (Allow)`** (phụ huynh không cần phải tự vào danh sách chặn để xóa thủ công).
   * Trong vòng **1.5 giây**, máy của bé tự động tải chính sách mới, gỡ `facebook.com` khỏi DNS Proxy và file `hosts`, xóa cache DNS (`ipconfig /flushdns`), đồng thời bật **Popup thông báo chúc mừng nổi trên màn hình của bé**: *"✅ Ba mẹ đã mở khóa cho con! Đã mở chặn tự động: facebook.com"*.

#### B. Luồng 2: Bé xin thêm 15 phút hoặc Phụ huynh từ chối yêu cầu
1. Bé nhấn nút **`⏳ Xin Ba Mẹ Thêm 15 Phút`** trên Tray UI -> Nhập lý do -> Gửi.
2. Phụ huynh vào tab **`💬 Yêu cầu của bé`**:
   * Nếu bấm **`✓ Duyệt +15p`**: Đồng hồ của bé lập tức được cộng thêm 15 phút và hiện Popup thông báo chúc mừng kèm âm thanh vui nhộn.
   * Nếu bấm **`Từ chối`**: Máy của bé cũng lập tức hiện Popup thông báo nhẹ nhàng kèm lời nhắn của phụ huynh để bé biết kết quả.

---

### 5.5. Giao nhiệm vụ học tập & Trao thưởng giờ (Gamification)
1. Trên Web Dashboard, vào tab **`🌟 Nhiệm vụ thưởng giờ`** -> Nhấn **`+ Giao nhiệm vụ mới`**.
2. Nhập tên nhiệm vụ (ví dụ: *"Hoàn thành 5 bài Toán trên OLM"*), chọn mức thưởng (`+15 phút`, `+30 phút`, hoặc `+45 phút`) -> Bấm **`Giao nhiệm vụ`**.
3. Trên giao diện **Tray UI của bé**, bấm nút **`🌟 Làm Nhiệm Vụ Nhận Thưởng Giờ`** -> Bé tích chọn **`✅ Báo hoàn thành`** khi đã làm xong bài.
4. Trên Web Dashboard, trạng thái nhiệm vụ chuyển sang **`🔔 Bé báo hoàn thành`** -> Phụ huynh nhấn **`🎁 Duyệt & Tặng +30p`**.
5. Máy của bé sẽ phát giai điệu nhận thưởng, hiển thị **Popup chúc mừng** và tự động cộng thêm 30 phút vào quỹ thời gian trong ngày!

---

### 5.6. Ma trận lịch biểu 7×48 & Lệnh điều khiển khẩn cấp từ xa (< 5 giây)
* **Lịch biểu 7×48**: Tại tab **`⏰ Quota & Lịch 7×48`**, bạn có thể nhấp vào từng ô 30 phút để bật/tắt khung giờ được phép dùng máy, hoặc chọn các mẫu có sẵn (*Khung giờ học tập chuẩn*, *Chỉ buổi tối*, *Mở toàn tuần*, *Khóa toàn tuần*), sau đó bấm **`💾 Lưu Chính Sách & Ký HMAC`**.
* **Lệnh khẩn cấp trên thanh Header**:
  * **`🔒 Khóa máy ngay`**: Khóa phiên sử dụng trên máy bé ngay lập tức.
  * **`🔓 Mở khóa`**: Mở khóa lại cho bé.
  * **`⚡ Thưởng +15 phút`**: Tặng nóng 15 phút cho bé kèm thông báo Popup tức thì.

---

### 5.7. Minh bạch hai chiều (NT5), Nhật ký kiểm toán & Quyền riêng tư (NĐ 13/2023)
* **Trên máy của bé**: Nhấn nút **`🔍 Hôm Nay Em Đã Dùng Gì? (Minh Bạch)`** trên Tray UI -> Bé sẽ thấy bảng thống kê thời gian sử dụng và lịch sử các quy tắc mà ba mẹ đã thiết lập (đảm bảo minh bạch, tôn trọng trẻ).
* **Trên Web Dashboard Phụ huynh**:
  * Tab **`📜 Nhật ký kiểm toán`**: Lưu vết toàn bộ thay đổi chính sách kèm dấu thời gian và địa chỉ IP, hỗ trợ nút **`📥 Xuất file CSV (Excel)`**.
  * Nút **`🗑️ Xóa toàn bộ dữ liệu của con`** (tại tab Tổng quan): Xóa sạch toàn bộ lịch sử hoạt động của trẻ trên cả Server và Agent theo đúng quyền được lãng quên của Nghị định 13/2023/NĐ-CP.

---

## 6. CÔNG CỤ KIỂM THỬ DNS PROXY ĐỘC LẬP (`tools_dns_tester`)

Nếu bạn muốn trình diễn riêng cơ chế hoạt động của **DNS Proxy cấp gói tin UDP cổng 53** (độc lập với Server):
1. Mở thư mục **`tools_dns_tester`**.
2. Nhấp chuột phải vào file **`CHAY_DNS_PROXY_ADMIN.bat`** -> Chọn **Run as administrator**.
3. Trên giao diện **OGK - Standalone DNS Proxy Tester**:
   * Nhập bất kỳ tên miền hoặc đường link nào muốn chặn (ví dụ: `facebook.com`, `tiktok.com`, `shopee.vn`) -> Nhấn **`+ Thêm Vào Danh Sách Chặn`**.
   * Nhấn nút màu xanh **`▶ BẬT DNS PROXY & CHẶN WEB`**.
4. Hệ thống sẽ kích hoạt **Cơ chế chặn kép (Dual-Layer)**:
   * Lắng nghe trực tiếp cổng `127.0.0.1:53` để trả về IP Sinkhole `0.0.0.0` cho mọi tên miền bị chặn và tên miền con (`*.facebook.com`).
   * Đồng bộ vào file `hosts` của Windows và tự động ngắt các kết nối socket đang mở + xóa bộ đệm DNS (`ipconfig /flushdns`) để trình duyệt không thể dùng lại IP cũ đã lưu trong cache.
5. Khi thử nghiệm xong, nhấn nút **`⏹ TẮT DNS PROXY (Khôi phục mạng)`** trước khi đóng cửa sổ.

---

## 7. KHÔI PHỤC MẠNG GỐC & XỬ LÝ SỰ CỐ THƯỜNG GẶP (TROUBLESHOOTING)

### Câu hỏi 1: Sau khi tắt ứng dụng hoặc tắt máy đột ngột, mình không vào được Discord, Instagram, Facebook hoặc mất mạng?
* **Nguyên nhân**: Khi đang bật chế độ chặn web mà bạn đóng cưỡng bức cửa sổ dòng lệnh hoặc tắt máy đột ngột, card mạng Windows có thể vẫn đang trỏ DNS về `127.0.0.1` hoặc file `hosts` vẫn còn lưu dòng chặn.
* **Cách khắc phục trong 3 giây**:
  1. Vào thư mục chính của dự án, nhấp **chuột phải** vào file **`KHOI_PHUC_MANG_GOC.bat`**.
  2. Chọn **Run as administrator** (Chạy với quyền Quản trị viên).
  3. Công cụ sẽ tự động trả DNS card mạng về DHCP tự động, xóa sạch toàn bộ dòng chặn OGK trong file `hosts` và làm mới bộ đệm mạng. Mọi ứng dụng (Discord, Instagram, Facebook, trình duyệt) sẽ hoạt động bình thường trở lại ngay lập tức!

### Câu hỏi 2: Chạy lệnh PowerShell hoặc bật DNS Proxy báo lỗi `Access is denied` / `PermissionDenied`?
* **Nguyên nhân**: Cổng mạng `53` và file hệ thống `C:\Windows\System32\drivers\etc\hosts` được Windows bảo vệ, bắt buộc phải có quyền Quản trị viên (Administrator) mới được phép chỉnh sửa.
* **Cách khắc phục**: Luôn nhấp **chuột phải** vào file `.bat` (`0_TRUNG_TAM_DIEU_KHIEN.bat`, `3_CHAY_AGENT_SERVICE.bat`, hoặc `KHOI_PHUC_MANG_GOC.bat`) và chọn **Run as administrator**.

### Câu hỏi 3: Làm sao để kiểm tra toàn bộ các chức năng của dự án có hoạt động đúng 100% trước khi nộp bài / báo cáo không?
* Mở Terminal / Command Prompt tại thư mục dự án và chạy lệnh:
  ```bash
  python verify_real_world.py
  ```
* Kịch bản tự động sẽ kiểm tra toàn bộ **29/29 tiêu chí thực tế** (từ bảo mật `scrypt`, chống brute-force, mã hóa `AES-256-GCM`, `TOTP 2FA`, ghép đôi 8 ký tự, chặn DNS wildcard, SafeSearch, chống DoH, băm `SHA-256` chống đổi tên `.exe`, chống lùi đồng hồ hệ thống, đến đồng bộ mở chặn tự động, hạn mức từng ứng dụng và theo dõi tiến trình thời gian thực) và in kết quả **`ĐẠT CHUẨN 100%`**.
