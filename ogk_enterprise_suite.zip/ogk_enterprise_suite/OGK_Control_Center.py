import sys
import os
import subprocess
import webbrowser
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

ROOT_DIR = Path(__file__).resolve().parent
VENV_PYTHON = ROOT_DIR / "venv" / "Scripts" / "python.exe" if sys.platform == "win32" else ROOT_DIR / "venv" / "bin" / "python"
PYTHON_EXEC = str(VENV_PYTHON) if VENV_PYTHON.exists() else sys.executable

class OGKControlCenter:
    """
    Bàn điều khiển trung tâm thương mại (Commercial Master Launcher):
    Quản lý toàn bộ hệ sinh thái OGK chỉ từ 1 giao diện duy nhất.
    Hỗ trợ kéo giãn kích thước tự do (Resizable) và tự động xuống dòng chống mất chữ.
    """
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("OGK Enterprise Suite - Trung Tâm Điều Khiển Tổng Hợp")
        self.root.geometry("720x600")
        self.root.minsize(560, 460)
        self.root.resizable(True, True)
        self.root.configure(bg="#0f172a")

        self.server_proc = None
        self.agent_proc = None
        self.tray_proc = None
        self._desc_labels = []

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        # 1. Header
        hdr = tk.Frame(self.root, bg="#1e293b", padx=24, pady=16)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text="🛡️ OGK ENTERPRISE SUITE v2.0", font=("Segoe UI", 15, "bold"), fg="#38bdf8", bg="#1e293b").pack(anchor="w")
        self.hdr_sub = tk.Label(
            hdr,
            text="Hệ thống Quản lý & Đồng hành Trẻ em trên Máy tính — Phiên bản Thương mại Hoàn chỉnh",
            font=("Segoe UI", 9),
            fg="#94a3b8",
            bg="#1e293b",
            justify="left"
        )
        self.hdr_sub.pack(anchor="w", pady=(2, 0))

        # 2. Scrollable Middle Body
        mid_container = tk.Frame(self.root, bg="#0f172a")
        mid_container.grid(row=1, column=0, sticky="nsew")
        mid_container.grid_rowconfigure(0, weight=1)
        mid_container.grid_columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(mid_container, bg="#0f172a", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(mid_container, orient="vertical", command=self.canvas.yview)
        self.body = tk.Frame(self.canvas, bg="#0f172a", padx=24, pady=14)

        self.canvas_win = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")

        self.body.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # Module Cards
        self._create_module_card(
            self.body,
            title="1. Máy Chủ Trung Tâm & Web Dashboard (OGK-Server)",
            desc="Cổng 8080 • Quản lý đa hồ sơ trẻ, Theo dõi App đang chạy, Ma trận lịch 7×48, Báo cáo biểu đồ, Nhiệm vụ thưởng giờ",
            btn_text="▶ Khởi Động Server & Mở Web",
            btn_color="#2563eb",
            cmd=self.start_server_and_web
        )

        self._create_module_card(
            self.body,
            title="2. Ghép Đôi Thiết Bị (Device Enrollment)",
            desc="Liên kết máy tính của trẻ với tài khoản phụ huynh bằng mã 8 ký tự (Chuẩn Nghị định 13/2023)",
            btn_text="🔗 Mở Cửa Sổ Ghép Đôi",
            btn_color="#4f46e5",
            cmd=self.open_enrollment
        )

        self._create_module_card(
            self.body,
            title="3. Dịch Vụ Bảo Vệ Nền & DNS Proxy (OGK-Agent Service)",
            desc="Cổng 53 & 58000 • Chặn tên miền, Cưỡng chế SafeSearch, Quét SHA-256, Hạn mức từng ứng dụng, Chống lùi đồng hồ",
            btn_text="🛡️ Bật Dịch Vụ Bảo Vệ (Admin)",
            btn_color="#059669",
            cmd=self.start_agent_service
        )

        self._create_module_card(
            self.body,
            title="4. Giao Diện Bạn Đồng Hành Cho Bé (Child Tray UI)",
            desc="Khay hệ thống • Đồng bộ ngầm liên tục, Theo dõi App đang hoạt động, Xin thêm giờ, Làm nhiệm vụ nhận thưởng",
            btn_text="🐻 Mở Giao Diện Cho Bé",
            btn_color="#d97706",
            cmd=self.start_tray_ui
        )

        # 3. Pinned Bottom Utility Bar (Never clipped when resizing)
        bottom = tk.Frame(self.root, bg="#1e293b", padx=24, pady=12)
        bottom.grid(row=2, column=0, sticky="ew")
        bottom.grid_columnconfigure(0, weight=1)
        bottom.grid_columnconfigure(1, weight=1)

        tk.Button(
            bottom,
            text="🔄 Khôi Phục Mạng Gốc (Reset DNS & Hosts)",
            font=("Segoe UI", 9, "bold"),
            bg="#334155",
            fg="#f8fafc",
            relief=tk.FLAT,
            padx=12,
            pady=8,
            cursor="hand2",
            command=self.restore_network
        ).grid(row=0, column=0, sticky="w", padx=(0, 6))

        tk.Button(
            bottom,
            text="⏹ Dừng Toàn Bộ Hệ Thống",
            font=("Segoe UI", 9, "bold"),
            bg="#dc2626",
            fg="#ffffff",
            relief=tk.FLAT,
            padx=15,
            pady=8,
            cursor="hand2",
            command=self.stop_all
        ).grid(row=0, column=1, sticky="e", padx=(6, 0))

    def _on_canvas_resize(self, event):
        self.canvas.itemconfig(self.canvas_win, width=event.width)
        wrap_w = max(220, event.width - 280)
        for lbl in self._desc_labels:
            lbl.configure(wraplength=wrap_w)
        self.hdr_sub.configure(wraplength=max(320, event.width - 48))

    def _create_module_card(self, parent, title, desc, btn_text, btn_color, cmd):
        card = tk.Frame(parent, bg="#1e293b", padx=16, pady=12, relief=tk.FLAT, highlightthickness=1, highlightbackground="#334155")
        card.pack(fill=tk.X, pady=6)
        card.grid_columnconfigure(0, weight=1)

        info = tk.Frame(card, bg="#1e293b")
        info.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        tk.Label(info, text=title, font=("Segoe UI", 10, "bold"), fg="#f8fafc", bg="#1e293b", justify="left").pack(anchor="w")
        desc_lbl = tk.Label(info, text=desc, font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b", justify="left", wraplength=380)
        desc_lbl.pack(anchor="w", pady=(3, 0))
        self._desc_labels.append(desc_lbl)

        tk.Button(
            card,
            text=btn_text,
            font=("Segoe UI", 9, "bold"),
            bg=btn_color,
            fg="#ffffff",
            relief=tk.FLAT,
            padx=14,
            pady=8,
            cursor="hand2",
            command=cmd
        ).grid(row=0, column=1, sticky="e")

    def start_server_and_web(self):
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(ROOT_DIR / "1_CHAY_SERVER.bat")], cwd=str(ROOT_DIR))
        threading.Timer(2.0, lambda: webbrowser.open("http://localhost:8080")).start()

    def open_enrollment(self):
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(ROOT_DIR / "2_GHEP_DOI_AGENT.bat")], cwd=str(ROOT_DIR))

    def start_agent_service(self):
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(ROOT_DIR / "3_CHAY_AGENT_SERVICE.bat")], cwd=str(ROOT_DIR))

    def start_tray_ui(self):
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(ROOT_DIR / "4_CHAY_TRAY_UI.bat")], cwd=str(ROOT_DIR))

    def restore_network(self):
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(ROOT_DIR / "KHOI_PHUC_MANG_GOC.bat")], cwd=str(ROOT_DIR))

    def stop_all(self):
        if messagebox.askyesno("Dừng hệ thống", "Bạn có muốn đóng toàn bộ các tiến trình Server, Agent và Tray UI đang chạy không?"):
            if sys.platform == "win32":
                subprocess.run("taskkill /F /IM python.exe", shell=True)
            sys.exit(0)

    def on_close(self):
        self.root.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = OGKControlCenter()
    app.run()
