@echo off
setlocal
title "OGK Enterprise Control Center"
set ROOT=%~dp0
cd /d "%ROOT%"

if exist "%ROOT%venv\Scripts\python.exe" (
    "%ROOT%venv\Scripts\python.exe" OGK_Control_Center.py
) else (
    python OGK_Control_Center.py
)
