import os
import sys
from pathlib import Path

server_dir = Path(__file__).resolve().parent / "ogk_server"
os.chdir(server_dir)
sys.path.insert(0, str(server_dir))

import uvicorn

if __name__ == "__main__":
    print("=" * 65)
    print("       OGK-SERVER: KHỞI ĐỘNG MÁY CHỦ VÀ WEB DASHBOARD PHỤ HUYNH       ")
    print("=" * 65)
    print("Đang lắng nghe tại: http://localhost:8080 (hoặc http://127.0.0.1:8080)")
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)
