@echo off
setlocal
title "OGK-Agent Service (DNS Proxy va Giam sat)"
set ROOT=%~dp0
cd /d "%ROOT%"

:: Auto-elevate to Administrator for Port 53 DNS Binding
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [THONG BAO] Dang yeu cau quyen Administrator de mo cong mang DNS 53...
    powershell -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
    exit /b
)

if not exist "%ROOT%venv\Scripts\python.exe" (
    echo ================================================================
    echo  [OGK AUTO-SETUP] Dang chuan bi moi truong venv...
    echo ================================================================
    py -m venv "%ROOT%venv"
    "%ROOT%venv\Scripts\pip" install -r "%ROOT%ogk_agent\requirements.txt"
)

set PY_CMD="%ROOT%venv\Scripts\python.exe"
cd /d "%ROOT%ogk_agent"
%PY_CMD% agent_service.py
pause
