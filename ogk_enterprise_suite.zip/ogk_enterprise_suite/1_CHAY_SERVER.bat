@echo off
setlocal
title "OGK-Server (May chu va Web Dashboard)"
set ROOT=%~dp0
cd /d "%ROOT%"

if not exist "%ROOT%venv\Scripts\python.exe" (
    echo ================================================================
    echo  [OGK AUTO-SETUP] Phat hien thu muc moi chua co venv.
    echo  Dang tu dong khoi tao venv va cai dat thu vien cho ban...
    echo  (Qua trinh nay chi chay 1 lan duy nhat, vui long cho trong giay lat)
    echo ================================================================
    py -m ensurepip --upgrade >nul 2>&1
    py -m venv "%ROOT%venv"
    if not exist "%ROOT%venv\Scripts\python.exe" (
        python -m venv "%ROOT%venv"
    )
    echo Dang cai dat cac thu vien can thiet (FastAPI, Uvicorn, Jinja2, Requests...)...
    "%ROOT%venv\Scripts\pip" install -r "%ROOT%ogk_server\requirements.txt"
    "%ROOT%venv\Scripts\pip" install -r "%ROOT%ogk_agent\requirements.txt"
    echo ================================================================
    echo  CAI DAT HOAN TAT! DANG KHOI DONG SERVER TREN CONG 8080...
    echo ================================================================
)

set PY_CMD="%ROOT%venv\Scripts\python.exe"
cd /d "%ROOT%ogk_server"
%PY_CMD% main.py
pause
