# KỊCH BẢN THỰC HIỆN DEMO VẤN ĐÁP ĐỒ ÁN MẠNG MÁY TÍNH

Tài liệu này chuẩn bị sẵn 5 kịch bản demo trực tiếp để nhóm đạt điểm tuyệt đối khi trình bày trước Hội đồng chấm thi:

---

### DEMO 1: Khởi chạy hệ thống & Ghép đôi thiết bị (Enrollment)
1. **Khởi chạy Server**:
   ```powershell
   cd ogk_server
   python main.py
   ```
2. Mở trình duyệt vào **`http://localhost:8080`** $ightarrow$ Đăng nhập với `phuhuynh@ogk.vn` / `MatKhauPhuHuynh2026!`.
3. Vào tab **Ghép đôi thiết bị** $ightarrow$ Bấm **Tạo mã ghép đôi 8 ký tự** (giả sử được mã `JLL3CZHJ`).
4. **Tại máy trẻ**, mở PowerShell quyền Admin trong thư mục `ogk_agent`:
   ```powershell
   python enroll_device.py
   ```
   Nhập mã `JLL3CZHJ` $ightarrow$ Nhận diện thiết bị thành công, lưu token vào ProgramData.
5. Khởi chạy Agent:
   ```powershell
   python agent_service.py
   ```
6. Khởi chạy Tray UI (trong cửa sổ khác):
   ```powershell
   python tray_ui/tray_app.py
   ```
   $ightarrow$ Quan sát thấy biểu tượng OGK xuất hiện ở khay hệ thống kèm thông báo nổi (Nguyên tắc NT1).

---

### DEMO 2: Lọc tên miền & Cưỡng chế SafeSearch bằng DNS Proxy 127.0.0.1:53
1. Mở Command Prompt trên máy trẻ, gõ lệnh nslookup kiểm tra:
   ```cmd
   nslookup tiktok.com 127.0.0.1
   ```
   $ightarrow$ Kết quả trả về `0.0.0.0` (Bị chặn).
2. Kiểm tra SafeSearch Google:
   ```cmd
   nslookup www.google.com 127.0.0.1
   ```
   $ightarrow$ Kết quả trả về `216.239.38.120` (`forcesafesearch.google.com`).
3. Kiểm tra tên miền miễn chặn vĩnh viễn (NT6):
   ```cmd
   nslookup tongdai111.vn 127.0.0.1
   ```
   $ightarrow$ Phân giải bình thường, không bao giờ bị chặn.

---

### DEMO 3: Chống đổi tên file thực thi bằng mã băm SHA-256
1. Tạo một file `game.exe` (hoặc lấy một file game bị chặn trong danh sách).
2. Đổi tên file đó thành `notepad.exe`.
3. Nhấp đúp chuột chạy file $ightarrow$ Trong vòng 1 giây, tiến trình bị tắt lập tức (`terminate`) và xuất hiện hộp thoại popup giải thích lý do: *"Ứng dụng bị hạn chế bởi phụ huynh"* (Nguyên tắc NT4).

---

### DEMO 4: Chống chỉnh lùi đồng hồ hệ thống (Clock Tampering)
1. Trên Windows, chỉnh lùi đồng hồ hệ thống về trước 3 tiếng.
2. Quan sát log của Agent $ightarrow$ Agent ghi nhận: `Detected system clock rollback! Logging clock_tampering`.
3. Quota thời gian còn lại không hề tăng lên vì Agent sử dụng bộ đếm đơn điệu `time.monotonic()` độc lập với đồng hồ hệ thống.

---

### DEMO 5: Lệnh khẩn cấp từ xa (< 5 giây) & Trẻ xin thêm giờ
1. Trên Dashboard phụ huynh, nhấn nút đỏ **"Khóa ngay"** $ightarrow$ Dưới 2 giây, máy tính của trẻ tự động gọi `LockWorkStation` và khóa màn hình.
2. Nhấn nút **"Mở khóa"** hoặc **"+15 phút"** $ightarrow$ Máy trẻ được mở khóa và đồng hồ cộng thêm 15 phút.
3. Trên máy trẻ, bấm nút **"Xin thêm 15 phút"** $ightarrow$ Trên Dashboard phụ huynh hiện thông báo chờ duyệt $ightarrow$ Phụ huynh nhấn **"Duyệt"**, lệnh lập tức được truyền xuống máy trẻ.
