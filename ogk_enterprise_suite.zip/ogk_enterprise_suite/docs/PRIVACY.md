# TÀI LIỆU MINH BẠCH VÀ CHÍNH SÁCH BẢO VỆ DỮ LIỆU CÁ NHÂN (PRIVACY.md)
*Tuân thủ Nghị định 13/2023/NĐ-CP về Bảo vệ dữ liệu cá nhân và Nguyên tắc NT2: Tối thiểu dữ liệu*

## 1. Triết lý thiết kế & Cam kết
Hệ thống **OGK (Open Guardian Kid)** được xây dựng theo định vị: **"Công cụ đồng hành, không phải phần mềm theo dõi lén"**.
Hệ thống tuyệt đối **KHÔNG**:
1. Thu thập nội dung tin nhắn, email, văn bản gõ phím (Keylogger).
2. Chụp ảnh màn hình (Screenshots) hay bật micro/webcam.
3. Gửi dữ liệu cá nhân tới bất kỳ dịch vụ phân tích hay máy chủ bên thứ ba nào.
4. Chạy tiến trình ẩn hay sử dụng kỹ thuật rootkit.

---

## 2. Bảng ma trận dữ liệu thu thập (Data Retention Matrix)

| Trường dữ liệu | Kiểu dữ liệu | Mục đích sử dụng | Thời hạn lưu trữ | Ai có quyền xem | Biện pháp bảo vệ kỹ thuật |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ts` | Unix Timestamp | Ghi nhận thời điểm sự kiện diễn ra để vẽ biểu đồ và đối chiếu lịch tuần | 90 ngày (tự động xóa) | Phụ huynh, Trẻ (NT5) | Chỉ lưu timestamp nguyên bản |
| `device_id` | UUID v4 | Định danh thiết bị của trẻ đã được phụ huynh ghép đôi hợp lệ | Đến khi gỡ thiết bị | Phụ huynh, Hệ thống | Sinh ngẫu nhiên, không gắn với số serial phần cứng nhạy cảm |
| `child_id` | Integer | Phân loại báo cáo và áp dụng đúng chính sách cho từng trẻ | Đến khi xóa hồ sơ trẻ | Phụ huynh, Hệ thống | Khóa ngoại Database (ON DELETE CASCADE) |
| `type` | Enum String | Nhận diện loại hoạt động (`app_start`, `blocked_app`, `domain_query`, `locked`,...) | 90 ngày (tự động xóa) | Phụ huynh, Trẻ (NT5) | Thuộc tập enum cố định đã được kiểm duyệt |
| `subject` | String | Tên tệp thực thi (vd: `zoom.exe`) hoặc tên miền cấp hai (vd: `khanacademy.org`) | 90 ngày (tự động xóa) | Phụ huynh, Trẻ (NT5) | **Cắt bỏ toàn bộ URL đầy đủ, tham số query và tiêu đề cửa sổ** |
| `duration_sec` | Integer | Đo lường thời lượng sử dụng thực tế để trừ vào Quota hàng ngày | 90 ngày (tự động xóa) | Phụ huynh, Trẻ (NT5) | Chỉ đếm khi có tương tác (ngắt khi idle > 5 phút) |
| `policy_id` | Integer | Đối chiếu phiên bản chính sách đang áp dụng tại thời điểm xảy ra sự kiện | 90 ngày (tự động xóa) | Phụ huynh, Hệ thống | Khóa ngoại chính sách |
| `idempotency_key`| UUID v4 | Khử trùng lặp sự kiện khi Agent đồng bộ theo lô sau khi ngoại tuyến | 90 ngày (tự động xóa) | Hệ thống | Ràng buộc UNIQUE INDEX trong SQLite |

---

## 3. Quyền của Phụ huynh và Trẻ em

1. **Quyền được biết & Minh bạch hai chiều (NT1 & NT5)**:
   - Trẻ luôn nhìn thấy biểu tượng OGK trên khay hệ thống, biết rõ máy đang áp dụng luật gì.
   - Trẻ có màn hình *"Hôm nay em đã dùng gì"* hiển thị cùng bộ dữ liệu với phụ huynh.
   - Trẻ được quyền xem Nhật ký kiểm toán (Audit Log) ghi nhận mọi thay đổi luật của phụ huynh.
2. **Quyền có tiếng nói (NT3)**:
   - Trẻ có nút *"Xin thêm 15 phút"* và *"Báo chặn nhầm"* gửi thẳng tới bảng điều khiển phụ huynh.
3. **Quyền được lãng quên & Xóa dữ liệu (Right to be Forgotten)**:
   - Nút **"Xóa toàn bộ dữ liệu của con tôi"** trên Dashboard phụ huynh cho phép xóa vĩnh viễn toàn bộ sự kiện và yêu cầu trên Server cũng như bộ đệm cục bộ của Agent ngay lập tức.
   - Tác vụ tự động dọn dẹp chạy định kỳ xóa vĩnh viễn dữ liệu cũ quá 90 ngày.
