# ĐẶC TẢ KIẾN TRÚC VÀ GIAO THỨC OGK (ARCHITECTURE.md)

## 1. Sơ đồ luồng giao tiếp (Protocols)

### 1.1. Ghép đôi thiết bị (Enrollment Protocol)
1. Phụ huynh đăng nhập Web Dashboard, chọn trẻ cần ghép đôi $ightarrow$ nhấn **"Tạo mã ghép đôi"**.
2. Server sinh mã 8 ký tự (vd: `JLL3CZHJ`), lưu vào bảng `enrollment_codes` với hạn dùng 10 phút.
3. Tại máy của trẻ, phụ huynh/trẻ nhập mã này vào OGK-Agent.
4. Agent gửi `POST /api/v1/enroll/claim` kèm mã và `device_fingerprint`.
5. Server kiểm tra hạn mã, tạo bản ghi `devices`, đánh dấu mã đã dùng, và trả về:
   - `device_id`: UUID của thiết bị
   - `access_token`: JWT ngắn hạn (15 phút)
   - `refresh_token`: JWT dài hạn (30 ngày)
6. Agent lưu token vào SQLite bảo mật tại `C:\ProgramData\OGK-Agent\cache.db`.

### 1.2. Nhịp tim & Kiểm tra chính sách (Heartbeat Protocol - 60s)
1. Mỗi 60 giây, Agent gửi `POST /api/v1/heartbeat`:
   ```json
   {
     "policy_version": 1,
     "used_quota_today_sec": 1800,
     "system_status": "ok",
     "agent_uptime_sec": 3600
   }
   ```
2. Server cập nhật `last_heartbeat` và trả về:
   - `server_time`: Unix timestamp máy chủ (dùng chống chỉnh lùi giờ hệ thống).
   - `latest_policy_version`: Phiên bản chính sách mới nhất trên server.
   - `commands`: Danh sách lệnh đang chờ (nếu có).
3. Nếu `policy_version < latest_policy_version`, Agent gọi ngay `GET /api/v1/policy` để tải và xác thực chữ ký HMAC của chính sách mới.

### 1.3. Lệnh khẩn cấp qua WebSocket (< 5s Latency)
- Agent duy trì kết nối WebSocket liên tục tới `/ws/agent/{device_id}`.
- Khi phụ huynh bấm **Khóa ngay**, **Mở khóa**, hoặc **+15 phút**, Server gửi thông điệp JSON qua WebSocket tới Agent với độ trễ dưới 500ms.
- Nếu mất mạng (WebSocket đứt), lệnh được lưu vào bảng `pending_commands` và tự động gửi qua Heartbeat ngay khi có kết nối trở lại.

### 1.4. Đồng bộ ngoại tuyến & Chống trùng lặp (Offline Batch Sync)
- Khi mất mạng, Agent tiếp tục đếm giờ, lưu sự kiện vào SQLite cục bộ.
- Mỗi sự kiện được gán 1 `idempotency_key` (UUID v4 duy nhất).
- Khi có mạng, Agent gửi `POST /api/v1/events/batch`. Server dùng ràng buộc `UNIQUE(idempotency_key)` để đảm bảo mỗi sự kiện chỉ được ghi nhận đúng một lần duy nhất.
