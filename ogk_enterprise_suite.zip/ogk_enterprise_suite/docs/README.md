# HƯỚNG DẪN CÀI ĐẶT VÀ KHỞI CHẠY OGK-SERVER

## 1. Cài đặt môi trường
Yêu cầu: Python 3.11+
```bash
cd ogk_server
pip install -r requirements.txt
```

## 2. Khởi chạy Server
```bash
python main.py
```
Hoặc dùng uvicorn trực tiếp:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## 3. Truy cập Web Dashboard
- Mở trình duyệt tại: `http://localhost:8000`
- Tài khoản mẫu mặc định đã được khởi tạo:
  - **Email**: `phuhuynh@ogk.vn`
  - **Mật khẩu**: `MatKhauPhuHuynh2026!`
- Tài liệu API tương tác (Swagger UI): `http://localhost:8000/docs`

## 4. Chạy kiểm thử tự động
```bash
python test_server_flows.py
```
