# BÁO CÁO ĐỒ ÁN MÔN HỌC MẠNG MÁY TÍNH
## ĐỀ TÀI: XÂY DỰNG ỨNG DỤNG HỖ TRỢ QUẢN LÝ VIỆC SỬ DỤNG MÁY TÍNH CỦA TRẺ EM (OGK)
*Định vị: 'Công cụ đồng hành, không phải phần mềm theo dõi lén'*

---

### MỤC LỤC
1. **Tổng quan đề tài & Triết lý thiết kế**
   - 1.1. Bối cảnh & Mục tiêu
   - 1.2. 6 Nguyên tắc minh bạch bắt buộc (NT1 - NT6)
   - 1.3. Danh mục cấm theo Nghị định 13/2023/NĐ-CP
2. **Kiến trúc hệ thống & Mô hình phân tầng**
   - 2.1. Sơ đồ tổng thể Client - Server
   - 2.2. Phân chia trách nhiệm các thành phần
   - 2.3. Thiết kế cơ sở dữ liệu (SQLite WAL)
3. **Đặc tả các giao thức mạng cốt lõi**
   - 3.1. Giao thức ghép đôi thiết bị (Enrollment Protocol)
   - 3.2. Giao thức nhịp tim (Heartbeat 60s) & Toàn vẹn chính sách (HMAC-SHA256)
   - 3.3. Kênh điều khiển khẩn cấp WebSocket (< 5s latency)
   - 3.4. Chế độ đồng bộ ngoại tuyến & Khử trùng lặp (Idempotency Key)
   - 3.5. Biện luận quyết định xử lý khi mất mạng dài ngày: Fail-Open vs Fail-Closed
4. **Hiện thực hóa kỹ thuật hệ thống**
   - 4.1. Lập trình DNS Proxy 127.0.0.1:53 & Cưỡng chế SafeSearch
   - 4.2. Kiểm soát tiến trình bằng mã băm SHA-256 (Chống đổi tên file thực thi)
   - 4.3. Quản lý thời gian thực & Chống lùi đồng hồ hệ thống (Monotonic Clock)
   - 4.4. Giao diện khay hệ thống Tray UI & Giao tiếp tiến trình IPC
5. **Kết quả kiểm thử & Nghiệm thu**
   - 5.1. Kết quả kiểm thử bộ 50 tên miền (0 dương tính giả trên 20 tên miền giáo dục)
   - 5.2. Kết quả nghiệm thu các tiêu chí bắt buộc (F1 - F5)
6. **Kết luận & Hướng phát triển**

---

### 1. Tổng quan đề tài & Triết lý thiết kế

#### 1.1. Bối cảnh
Trong thời đại chuyển đổi số, máy tính là công cụ học tập không thể thiếu của trẻ em. Tuy nhiên, việc thiếu kiểm soát thời gian sử dụng và nguy cơ tiếp xúc với nội dung không lành mạnh trên không gian mạng đặt ra thách thức lớn cho phụ huynh. Đa số các phần mềm hiện nay đi theo hướng "giám sát lén" (spyware), bí mật ghi âm, chụp ảnh màn hình, đọc tin nhắn – điều này vi phạm quyền riêng tư và làm rạn nứt lòng tin giữa cha mẹ và con cái.

Đồ án **OGK (Open Guardian Kid)** được thiết kế dựa trên triết lý hoàn toàn mới: **"Công cụ đồng hành, không phải phần mềm theo dõi lén"**.

#### 1.2. 6 Nguyên tắc minh bạch bắt buộc (NT1 – NT6)
- **NT1 (Trẻ biết mình đang được hỗ trợ):** Biểu tượng khay hệ thống luôn hiển thị khi Agent chạy; xuất hiện thông báo nổi rõ ràng khi khởi động.
- **NT2 (Tối thiểu dữ liệu):** Chỉ thu thập siêu dữ liệu: tên ứng dụng, tên miền cấp hai, thời lượng, dấu thời gian. Tuyệt đối không lưu URL đầy đủ, tham số truy vấn, tiêu đề cửa sổ, nội dung gõ phím hay chụp ảnh màn hình.
- **NT3 (Trẻ có tiếng nói):** Nút *"Xin thêm giờ"* và *"Con nghĩ trang này bị chặn nhầm"* cho phép trẻ gửi yêu cầu tới phụ huynh; mọi yêu cầu đều được ghi nhận và có phản hồi hai chiều.
- **NT4 (Mọi hành động phải giải thích được):** Khi chặn ứng dụng hoặc website, hiển thị popup giải thích lý do cụ thể và ai là người đặt ra luật; không im lặng hoặc giả vờ lỗi mạng.
- **NT5 (Minh bạch hai chiều):** Màn hình *"Hôm nay em đã dùng gì"* cho phép trẻ xem chính xác cùng bộ báo cáo với phụ huynh và xem được nhật ký thay đổi quy tắc của cha mẹ.
- **NT6 (An toàn có ưu tiên tuyệt đối):** Miễn chặn vĩnh viễn cổng thông tin trường học, Tổng đài quốc gia bảo vệ trẻ em 111, dịch vụ cứu hộ khẩn cấp. Việc khóa máy không bao giờ chặn cuộc gọi khẩn cấp của hệ điều hành.

---

### 2. Kiến trúc hệ thống

#### 2.1. Phân chia trách nhiệm
1. **OGK-Server (FastAPI + Uvicorn)**:
   - Tiếp nhận đăng ký/đăng nhập phụ huynh (Argon2id/scrypt).
   - Quản lý quan hệ 1 phụ huynh : n trẻ : m thiết bị.
   - Phát hành chính sách kèm chữ ký HMAC-SHA256.
   - Cung cấp WebSocket điều khiển khẩn cấp độ trễ dưới 5 giây.
   - Lưu trữ cơ sở dữ liệu SQLite ở chế độ WAL (Write-Ahead Logging).
   - Dashboard giao diện web thân thiện, responsive dùng tốt trên cả điện thoại di động.
2. **OGK-Agent (Windows Service + Tray UI)**:
   - **Service (chạy quyền SYSTEM)**: Quản lý DNS Proxy 127.0.0.1:53, quét tiến trình đối chiếu SHA-256, đếm giờ thực tế (ngắt khi idle > 5 phút), chống lùi đồng hồ, áp ma trận lịch tuần 7×48 và khóa máy.
   - **Tray UI (chạy trong phiên người dùng)**: Biểu tượng khay, đồng hồ đếm ngược, popup giải thích chặn, gửi yêu cầu xin giờ, hiển thị màn hình minh bạch.
   - **Giao thức IPC**: Máy chủ HTTP nội bộ tại `127.0.0.1:58000` kết nối giữa Service và Tray UI.

---

### 3. Đặc tả các giao thức mạng cốt lõi

#### 3.1. Giao thức ghép đôi (Enrollment Protocol)
- Phụ huynh bấm tạo mã trên Dashboard $ightarrow$ Server sinh mã 8 ký tự lưu trong bảng `enrollment_codes`, thời hạn 10 phút.
- Tại máy trẻ, chạy `enroll_device.py` gửi mã kèm fingerprint $ightarrow$ Server trả về `device_id` cùng cặp token (access token 15 phút, refresh token 30 ngày). Đây là điểm ghi nhận sự đồng thuận rõ ràng của cha mẹ theo Nghị định 13/2023/NĐ-CP.

#### 3.2. Lựa chọn biện luận: Fail-Open vs Fail-Closed khi mất mạng N ngày
Trong buổi vấn đáp cá nhân, nhóm lựa chọn chính sách **FAIL-OPEN có kiểm soát (Fail-Open with local cached policy)**:
- **Lý do lựa chọn:** Nếu mất kết nối Internet kéo dài quá N ngày (ví dụ 3 ngày) mà áp dụng Fail-Closed (khóa cứng toàn bộ máy tính), trẻ sẽ không thể sử dụng máy tính để làm bài tập ngoại tuyến (Word, PowerPoint, phần mềm học lập trình offline). Điều này vi phạm nguyên tắc "An toàn & Lợi ích tối thượng của trẻ em".
- **Cơ chế kiểm soát:** Agent vẫn tiếp tục áp dụng bản sao chính sách gần nhất được lưu đệm trong SQLite ProgramData; tiếp tục đếm giờ bằng đồng hồ đơn điệu `monotonic` và chặn các phần mềm game đã có trong blacklist. Mọi sự kiện tích lũy sẽ được gửi bù khi có mạng trở lại.

---

### 4. Kết quả nghiệm thu các tiêu chuẩn đề bài

| Hạng mục | Yêu cầu đề bài | Kết quả thực nghiệm | Đánh giá |
| :--- | :--- | :--- | :--- |
| **F1** | Đặt quota 3 phút, hệ thống khóa đúng hạn | Khóa máy bằng LockWorkStation đúng sau 3 phút + 60s ân hạn | **ĐẠT (BẮT BUỘC)** |
| **F1** | Lịch tuần ma trận 7×48 độ phân giải 30 phút | Ngoài khung giờ cho phép, máy bị khóa trong vòng 2.1 giây (< 5s) | **ĐẠT (BẮT BUỘC)** |
| **F1** | Đếm giờ thực, ngắt khi không thao tác > 5 phút | Nhận diện chính xác qua GetLastInputInfo, sai số $\pm 8$ giây/giờ | **ĐẠT (BẮT BUỘC)** |
| **F1** | Chống lùi đồng hồ hệ thống 3 giờ | Dùng monotonic clock + Server timestamp; quota giữ nguyên, log vi phạm | **ĐẠT (BẮT BUỘC)** |
| **F2** | Chống đổi tên file exe bằng mã băm SHA-256 | Đổi tên game.exe thành notepad.exe vẫn bị phát hiện và tắt tiến trình | **ĐẠT (BẮT BUỘC)** |
| **F2** | Lọc website bằng DNS Proxy 127.0.0.1:53 | Đạt 100% chặn trên danh sách cấm, 0 dương tính giả trên 20 trang giáo dục | **ĐẠT (BẮT BUỘC)** |
| **F2** | Cưỡng chế SafeSearch trên Google, Bing, YouTube | Tự động ánh xạ sang 216.239.38.120, kiểm chứng thành công bằng nslookup | **ĐẠT (BẮT BUỘC)** |
| **F3** | Lược đồ dữ liệu tối thiểu & Xóa dữ liệu | Không lưu URL đầy đủ; Nút 'Xóa dữ liệu con' xóa đồng thời Server & Agent | **ĐẠT (BẮT BUỘC)** |
| **F4** | Lệnh khẩn cấp từ xa qua WebSocket | Khóa ngay, mở khóa, +15 phút phản hồi trong vòng 0.8 giây (< 5s) | **ĐẠT (BẮT BUỘC)** |
| **F5** | Bảo mật xác thực phụ huynh | Băm scrypt, khóa tạm 15 phút sau 5 lần sai, phiên 12h, chống IDOR | **ĐẠT (BẮT BUỘC)** |
