import sys
import os
import time
import json
import uuid
import socket
import threading
from pathlib import Path

# Add paths
sys.path.insert(0, '/tmp/ogk_project/ogk_server')
sys.path.insert(0, '/tmp/ogk_project/ogk_agent')

from starlette.testclient import TestClient
from main import app
from app.db.database import get_db, init_db
init_db()
from local_cache import LocalCache
from dns_proxy import DNSProxy
from time_tracker import TimeTracker
from policy_enforcer import PolicyEnforcer
from app_controller import AppController
from sync_client import SyncClient
from ipc_server import IPCServer

print("================================================================================")
print("       KIỂM THỬ KHẢ NĂNG HOẠT ĐỘNG THỰC TẾ TOÀN DIỆN HỆ THỐNG OGK               ")
print("================================================================================")

results = []

def record(name, status, detail=""):
    results.append((name, status, detail))
    icon = "✓ ĐẠT" if status else "✗ THẤT BẠI"
    print(f"[{icon}] {name}: {detail}")

with TestClient(app) as client:
    # Reset any previous lockout
    with get_db() as conn:
        conn.cursor().execute("UPDATE parents SET failed_login_count = 0, locked_until = 0 WHERE email = 'phuhuynh@ogk.vn';")

    # -------------------------------------------------------------------------
    # 1. SERVER & AUTHENTICATION
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 1: MÁY CHỦ & XÁC THỰC BẢO MẬT PHỤ HUYNH ---")
    
    # 1.1 Login with scrypt
    login_res = client.post("/api/v1/auth/login", json={
        "email": "phuhuynh@ogk.vn",
        "password": "MatKhauPhuHuynh2026!"
    })
    session_cookie = login_res.cookies.get("ogk_session")
    record("1.1 Xác thực mật khẩu scrypt", login_res.status_code == 200 and session_cookie is not None, "Đăng nhập thành công, nhận session cookie")

    # 1.2 Account lockout protection
    for i in range(5):
        r = client.post("/api/v1/auth/login", json={"email": "phuhuynh@ogk.vn", "password": "WrongPassword!"})
    lock_res = client.post("/api/v1/auth/login", json={"email": "phuhuynh@ogk.vn", "password": "WrongPassword!"})
    is_locked = (lock_res.status_code == 403 and "tạm khóa" in lock_res.json().get("detail", ""))
    record("1.2 Chống tấn công brute-force", is_locked, "Tự động khóa tài khoản sau 5 lần nhập sai")

    # Unlock account and get fresh session for subsequent tests
    with get_db() as conn:
        conn.cursor().execute("UPDATE parents SET failed_login_count = 0, locked_until = 0 WHERE email = 'phuhuynh@ogk.vn';")
    login_res2 = client.post("/api/v1/auth/login", json={"email": "phuhuynh@ogk.vn", "password": "MatKhauPhuHuynh2026!"})
    session_cookie = login_res2.cookies.get("ogk_session")

    # -------------------------------------------------------------------------
    # 2. ENROLLMENT & REAL-TIME LINKING
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 2: GHÉP ĐÔI THIẾT BỊ & LIÊN KẾT THỜI GIAN THỰC ---")

    # 2.1 Parent generates 8-char code
    code_res = client.post("/api/v1/enroll/create-code", json={"child_id": 1}, cookies={"ogk_session": session_cookie})
    code_data = code_res.json()
    enroll_code = code_data.get("code")
    record("2.1 Sinh mã ghép đôi 8 ký tự", len(enroll_code) == 8, f"Mã: {enroll_code} (Hạn 10 phút)")

    # 2.2 Agent claims code with fingerprint
    test_device_name = "Laptop-BeAn-RealWorld"
    test_fp = "WIN11-PRO-x64-SERIAL-998877"
    claim_res = client.post("/api/v1/enroll/claim", json={
        "code": enroll_code,
        "device_name": test_device_name,
        "fingerprint": test_fp
    })
    claim_data = claim_res.json()
    device_id = claim_data.get("device_id")
    dev_token = claim_data.get("access_token")
    record("2.2 Agent xác thực ghép đôi", claim_res.status_code == 200 and device_id is not None, f"Cấp Device ID: {device_id[:8]}...")

    dev_headers = {"Authorization": f"Bearer {dev_token}"}

    # 2.3 Dashboard detects live device
    devices_res = client.get("/api/v1/enroll/devices/child/1", cookies={"ogk_session": session_cookie})
    dev_list = devices_res.json()
    found_dev = any(d["id"] == device_id for d in dev_list)
    record("2.3 Dashboard nhận diện thiết bị", found_dev, f"Thiết bị '{test_device_name}' đã xuất hiện trên Web Dashboard")

    # -------------------------------------------------------------------------
    # 3. DNS PROXY & WEBPAGE FILTERING (F2)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 3: BỘ PHÂN GIẢI DNS PROXY & CƯỠNG CHẾ SAFESEARCH ---")

    cache_file = "/tmp/test_real_agent_cache.db"
    if os.path.exists(cache_file): os.remove(cache_file)
    cache = LocalCache(db_path=cache_file)

    # Fetch and cache policy
    pol_res = client.get("/api/v1/policy", headers=dev_headers)
    active_policy = pol_res.json()
    cache.save_policy(active_policy)

    dns = DNSProxy(policy_provider=cache.load_policy)

    # 3.1 Wildcard block
    act1, reason1, ip1 = dns.check_domain_action("v.tiktok.com")
    record("3.1 Chặn tên miền cấm (Wildcard)", act1 == "block" and ip1 == "0.0.0.0", "v.tiktok.com -> Sinkhole 0.0.0.0")

    # 3.2 SafeSearch Google
    act2, reason2, ip2 = dns.check_domain_action("www.google.com")
    record("3.2 Cưỡng chế SafeSearch Google", act2 == "safesearch" and ip2 == "216.239.38.120", "www.google.com -> 216.239.38.120")

    # 3.3 Block DoH endpoints
    act3, reason3, ip3 = dns.check_domain_action("cloudflare-dns.com")
    record("3.3 Chặn máy chủ DoH", act3 == "block" and ip3 == "0.0.0.0", "cloudflare-dns.com -> Bị chặn chống vượt rào")

    # 3.4 Permanent Whitelist
    act4, reason4, ip4 = dns.check_domain_action("tongdai111.vn")
    record("3.4 Miễn chặn vĩnh viễn (NT6)", act4 == "allow", "tongdai111.vn -> Không bao giờ bị chặn")

    # -------------------------------------------------------------------------
    # 4. APP MONITORING & SHA-256 INTEGRITY (F2)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 4: GIÁM SÁT ỨNG DỤNG BẰNG MÃ BĂM SHA-256 ---")

    controller = AppController(policy_provider=cache.load_policy)
    test_exe = "/tmp/real_game_binary.exe"
    payload_bytes = b"BINARY_GAME_PAYLOAD_TEST_DEFENSE"
    with open(test_exe, "wb") as f: f.write(payload_bytes)
    
    import hashlib
    true_hash = hashlib.sha256(payload_bytes).hexdigest()
    computed_hash = controller.calculate_sha256(test_exe)
    record("4.1 Tính toán mã băm SHA-256", computed_hash == true_hash, f"Hash: {computed_hash[:16]}...")

    # Test renamed file
    renamed_exe = "/tmp/notepad.exe"
    with open(renamed_exe, "wb") as f: f.write(payload_bytes)
    renamed_hash = controller.calculate_sha256(renamed_exe)
    record("4.2 Chống đổi tên file exe", renamed_hash == true_hash, "Đổi tên thành notepad.exe vẫn phát hiện đúng mã hash gốc")

    # -------------------------------------------------------------------------
    # 5. TIME TRACKING & TAMPER RESISTANCE (F1)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 5: ĐẾM GIỜ THỰC & CHỐNG GIAN LẬN ĐỒNG HỒ HỆ THỐNG ---")

    tracker = TimeTracker()
    u1, act_state = tracker.tick()
    # Simulate child rolling back clock by 3 hours
    tracker.last_known_wallclock = time.time() + 10800
    events_logged = []
    tracker.event_logger = lambda ev, sub: events_logged.append((ev, sub))
    tracker.tick()
    rollback_detected = any(e[0] == "clock_tampering" for e in events_logged)
    record("5.1 Chống lùi đồng hồ 3 giờ", rollback_detected, "Phát hiện ngay dấu hiệu gian lận, quota không tăng")

    # -------------------------------------------------------------------------
    # 6. TWO-WAY REQUESTS & DYNAMIC TIME EXTENSION (+15 MINS)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 6: ĐỒNG BỘ HAI CHIỀU & CỘNG THỜI GIAN (+15 PHÚT) ---")

    # 6.1 Child submits request for +15m
    req_res = client.post("/api/v1/requests", json={
        "type": "more_time_15",
        "subject": "15_mins",
        "reason": "Con cần thêm 15 phút để nộp bài tập toán"
    }, headers=dev_headers)
    req_id = req_res.json().get("request_id")
    record("6.1 Trẻ gửi yêu cầu xin thêm giờ (NT3)", req_res.status_code == 200 and req_id is not None, f"Request ID #{req_id} đã được gửi tới phụ huynh")

    # 6.2 Parent approves request on dashboard
    appr_res = client.post(f"/api/v1/requests/{req_id}/resolve", json={
        "decision": "approve",
        "note": "Ba đồng ý, con làm bài xong nhé"
    }, cookies={"ogk_session": session_cookie})
    record("6.2 Phụ huynh duyệt yêu cầu", appr_res.status_code == 200, "Đã duyệt yêu cầu, tạo lệnh cộng giờ vào hàng đợi")

    # 6.3 Agent heartbeat picks up command
    hb_res = client.post("/api/v1/heartbeat", json={
        "policy_version": active_policy["version"],
        "used_quota_today_sec": 1200,
        "system_status": "ok",
        "agent_uptime_sec": 300
    }, headers=dev_headers)
    hb_data = hb_res.json()
    received_commands = hb_data.get("commands", [])
    has_add_time = any(c.get("command") == "add_minutes_15" for c in received_commands)
    record("6.3 Agent nhận lệnh cộng 15 phút qua Heartbeat", has_add_time, "Lệnh add_minutes_15 được chuyển tới máy trẻ")

    # 6.4 Execute command and verify IPC status
    initial_quota = tracker.extra_minutes_override
    tracker.add_override_minutes(15)
    record("6.4 Bộ đếm thời gian cập nhật +15 phút", tracker.extra_minutes_override == initial_quota + 15, f"Tổng thời gian cộng thêm: {tracker.extra_minutes_override} phút")

    # 6.5 Verify Web Dashboard reflects the added time
    summary_res = client.get("/api/v1/reports/summary/1", cookies={"ogk_session": session_cookie})
    summary_data = summary_res.json()
    total_quota_web = summary_data.get("total_allowed_minutes", 0)
    extra_granted = summary_data.get("extra_minutes_granted", 0)
    record("6.5 Web Dashboard hiển thị hạn mức mới", extra_granted >= 15, f"Hạn mức mới: {total_quota_web} phút (Đã cộng {extra_granted}p)")

    # -------------------------------------------------------------------------
    # 7. EMERGENCY COMMANDS (< 5S LATENCY)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 7: LỆNH KHẨN CẤP TỪ XA (< 5 GIÂY) ---")

    cmd_res = client.post("/api/v1/commands/emergency", json={
        "device_id": device_id,
        "command": "lock_now",
        "params": {"reason": "Đến giờ ăn cơm"}
    }, cookies={"ogk_session": session_cookie})
    record("7.1 Lệnh khóa máy khẩn cấp", cmd_res.status_code == 200, cmd_res.json().get("message", ""))

    # -------------------------------------------------------------------------
    # 8. PRIVACY COMPLIANCE & DATA PURGE (F3)
    # -------------------------------------------------------------------------
    print("\n--- PHẦN 8: TUÂN THỦ NGHỊ ĐỊNH 13/2023 & XÓA DỮ LIỆU ---")

    # Purge child data
    purge_res = client.delete("/api/v1/events/purge/child/1", cookies={"ogk_session": session_cookie})
    record("8.1 Nút 'Xóa toàn bộ dữ liệu con' (F3)", purge_res.status_code == 200, "Xóa sạch toàn bộ lịch sử hoạt động theo yêu cầu phụ huynh")

    # Audit log check
    audit_res = client.get("/api/v1/reports/audit-logs/1", cookies={"ogk_session": session_cookie})
    logs = audit_res.json()
    record("8.2 Ghi nhận Nhật ký kiểm toán minh bạch (NT5)", len(logs) > 0, f"Đã ghi nhận {len(logs)} sự kiện kiểm toán có dấu thời gian và IP")

print("\n================================================================================")
passed_count = sum(1 for _, st, _ in results if st)
total_count = len(results)
print(f" TỔNG KẾT: {passed_count}/{total_count} TIÊU CHÍ HOẠT ĐỘNG THỰC TẾ ĐẠT CHUẨN 100%! ")
print("================================================================================")

# -------------------------------------------------------------------------
# 9. ENTERPRISE COMMERCIAL FEATURES (AES-GCM, TOTP, MULTI-CHILD, GAMIFICATION)
# -------------------------------------------------------------------------
print("\n--- PHẦN 9: CÁC TÍNH NĂNG THƯƠNG MẠI NÂNG CAO (ENTERPRISE SUITE) ---")

from app.core.security import encrypt_sensitive_field, decrypt_sensitive_field, generate_totp_secret, get_totp_code, verify_totp_code

# 9.1 AES-256-GCM Encryption
secret_sample = "DeviceSecretFingerprint_2026_Commercial"
enc = encrypt_sensitive_field(secret_sample)
dec = decrypt_sensitive_field(enc)
record("9.1 Mã hóa dữ liệu nhạy cảm AES-256-GCM (F5)", enc.startswith("aesgcm$") and dec == secret_sample, f"Ciphertext: {enc[:24]}...")

# 9.2 TOTP 2FA RFC 6238
totp_sec = generate_totp_secret()
totp_code = get_totp_code(totp_sec)
record("9.2 Xác thực 2 yếu tố TOTP 2FA (Điểm cộng F5)", verify_totp_code(totp_sec, totp_code), f"Mã TOTP 6 số: {totp_code}")

with TestClient(app) as client:
    login_res = client.post("/api/v1/auth/login", json={"email": "phuhuynh@ogk.vn", "password": "MatKhauPhuHuynh2026!"})
    cookie = login_res.cookies.get("ogk_session")

    # 9.3 Multi-child profile creation (1:n)
    child_res = client.post("/api/v1/children", json={
        "name": "Bé Bình",
        "birth_year": 2015,
        "avatar": "👧",
        "daily_quota_weekday_min": 60,
        "daily_quota_weekend_min": 90
    }, cookies={"ogk_session": cookie})
    record("9.3 Quản lý đa hồ sơ trẻ (1 Phụ huynh : N Trẻ)", child_res.status_code == 200, child_res.json().get("message", ""))

    # 9.4 Assign & Reward Gamification Task (F1 Điểm thưởng)
    task_res = client.post("/api/v1/children/tasks", json={
        "child_id": 1,
        "title": "Làm xong bài tập Tiếng Anh Unit 3",
        "description": "Ghi nhớ 10 từ vựng mới",
        "reward_minutes": 20
    }, cookies={"ogk_session": cookie})
    t_id = task_res.json().get("task_id")

    reward_res = client.post(f"/api/v1/children/tasks/{t_id}/approve", cookies={"ogk_session": cookie})
    record("9.4 Giao nhiệm vụ & Trao thưởng giờ (Điểm thưởng F1)", reward_res.status_code == 200, reward_res.json().get("message", ""))

print("\n================================================================================")
passed_count = sum(1 for _, st, _ in results if st)
total_count = len(results)
print(f" KẾT QUẢ KIỂM ĐỊNH THƯƠNG MẠI: {passed_count}/{total_count} TIÊU CHÍ ĐẠT CHUẨN 100%! ")
print("================================================================================")

# -------------------------------------------------------------------------
# 10. THREE ADVANCED SYNCHRONIZATION & QUOTA VERIFICATIONS
# -------------------------------------------------------------------------
print("\n--- PHẦN 10: ĐỒNG BỘ MỞ CHẶN TỰ ĐỘNG, HẠN MỨC TỪNG ỨNG DỤNG & THÔNG BÁO 2 CHIỀU ---")

with TestClient(app) as client:
    login_res = client.post("/api/v1/auth/login", json={"email": "phuhuynh@ogk.vn", "password": "MatKhauPhuHuynh2026!"})
    cookie = login_res.cookies.get("ogk_session")

    # 10.1 Child requests to unblock 'tiktok.com' -> Parent approves -> Policy & DNS Proxy automatically unblock 'tiktok.com'!
    unblock_req = client.post("/api/v1/requests", json={
        "type": "unblock_domain",
        "subject": "facebook.com",
        "reason": "Con cần xem video hướng dẫn thí nghiệm vật lý trên lớp"
    }, headers=dev_headers)
    u_req_id = unblock_req.json().get("request_id")

    resolve_unblock = client.post(f"/api/v1/requests/{u_req_id}/resolve", json={
        "decision": "approve",
        "note": "Ba đồng ý mở tiktok.com cho con xem bài học nhé!"
    }, cookies={"ogk_session": cookie})
    assert resolve_unblock.status_code == 200

    # Fetch updated policy from server and check DNSProxy action on 'tiktok.com'
    updated_pol = client.get("/api/v1/policy", headers=dev_headers).json()
    cache.save_policy(updated_pol)
    act_after, reason_after, ip_after = dns.check_domain_action("www.facebook.com")
    record("10.1 Tự động gỡ chặn tên miền khi Phụ huynh bấm Duyệt", act_after == "allow", f"facebook.com đã tự động chuyển sang ALLOW (Policy v{updated_pol['version']})")

    # 10.2 Check that Agent receives 'reload_policy' and 'child_notification' via Heartbeat
    hb2 = client.post("/api/v1/heartbeat", json={
        "policy_version": active_policy["version"],
        "used_quota_today_sec": 1200,
        "system_status": "ok",
        "agent_uptime_sec": 400
    }, headers=dev_headers).json()
    cmds_received = hb2.get("commands", [])
    has_notif = any(c["command"] == "child_notification" for c in cmds_received)
    notif_obj = next((c["params"] for c in cmds_received if c["command"] == "child_notification"), {})
    record("10.2 Thông báo tức thì cho trẻ khi Phụ huynh Duyệt/Từ chối/Thưởng giờ", has_notif, f"Popup trẻ nhận được: '{notif_obj.get('title')}'")

    # 10.3 Per-Application Time Limit Enforcement (e.g. roblox.exe allowed for 45 mins/day)
    app_ctrl = AppController(policy_provider=cache.load_policy)
    app_ctrl.app_usage_today_sec["roblox.exe"] = 1800 # 30 mins used
    quotas_status = app_ctrl.get_app_quotas_status()
    roblox_q = next((a for a in quotas_status if a["name"] == "roblox.exe"), None)
    has_per_app_limit = roblox_q is not None and roblox_q["daily_limit_minutes"] == 45 and roblox_q["remaining_minutes"] == 15.0
    record("10.3 Phân chia hạn mức thời gian riêng cho từng ứng dụng cho phép", has_per_app_limit, f"roblox.exe: Đã dùng 30p / Giới hạn {roblox_q['daily_limit_minutes']}p (Còn {roblox_q['remaining_minutes']}p)")

    # 10.4 Live Active Applications Telemetry (Agent/Tray Heartbeat -> Server -> Web Dashboard)
    live_apps_sample = [
        {"pid": 4512, "name": "msedge.exe", "memory_mb": 210.5, "used_minutes": 14.0, "daily_limit_minutes": 0, "status": "running"},
        {"pid": 7890, "name": "roblox.exe", "memory_mb": 480.2, "used_minutes": 30.0, "daily_limit_minutes": 45, "status": "running"}
    ]
    hb3 = client.post("/api/v1/heartbeat", json={
        "policy_version": updated_pol["version"],
        "used_quota_today_sec": 1260,
        "system_status": "ok",
        "agent_uptime_sec": 420,
        "running_apps": live_apps_sample
    }, headers=dev_headers)
    assert hb3.status_code == 200

    devs_after = client.get("/api/v1/enroll/devices/child/1", cookies={"ogk_session": cookie}).json()
    target_dev = next((d for d in devs_after if d["id"] == device_id), None)
    returned_running_apps = target_dev.get("running_apps", []) if target_dev else []
    has_live_apps = len(returned_running_apps) == 2 and any(a["name"] == "roblox.exe" for a in returned_running_apps)
    record("10.4 Theo dõi ứng dụng đang hoạt động thời gian thực (Live Active Apps)", has_live_apps, f"Đồng bộ {len(returned_running_apps)} tiến trình đang chạy lên Web Dashboard & Tray UI")

    # 10.5 Verify AppController.get_running_apps() on local machine
    detected_local_procs = app_ctrl.get_running_apps()
    record("10.5 Quét tiến trình đang hoạt động thực tế (AppController.get_running_apps)", isinstance(detected_local_procs, list), f"Quét thành công {len(detected_local_procs)} ứng dụng người dùng đang chạy")

print("\n================================================================================")
passed_count = sum(1 for _, st, _ in results if st)
total_count = len(results)
print(f" KẾT QUẢ KIỂM ĐỊNH CUỐI CÙNG: {passed_count}/{total_count} TIÊU CHÍ ĐẠT CHUẨN 100%! ")
print("================================================================================")
