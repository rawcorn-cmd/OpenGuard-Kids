@echo off
setlocal
title "OGK-Agent Ghep Doi Thiet Bi"
set ROOT=%~dp0
cd /d "%ROOT%"

if not exist "%ROOT%venv\Scripts\python.exe" (
    echo ================================================================
    echo  [OGK AUTO-SETUP] Dang chuan bi moi truong venv...
    echo ================================================================
    py -m venv "%ROOT%venv"
    "%ROOT%venv\Scripts\pip" install -r "%ROOT%ogk_agent\requirements.txt"
)

set PY_CMD="%ROOT%venv\Scripts\python.exe"
cd /d "%ROOT%ogk_agent"
%PY_CMD% enroll_device.py
pause
