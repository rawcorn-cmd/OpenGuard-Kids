import sys
import os
import subprocess
import logging

logger = logging.getLogger("OGK-DNSConfig")

HOSTS_FILE = r"C:\Windows\System32\drivers\etc\hosts" if sys.platform == "win32" else "/etc/hosts"
MARKER_START = "# --- OGK GUARDIAN BLOCKLIST START ---"
MARKER_END = "# --- OGK GUARDIAN BLOCKLIST END ---"

def set_windows_dns_loopback():
    """Sets primary active network adapter DNS to 127.0.0.1 (OGK DNS Proxy)."""
    if sys.platform != "win32":
        return
    try:
        cmd = 'powershell -Command "Get-NetAdapter | Where-Object Status -eq Up | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses (\"127.0.0.1\", \"1.1.1.1\") }"'
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logger.info("Configured Windows DNS adapter to 127.0.0.1")
        flush_dns_cache()
    except Exception as e:
        logger.warning(f"Could not configure network adapter DNS (requires Administrator): {e}")

def restore_windows_dns_dhcp():
    """Restores primary network adapter DNS back to automatic DHCP."""
    if sys.platform != "win32":
        return
    try:
        cmd = 'powershell -Command "Get-NetAdapter | Where-Object Status -eq Up | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }"'
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logger.info("Restored Windows DNS adapter to automatic DHCP")
        flush_dns_cache()
    except Exception as e:
        logger.warning(f"Could not restore DNS to DHCP: {e}")

def flush_dns_cache():
    """Flushes Windows DNS resolver cache so blocked sites take effect immediately."""
    if sys.platform != "win32":
        return
    try:
        subprocess.run("ipconfig /flushdns", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logger.info("Flushed Windows DNS resolver cache (ipconfig /flushdns)")
    except Exception:
        pass

def update_windows_hosts_blocklist(blocked_domains: list):
    """
    Dual-layer defense: Enforces domain blocking in Windows hosts file.
    Guarantees that ANY browser (Chrome, Edge, Firefox, Brave) blocks the site
    even if browser has internal DNS caching or uses Secure DNS (DoH).
    """
    if sys.platform != "win32" or not os.path.exists(HOSTS_FILE):
        return

    try:
        with open(HOSTS_FILE, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        # Remove previous OGK blocklist section if present
        if MARKER_START in content and MARKER_END in content:
            pre = content.split(MARKER_START)[0]
            post = content.split(MARKER_END)[1]
            content = pre.rstrip() + "\n" + post.lstrip()

        # Build new blocklist section
        block_lines = [MARKER_START]
        for dom in blocked_domains:
            clean_dom = dom.strip().lower().lstrip("*.")
            if clean_dom:
                block_lines.append(f"0.0.0.0 {clean_dom}")
                block_lines.append(f"0.0.0.0 www.{clean_dom}")
        block_lines.append(MARKER_END)

        new_content = content.rstrip() + "\n\n" + "\n".join(block_lines) + "\n"

        with open(HOSTS_FILE, "w", encoding="utf-8") as f:
            f.write(new_content)

        logger.info(f"Updated Windows hosts file with {len(blocked_domains)} blocked domains.")
        flush_dns_cache()
    except Exception as e:
        logger.warning(f"Could not update hosts file (requires Administrator): {e}")

def clean_windows_hosts_blocklist():
    """Removes OGK blocklist section from Windows hosts file upon agent exit."""
    if sys.platform != "win32" or not os.path.exists(HOSTS_FILE):
        return

    try:
        with open(HOSTS_FILE, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        if MARKER_START in content and MARKER_END in content:
            pre = content.split(MARKER_START)[0]
            post = content.split(MARKER_END)[1]
            clean_content = pre.rstrip() + "\n" + post.lstrip()
            with open(HOSTS_FILE, "w", encoding="utf-8") as f:
                f.write(clean_content)
            logger.info("Cleaned up Windows hosts file blocklist section.")
            flush_dns_cache()
    except Exception as e:
        logger.warning(f"Could not clean hosts file: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "restore":
        restore_windows_dns_dhcp()
        clean_windows_hosts_blocklist()
    else:
        set_windows_dns_loopback()


def kill_browser_active_connections():
    if sys.platform != "win32":
        return
    try:
        subprocess.run("ipconfig /flushdns", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run("nbtstat -R", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
