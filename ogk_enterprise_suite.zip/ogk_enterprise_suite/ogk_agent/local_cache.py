import sqlite3
import json
import time
import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from config import CACHE_DB_PATH, DEVICE_CONFIG_PATH

class LocalCache:
    def __init__(self, db_path=CACHE_DB_PATH):
        self.db_path = str(db_path)
        # Ensure parent directory exists
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
        except Exception:
            pass # fallback to standard journal if WAL not supported
        return conn

    def _init_db(self):
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS local_policy (
                    child_id INTEGER PRIMARY KEY,
                    version INTEGER,
                    daily_quota_weekday_sec INTEGER,
                    daily_quota_weekend_sec INTEGER,
                    schedule_matrix_json TEXT,
                    app_rules_json TEXT,
                    domain_rules_json TEXT,
                    safe_search_enabled INTEGER,
                    doh_blocked INTEGER,
                    hmac_signature TEXT,
                    synced_at INTEGER
                );
                ''')

                cursor.execute('''
                CREATE TABLE IF NOT EXISTS event_queue (
                    idempotency_key TEXT PRIMARY KEY,
                    ts INTEGER,
                    type TEXT,
                    subject TEXT,
                    duration_sec INTEGER,
                    policy_id INTEGER,
                    synced INTEGER DEFAULT 0
                );
                ''')
        except Exception as e:
            print(f"[Warning] Could not initialize local cache table: {e}")

    def save_device_credentials(self, device_id: str, child_id: int, access_token: str, refresh_token: str, child_name: str = "Bé An", device_name: str = "PC"):
        data = {
            "device_id": device_id,
            "child_id": child_id,
            "child_name": child_name,
            "device_name": device_name,
            "access_token": access_token,
            "refresh_token": refresh_token,
            "extra_override_minutes": 0,
            "enrolled_at": int(time.time())
        }
        with open(DEVICE_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def load_device_credentials(self) -> Optional[Dict[str, Any]]:
        # 1. Check local project config
        if DEVICE_CONFIG_PATH.exists():
            try:
                with open(DEVICE_CONFIG_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass

        # 2. Fallback to ProgramData if exists
        if sys.platform == "win32":
            prog_data_file = Path(os.getenv("ALLUSERSPROFILE", "C:\\ProgramData")) / "OGK-Agent" / "device_config.json"
            if prog_data_file.exists():
                try:
                    with open(prog_data_file, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    pass
        return None

    def save_policy(self, policy: Dict[str, Any]):
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT OR REPLACE INTO local_policy (
                    child_id, version, daily_quota_weekday_sec, daily_quota_weekend_sec,
                    schedule_matrix_json, app_rules_json, domain_rules_json,
                    safe_search_enabled, doh_blocked, hmac_signature, synced_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                ''', (
                    policy["child_id"],
                    policy["version"],
                    policy["daily_quota_weekday_sec"],
                    policy["daily_quota_weekend_sec"],
                    json.dumps(policy["schedule_matrix"]),
                    json.dumps(policy["app_rules"], ensure_ascii=False),
                    json.dumps(policy["domain_rules"], ensure_ascii=False),
                    int(policy["safe_search_enabled"]),
                    int(policy["doh_blocked"]),
                    policy.get("hmac_signature", ""),
                    int(time.time())
                ))
        except Exception as e:
            print(f"[Warning] Could not save policy locally: {e}")

    def load_policy(self) -> Optional[Dict[str, Any]]:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM local_policy ORDER BY synced_at DESC LIMIT 1;")
                row = cursor.fetchone()
                if not row:
                    return None
                return {
                    "child_id": row["child_id"],
                    "version": row["version"],
                    "daily_quota_weekday_sec": row["daily_quota_weekday_sec"],
                    "daily_quota_weekend_sec": row["daily_quota_weekend_sec"],
                    "schedule_matrix": json.loads(row["schedule_matrix_json"]),
                    "app_rules": json.loads(row["app_rules_json"]),
                    "domain_rules": json.loads(row["domain_rules_json"]),
                    "safe_search_enabled": bool(row["safe_search_enabled"]),
                    "doh_blocked": bool(row["doh_blocked"]),
                    "hmac_signature": row["hmac_signature"]
                }
        except Exception:
            return None

    def queue_event(self, event_type: str, subject: str, duration_sec: int = 0, policy_id: int = 1) -> str:
        import uuid
        key = str(uuid.uuid4())
        now = int(time.time())
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                INSERT INTO event_queue (idempotency_key, ts, type, subject, duration_sec, policy_id, synced)
                VALUES (?, ?, ?, ?, ?, ?, 0);
                ''', (key, now, event_type, subject, duration_sec, policy_id))
        except Exception:
            pass
        return key

    def get_unsynced_events(self, limit: int = 100) -> List[Dict[str, Any]]:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                SELECT idempotency_key, ts, type, subject, duration_sec, policy_id
                FROM event_queue WHERE synced = 0 ORDER BY ts ASC LIMIT ?;
                ''', (limit,))
                return [dict(r) for r in cursor.fetchall()]
        except Exception:
            return []

    def mark_events_synced(self, idempotency_keys: List[str]):
        if not idempotency_keys:
            return
        placeholders = ",".join("?" * len(idempotency_keys))
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute(f"UPDATE event_queue SET synced = 1 WHERE idempotency_key IN ({placeholders});", idempotency_keys)
        except Exception:
            pass
