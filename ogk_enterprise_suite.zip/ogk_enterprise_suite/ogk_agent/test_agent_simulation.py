import time
import os
import hashlib
from local_cache import LocalCache
from dns_proxy import DNSProxy
from time_tracker import TimeTracker
from policy_enforcer import PolicyEnforcer
from app_controller import AppController

print('--- 1. Testing Local Cache & Offline Queue ---')
if os.path.exists('/tmp/test_agent_cache.db'): os.remove('/tmp/test_agent_cache.db')
cache = LocalCache(db_path='/tmp/test_agent_cache.db')
sample_policy = {
    'child_id': 1,
    'version': 2,
    'daily_quota_weekday_sec': 5400,
    'daily_quota_weekend_sec': 7200,
    'schedule_matrix': [[1]*48 for _ in range(7)],
    'app_rules': [{'name': 'game.exe', 'sha256': 'fakehash123', 'action': 'block', 'reason': 'Chơi game quá giờ'}],
    'domain_rules': [{'domain': 'tiktok.com', 'action': 'block', 'category': 'social'}],
    'safe_search_enabled': True,
    'doh_blocked': True,
    'hmac_signature': 'mock_sig_123'
}
cache.save_policy(sample_policy)
loaded = cache.load_policy()
assert loaded['version'] == 2
print('Policy successfully saved and loaded from SQLite cache!')

ev_key = cache.queue_event('app_start', 'zoom.exe', 1200)
unsynced = cache.get_unsynced_events()
assert len(unsynced) == 1
assert unsynced[0]['idempotency_key'] == ev_key
cache.mark_events_synced([ev_key])
assert len(cache.get_unsynced_events()) == 0
print('Offline event queue & idempotency key test passed!')

print('--- 2. Testing DNS Proxy Domain Matching & SafeSearch ---')
dns = DNSProxy(policy_provider=lambda: loaded)

act, reason, ip = dns.check_domain_action('tongdai111.vn')
assert act == 'allow' and 'Miễn chặn vĩnh viễn' in reason
print('Permanent whitelist (tongdai111.vn) allowed!')

act, reason, ip = dns.check_domain_action('cloudflare-dns.com')
assert act == 'block' and ip == '0.0.0.0'
print('DoH endpoint (cloudflare-dns.com) blocked!')

act, reason, ip = dns.check_domain_action('v.tiktok.com')
assert act == 'block' and ip == '0.0.0.0'
print('Wildcard subdomain (*.tiktok.com) blocked!')

act, reason, ip = dns.check_domain_action('www.google.com')
assert act == 'safesearch' and ip == '216.239.38.120'
print('SafeSearch Google rewrite verified (216.239.38.120)!')

print('--- 3. Testing Screen-Time Counter & Clock Tamper Resistance ---')
tracker = TimeTracker(event_logger=cache.queue_event)
used, active = tracker.tick()
assert used >= 0 and active == True

tracker.last_known_wallclock = time.time() + 7200
tracker.tick()
unsynced = cache.get_unsynced_events()
assert any(ev['type'] == 'clock_tampering' for ev in unsynced)
print('Clock tampering correctly detected and logged!')

print('--- 4. Testing App Controller SHA-256 Hashing ---')
controller = AppController(policy_provider=lambda: loaded)
test_file = '/tmp/test_game.exe'
with open(test_file, 'wb') as f:
    f.write(b'SAMPLE GAME BINARY EXECUTABLE CONTENT')
expected_hash = hashlib.sha256(b'SAMPLE GAME BINARY EXECUTABLE CONTENT').hexdigest()
computed_hash = controller.calculate_sha256(test_file)
assert computed_hash == expected_hash
print(f'SHA-256 calculation verified: {computed_hash[:16]}...')

print('========================================================')
print(' ALL OGK-AGENT MODULE TESTS PASSED FLAWLESSLY! ')
print('========================================================')
