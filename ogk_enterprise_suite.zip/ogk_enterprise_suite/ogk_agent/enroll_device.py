import sys
import platform
import socket
import requests
from config import SERVER_URL
from local_cache import LocalCache

def enroll():
    print("==========================================================")
    print("       OGK-AGENT: GHEP DOI THIET BI VOI PHU HUYNH        ")
    print("==========================================================")
    code = input("Nhap ma ghep doi 8 ky tu tu Dashboard (vd: JLL3CZHJ): ").strip().upper()
    if len(code) != 8:
        print("Loi: Ma ghep doi phai gom dung 8 ky tu!")
        return False

    dev_name = f"PC-{platform.node()}"
    fingerprint = f"{platform.system()}-{platform.machine()}-{socket.gethostname()}"

    print(f"\nDang ket noi toi server {SERVER_URL} de xac thuc...")
    try:
        res = requests.post(f"{SERVER_URL}/api/v1/enroll/claim", json={
            "code": code,
            "device_name": dev_name,
            "fingerprint": fingerprint
        }, timeout=5.0)

        if res.status_code != 200:
            print("Ghep doi that bai:", res.json().get("detail", res.text))
            return False

        data = res.json()
    except Exception as e:
        print("Khong the ket noi toi server:", e)
        return False

    device_id = data["device_id"]
    child_id = data["child_id"]
    child_name = data.get("child_name", "Be An")
    access_token = data["access_token"]
    refresh_token = data["refresh_token"]

    # Save credentials locally
    cache = LocalCache()
    cache.save_device_credentials(device_id, child_id, access_token, refresh_token, child_name=child_name, device_name=dev_name)

    print("\n==========================================================")
    print(f" THANH CONG! Thiet bi da duoc gan cho: {child_name}")
    print(f" Device ID: {device_id}")
    print(" Thong tin xac thuc da duoc luu an toan.")
    print("==========================================================")

    # Fetch policy
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        p_res = requests.get(f"{SERVER_URL}/api/v1/policy", headers=headers, timeout=5.0)
        if p_res.status_code == 200:
            cache.save_policy(p_res.json())
            print(f"Da tai va luu tru chinh sach bao ve v{p_res.json().get('version')}.")
    except Exception as e:
        print(f"[Chu y] Chua the tai ngay chinh sach: {e}")

    print("\nBay gio ban co the khoi chay Agent bang file:")
    print("    3_CHAY_AGENT_SERVICE.bat")
    return True

if __name__ == "__main__":
    enroll()
