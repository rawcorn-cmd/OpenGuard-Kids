import time
import sys
import ctypes
import logging
from typing import Tuple, Optional, Callable

logger = logging.getLogger("OGK-TimeTracker")

class TimeTracker:
    """
    Tracks actual computer screen time (F1):
    - Pauses counter when user is idle > 5 minutes (GetLastInputInfo).
    - Monotonic time tracking (time.monotonic / GetTickCount64) prevents clock tampering.
    - Accurately reports used quota today.
    """
    def __init__(self, idle_threshold_sec: int = 300, event_logger=None):
        self.idle_threshold_sec = idle_threshold_sec
        self.event_logger = event_logger
        self.used_quota_today_sec = 0
        self.last_check_monotonic = time.monotonic()
        self.last_known_wallclock = time.time()
        self.extra_minutes_override = 0

    def get_idle_seconds(self) -> float:
        """Checks idle time using Windows GetLastInputInfo API."""
        if sys.platform == "win32":
            try:
                class LASTINPUTINFO(ctypes.Structure):
                    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

                lii = LASTINPUTINFO()
                lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
                if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii)):
                    millis = ctypes.windll.kernel32.GetTickCount() - lii.dwTime
                    return max(0.0, millis / 1000.0)
            except Exception:
                pass
        return 0.0 # Default active

    def tick(self) -> Tuple[int, bool]:
        """
        Called once per second:
        Returns (used_seconds_today, is_active)
        """
        now_mono = time.monotonic()
        now_wall = time.time()
        delta_mono = now_mono - self.last_check_monotonic
        self.last_check_monotonic = now_mono

        # Check for system clock tampering (e.g. user rolled back clock by hours)
        delta_wall = now_wall - self.last_known_wallclock
        if delta_wall < -60: # Clock jumped backwards by > 1 minute
            logger.warning(f"Detected system clock rollback: {delta_wall}s! Logging clock_tampering.")
            if self.event_logger:
                self.event_logger("clock_tampering", f"Lùi giờ {abs(int(delta_wall))}s")
        self.last_known_wallclock = now_wall

        # If user is idle > 5 minutes, do not count active time
        idle_sec = self.get_idle_seconds()
        is_active = (idle_sec < self.idle_threshold_sec)

        if is_active:
            self.used_quota_today_sec += int(delta_mono)

        return self.used_quota_today_sec, is_active

    def add_override_minutes(self, minutes: int):
        """Grants extra minutes (e.g. +15 mins approved by parent)."""
        self.extra_minutes_override += minutes
        logger.info(f"Added {minutes} override minutes. Total override: {self.extra_minutes_override}m")
