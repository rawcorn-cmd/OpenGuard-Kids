import json
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Callable, Optional

logger = logging.getLogger("OGK-IPC")

class IPCHandler(BaseHTTPRequestHandler):
    status_provider: Optional[Callable] = None
    request_handler: Optional[Callable] = None

    def log_message(self, format, *args):
        # Suppress routine console spam
        pass

    def do_GET(self):
        if self.path == "/status":
            if self.status_provider:
                status_data = self.status_provider()
            else:
                status_data = {
                    "status": "active",
                    "child_name": "Bé An",
                    "remaining_minutes": 60,
                    "used_minutes": 30,
                    "quota_minutes": 90,
                    "is_locked": False,
                    "recent_alert": None
                }
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(status_data, ensure_ascii=False).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/submit-request":
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length).decode("utf-8")
            try:
                data = json.loads(body)
                if self.request_handler:
                    res = self.request_handler(data.get("type"), data.get("subject"), data.get("reason"))
                else:
                    res = {"status": "success", "message": "Yêu cầu đã được tiếp nhận"}
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(json.dumps(res, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

class IPCServer:
    def __init__(self, host="127.0.0.1", port=58000, status_provider=None, request_handler=None):
        self.host = host
        self.port = port
        IPCHandler.status_provider = staticmethod(status_provider) if status_provider else None
        IPCHandler.request_handler = staticmethod(request_handler) if request_handler else None
        self.httpd = None
        self.thread = None

    def start(self):
        try:
            self.httpd = HTTPServer((self.host, self.port), IPCHandler)
            self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
            self.thread.start()
            logger.info(f"IPC Server running on {self.host}:{self.port}")
        except Exception as e:
            logger.warning(f"Could not bind IPC Server on port {self.port}: {e}")

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
