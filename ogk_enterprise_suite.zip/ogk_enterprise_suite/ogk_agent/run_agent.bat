@echo off
title OGK-Agent Child Client
echo ====================================================
echo  OGK-Agent: Cong cu dong hanh cung tre em
echo  Khoi dong Service, DNS Proxy va Tray UI...
echo ====================================================
python agent_service.py
pause
