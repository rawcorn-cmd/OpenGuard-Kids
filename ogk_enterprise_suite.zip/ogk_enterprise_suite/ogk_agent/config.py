import os
import sys
from pathlib import Path

# Safe Test Mode (Default: True - An toàn tuyệt đối khi thử nghiệm)
SAFE_TEST_MODE = os.getenv("OGK_SAFE_TEST_MODE", "true").lower() in ("true", "1", "yes")

# Server URL (defaults to localhost:8080)
SERVER_URL = os.getenv("OGK_SERVER_URL", "http://127.0.0.1:8080")
WS_SERVER_URL = os.getenv("OGK_WS_URL", "ws://127.0.0.1:8080")

# Local storage path:
# Lưu trữ trực tiếp trong thư mục dự án (tránh lỗi quyền C:\ProgramData readonly trên Windows)
AGENT_DIR = Path(__file__).resolve().parent
DATA_DIR = AGENT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

CACHE_DB_PATH = DATA_DIR / "cache.db"
DEVICE_CONFIG_PATH = DATA_DIR / "device_config.json"

# DNS Proxy Configuration
DNS_BIND_IP = "127.0.0.1"
DNS_BIND_PORT = 53
UPSTREAM_DNS = ("1.1.1.1", 53)

SAFESEARCH_IPS = {
    "google": "216.239.38.120",
    "bing": "204.79.197.220",
    "youtube": "216.239.38.119"
}

IPC_HOST = "127.0.0.1"
IPC_PORT = 58000
