@echo off
title OGK-Agent Tray UI
echo ====================================================
echo  Khoi dong Giao dien khay he thong cho tre (Tray UI)
echo ====================================================
python tray_ui/tray_app.py
pause
