import time
import json
import logging
import threading
import asyncio
import requests
from typing import Optional, Callable
from config import SERVER_URL, WS_SERVER_URL

logger = logging.getLogger("OGK-SyncClient")

class SyncClient:
    """
    Synchronizes with OGK-Server:
    - Maintains a persistent WebSocket connection (/ws/agent/{device_id}) for sub-second push commands & notifications!
    - Runs a fast 3-second Heartbeat fallback loop to guarantee 0 dropped commands.
    """
    def __init__(self, local_cache, command_handler=None, time_tracker=None, app_controller=None, server_url=SERVER_URL):
        self.app_controller = app_controller
        self.cache = local_cache
        self.command_handler = command_handler
        self.time_tracker = time_tracker
        self.server_url = server_url
        self.running = False

    def start(self):
        self.running = True
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()
        threading.Thread(target=self._websocket_loop, daemon=True).start()

    def stop(self):
        self.running = False

    def _get_headers(self) -> dict:
        creds = self.cache.load_device_credentials()
        if creds and "access_token" in creds:
            return {"Authorization": f"Bearer {creds['access_token']}"}
        return {}

    def fetch_latest_policy(self) -> bool:
        headers = self._get_headers()
        if not headers:
            return False
        try:
            res = requests.get(f"{self.server_url}/api/v1/policy", headers=headers, timeout=4.0)
            if res.status_code == 200:
                policy = res.json()
                self.cache.save_policy(policy)
                logger.info(f"Downloaded and cached updated policy v{policy['version']}")
                return True
        except Exception as e:
            logger.debug(f"Failed to fetch policy: {e}")
        return False

    def flush_events_batch(self):
        unsynced = self.cache.get_unsynced_events(limit=50)
        if not unsynced:
            return
        headers = self._get_headers()
        if not headers:
            return
        try:
            res = requests.post(f"{self.server_url}/api/v1/events/batch", json={"events": unsynced}, headers=headers, timeout=4.0)
            if res.status_code == 200:
                keys = [ev["idempotency_key"] for ev in unsynced]
                self.cache.mark_events_synced(keys)
        except Exception:
            pass

    def send_heartbeat(self) -> Optional[dict]:
        creds = self.cache.load_device_credentials()
        if not creds:
            return None

        policy = self.cache.load_policy()
        cur_version = policy["version"] if policy else 0
        used_sec = self.time_tracker.used_quota_today_sec if self.time_tracker else 0

        payload = {
            "policy_version": cur_version,
            "used_quota_today_sec": used_sec,
            "system_status": "ok",
            "agent_uptime_sec": int(time.time() - creds.get("enrolled_at", time.time())),
            "running_apps": self.app_controller.get_running_apps() if self.app_controller else []
        }

        try:
            res = requests.post(f"{self.server_url}/api/v1/heartbeat", json=payload, headers=self._get_headers(), timeout=4.0)
            if res.status_code == 200:
                data = res.json()
                if data.get("policy_outdated"):
                    self.fetch_latest_policy()
                    if self.command_handler:
                        self.command_handler("reload_policy", {"version": data.get("latest_policy_version")})

                for cmd in data.get("commands", []):
                    c_name = cmd.get("command")
                    c_params = cmd.get("params", {})
                    if self.command_handler:
                        self.command_handler(c_name, c_params)
                return data
        except Exception:
            pass
        return None

    def _heartbeat_loop(self):
        while self.running:
            try:
                self.flush_events_batch()
                self.send_heartbeat()
            except Exception:
                pass
            time.sleep(3)

    def _websocket_loop(self):
        try:
            import websockets
        except ImportError:
            return

        async def _listen():
            while self.running:
                creds = self.cache.load_device_credentials()
                if not creds or "device_id" not in creds:
                    await asyncio.sleep(3)
                    continue
                dev_id = creds["device_id"]
                ws_url = f"{WS_SERVER_URL}/ws/agent/{dev_id}"
                try:
                    async with websockets.connect(ws_url) as ws:
                        logger.info(f"Connected to real-time WebSocket channel: {ws_url}")
                        while self.running:
                            msg = await ws.recv()
                            data = json.loads(msg)
                            if data.get("type") == "command" and self.command_handler:
                                self.command_handler(data.get("command"), data.get("params", {}))
                except Exception:
                    await asyncio.sleep(3)

        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(_listen())
        except Exception:
            pass
