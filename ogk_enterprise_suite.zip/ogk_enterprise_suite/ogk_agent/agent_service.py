import time
import logging
import threading
import sys
import uuid
import atexit
from dns_configurator import set_windows_dns_loopback, restore_windows_dns_dhcp, update_windows_hosts_blocklist, clean_windows_hosts_blocklist, kill_browser_active_connections
from config import SERVER_URL, IPC_PORT
from local_cache import LocalCache
from dns_proxy import DNSProxy
from app_controller import AppController
from time_tracker import TimeTracker
from policy_enforcer import PolicyEnforcer
from sync_client import SyncClient
from ipc_server import IPCServer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("OGK-Agent")

class OGKAgent:
    def __init__(self):
        self.cache = LocalCache()
        self.notifications_queue = [] # List of {id, title, message, decision, sound, ts}
        self.processed_cmd_hashes = set()

        self.time_tracker = TimeTracker(event_logger=self.cache.queue_event)
        self.policy_enforcer = PolicyEnforcer(
            policy_provider=self.cache.load_policy,
            time_tracker=self.time_tracker,
            event_logger=self.cache.queue_event,
            warning_callback=self._on_warning
        )
        self.app_controller = AppController(
            policy_provider=self.cache.load_policy,
            event_logger=self.cache.queue_event,
            notification_callback=self._on_app_blocked
        )
        self.dns_proxy = DNSProxy(
            policy_provider=self.cache.load_policy,
            event_logger=self.cache.queue_event
        )
        self.sync_client = SyncClient(
            local_cache=self.cache,
            command_handler=self.handle_remote_command,
            time_tracker=self.time_tracker,
            app_controller=self.app_controller
        )
        self.ipc_server = IPCServer(
            port=IPC_PORT,
            status_provider=self.get_ipc_status,
            request_handler=self.handle_ipc_request
        )
        self.running = False

    def push_child_notification(self, title: str, message: str, decision: str = "info", sound: str = "success"):
        notif = {
            "id": str(uuid.uuid4()),
            "title": title,
            "message": message,
            "decision": decision,
            "sound": sound,
            "ts": int(time.time())
        }
        self.notifications_queue.append(notif)
        # Keep latest 20 notifications
        if len(self.notifications_queue) > 20:
            self.notifications_queue = self.notifications_queue[-20:]

    def sync_hosts_from_policy(self):
        policy = self.cache.load_policy()
        if policy and "domain_rules" in policy:
            blocked = [d["domain"] for d in policy["domain_rules"] if d.get("action") == "block"]
            update_windows_hosts_blocklist(blocked)
            kill_browser_active_connections()

    def get_ipc_status(self) -> dict:
        policy = self.cache.load_policy()
        child_name = "Bé An"
        creds = self.cache.load_device_credentials()
        if creds and "child_name" in creds:
            child_name = creds["child_name"]

        used_sec = self.time_tracker.used_quota_today_sec
        quota_sec = policy["daily_quota_weekday_sec"] if policy else 5400
        total_quota_sec = quota_sec + (self.time_tracker.extra_minutes_override * 60)
        rem_sec = max(0, total_quota_sec - used_sec)

        return {
            "status": "active",
            "child_name": child_name,
            "used_minutes": used_sec // 60,
            "quota_minutes": total_quota_sec // 60,
            "extra_override_minutes": self.time_tracker.extra_minutes_override,
            "remaining_seconds": rem_sec,
            "remaining_minutes": rem_sec // 60,
            "is_locked": self.policy_enforcer.locked,
            "app_quotas": self.app_controller.get_app_quotas_status(),
            "running_apps": self.app_controller.get_running_apps(),
            "notifications": self.notifications_queue[-5:]
        }

    def handle_ipc_request(self, req_type: str, subject: str, reason: str) -> dict:
        logger.info(f"IPC Request from child: {req_type} ({subject}): {reason}")
        self.cache.queue_event("unlock_request", f"{req_type}:{subject} - {reason}")
        return {"status": "success", "message": "Yêu cầu đã được ghi nhận và gửi tới ba mẹ."}

    def handle_remote_command(self, cmd: str, params: dict):
        # Deduplicate command execution within a 2-second window (in case both WebSocket and Heartbeat deliver it)
        cmd_key = f"{cmd}:{json.dumps(params, sort_keys=True)}:{int(time.time()) // 3}"
        if cmd_key in self.processed_cmd_hashes:
            return
        self.processed_cmd_hashes.add(cmd_key)

        logger.info(f"Executing remote command: {cmd} with params: {params}")
        if cmd == "lock_now":
            self.policy_enforcer.lock_screen()
            self.push_child_notification("🔒 Máy tính đã được khóa", "Ba mẹ vừa gửi lệnh khóa máy tính tạm thời.", "rejected", "lock")
        elif cmd == "unlock":
            self.policy_enforcer.unlock_screen()
            self.push_child_notification("🔓 Máy tính đã được mở khóa!", "Ba mẹ vừa mở khóa máy tính cho con.", "approved", "success")
        elif cmd in ("add_minutes_15", "add_time_15"):
            mins = int(params.get("minutes", 15))
            self.time_tracker.add_override_minutes(mins)
        elif cmd == "reload_policy":
            self.sync_client.fetch_latest_policy()
            self.sync_hosts_from_policy()
            unblocked_item = params.get("unblocked")
            if unblocked_item:
                logger.info(f"Domain/App '{unblocked_item}' unblocked and hosts updated immediately!")
        elif cmd == "child_notification":
            self.push_child_notification(
                title=params.get("title", "💬 Thông báo từ Ba Mẹ"),
                message=params.get("message", ""),
                decision=params.get("decision", "info"),
                sound=params.get("sound", "success")
            )

    def _on_warning(self, title: str, msg: str):
        logger.warning(f"TIME WARNING: {title} - {msg}")
        self.push_child_notification(title, msg, "warning", "warning")

    def _on_app_blocked(self, title: str, message: str):
        logger.info(f"APP BLOCKED: {title} - {message}")
        self.push_child_notification(title, message, "rejected", "warning")

    def start(self):
        logger.info("Starting OGK-Agent Service...")
        self.running = True

        self.ipc_server.start()
        self.sync_client.fetch_latest_policy()
        self.dns_proxy.start()
        set_windows_dns_loopback()
        self.sync_hosts_from_policy()
        atexit.register(self.stop)

        self.sync_client.start()

        try:
            while self.running:
                self.policy_enforcer.check_and_enforce()
                self.app_controller.scan_and_enforce()
                time.sleep(1.0)
        except KeyboardInterrupt:
            self.stop()

    def stop(self):
        logger.info("Stopping OGK-Agent Service...")
        self.running = False
        self.ipc_server.stop()
        self.dns_proxy.stop()
        restore_windows_dns_dhcp()
        clean_windows_hosts_blocklist()
        self.sync_client.stop()

import json
if __name__ == "__main__":
    agent = OGKAgent()
    agent.start()
