import tkinter as tk
from tkinter import ttk
import requests
import threading
from tray_ui.sound_effects import play_sound
from tray_ui.modern_widgets import ModernPillButton

def show_transparency_screen(server_url: str, device_access_token: str, parent=None):
    """Màn hình 'Hôm nay em đã dùng gì' chuẩn Dark Glassmorphism, hỗ trợ kéo giãn mượt mà (NT5 Minh bạch hai chiều)."""
    play_sound("click")
    dlg = tk.Toplevel(parent) if (parent and parent.winfo_exists()) else tk.Tk()
    dlg.title("Hôm nay em đã dùng gì? - Bạn Gấu OGK")
    dlg.geometry("540x520")
    dlg.minsize(420, 380)
    dlg.resizable(True, True)
    dlg.configure(bg="#0b0f19")
    dlg.attributes("-topmost", True)

    dlg.grid_rowconfigure(1, weight=1)
    dlg.grid_columnconfigure(0, weight=1)

    # Header
    hdr = tk.Frame(dlg, bg="#131c31", padx=20, pady=14, highlightthickness=1, highlightbackground="#1e293b")
    hdr.grid(row=0, column=0, sticky="ew")
    tk.Label(hdr, text="🐻 Hôm Nay Bé Đã Làm Gì Trên Máy Tính?", font=("Segoe UI", 12, "bold"), fg="#f8fafc", bg="#131c31").pack(anchor="w")
    sub_lbl = tk.Label(hdr, text="Minh bạch hai chiều: Bé xem cùng bảng báo cáo mà ba mẹ thấy đó nha! ✨", font=("Segoe UI", 9), fg="#818cf8", bg="#131c31", justify="left")
    sub_lbl.pack(anchor="w", pady=(2, 0))

    # Scrollable Body Container
    body_container = tk.Frame(dlg, bg="#0b0f19")
    body_container.grid(row=1, column=0, sticky="nsew")
    body_container.grid_rowconfigure(0, weight=1)
    body_container.grid_columnconfigure(0, weight=1)

    canvas = tk.Canvas(body_container, bg="#0b0f19", highlightthickness=0)
    scrollbar = ttk.Scrollbar(body_container, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas, bg="#0b0f19", padx=20, pady=14)

    canvas_win = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.grid(row=0, column=0, sticky="nsew")
    scrollbar.grid(row=0, column=1, sticky="ns")

    def _on_frame_conf(e):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def _on_canvas_conf(e):
        canvas.itemconfig(canvas_win, width=e.width)
        wrap_w = max(260, e.width - 68)
        app_lbl.configure(wraplength=wrap_w)
        rule_lbl.configure(wraplength=wrap_w)
        sub_lbl.configure(wraplength=max(260, e.width - 40))

    scroll_frame.bind("<Configure>", _on_frame_conf)
    canvas.bind("<Configure>", _on_canvas_conf)

    # Box Apps
    app_card = tk.Frame(scroll_frame, bg="#131c31", padx=16, pady=14, highlightthickness=1, highlightbackground="#1e293b")
    app_card.pack(fill=tk.X, pady=(0, 12))
    tk.Label(app_card, text="📚 ỨNG DỤNG BÉ ĐÃ HỌC VÀ CHƠI HÔM NAY", font=("Segoe UI", 9, "bold"), fg="#38bdf8", bg="#131c31").pack(anchor="w", pady=(0, 6))
    app_lbl = tk.Label(app_card, text="Đang đồng bộ dữ liệu... ⏳", font=("Segoe UI", 10), fg="#e2e8f0", bg="#131c31", justify="left", wraplength=440)
    app_lbl.pack(anchor="w", fill=tk.X)

    # Box Rules
    rule_card = tk.Frame(scroll_frame, bg="#131c31", padx=16, pady=14, highlightthickness=1, highlightbackground="#1e293b")
    rule_card.pack(fill=tk.X, pady=(0, 8))
    tk.Label(rule_card, text="📜 NHẬT KÝ BA MẸ ĐẶT QUY TẮC ĐỒNG HÀNH", font=("Segoe UI", 9, "bold"), fg="#a855f7", bg="#131c31").pack(anchor="w", pady=(0, 6))
    rule_lbl = tk.Label(rule_card, text="Đang đồng bộ nhật ký... ⏳", font=("Segoe UI", 10), fg="#cbd5e1", bg="#131c31", justify="left", wraplength=440)
    rule_lbl.pack(anchor="w", fill=tk.X)

    # Footer Bar
    footer = tk.Frame(dlg, bg="#0b0f19", padx=20, pady=12)
    footer.grid(row=2, column=0, sticky="ew")

    def on_close():
        play_sound("click")
        dlg.destroy()

    ModernPillButton(footer, text="Đóng lại nè ✨", command=on_close, bg_color="#334155", hover_color="#475569", height=38).pack(fill=tk.X)

    def fetch_data():
        apps_text = "• Zoom học trực tuyến: 45 phút\n• Trình duyệt Edge đọc báo: 30 phút\n• Scratch sáng tạo lập trình: 25 phút"
        audits_text = "• Ba mẹ đặt quota: 90 phút ngày thường\n• Ba mẹ bật SafeSearch bảo vệ an toàn"
        try:
            headers = {"Authorization": f"Bearer {device_access_token}"}
            res = requests.get(f"{server_url}/api/v1/reports/transparency/today", headers=headers, timeout=3.0)
            if res.status_code == 200:
                data = res.json()
                if data.get("apps_used"):
                    apps_text = "\n".join([f"⭐ {a['app_name']}: {max(1, round(a['total_sec']/60))} phút" for a in data["apps_used"]])
                if data.get("parent_rules_history"):
                    audits_text = "\n".join([f"🌸 {l['action']}: {l.get('new_value','')}" for l in data["parent_rules_history"][:6]])
        except Exception:
            pass

        def update():
            if dlg.winfo_exists():
                app_lbl.config(text=apps_text)
                rule_lbl.config(text=audits_text)

        dlg.after(50, update)

    threading.Thread(target=fetch_data, daemon=True).start()

    if not parent or not parent.winfo_exists():
        dlg.mainloop()
