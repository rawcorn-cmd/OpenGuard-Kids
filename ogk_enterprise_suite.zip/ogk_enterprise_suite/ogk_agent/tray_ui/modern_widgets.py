import tkinter as tk
import math

class ModernPillButton(tk.Canvas):
    """
    Fully responsive rounded pill button drawn on Tkinter Canvas.
    Automatically redraws and centers text whenever the window or parent container resizes!
    """
    def __init__(self, parent, text, command=None, width=360, height=42, bg_color="#4f46e5", hover_color="#6366f1", text_color="#ffffff", parent_bg="#131c31", radius=12, font=("Segoe UI", 9, "bold")):
        super().__init__(parent, width=width, height=height, bg=parent_bg, highlightthickness=0, bd=0, cursor="hand2")
        self.text = text
        self.command = command
        self.req_width = width
        self.req_height = height
        self.bg_color = bg_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.radius = radius
        self.font = font
        self.current_bg = bg_color

        self.bind("<Configure>", self._on_resize)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _on_resize(self, event):
        self._draw(event.width, event.height)

    def _draw(self, w=None, h=None):
        self.delete("all")
        w = max(120, w or self.winfo_width() or self.req_width)
        h = max(32, h or self.winfo_height() or self.req_height)
        r = min(self.radius, h // 2)
        pts = [
            r, 1, w-r, 1, w-1, 1, w-1, r,
            w-1, h-r, w-1, h-1, w-r, h-1, r, h-1,
            1, h-1, 1, h-r, 1, r, 1, 1
        ]
        self.create_polygon(pts, smooth=True, fill=self.current_bg, outline="", tags="bg")
        self.create_text(w // 2, h // 2, text=self.text, fill=self.text_color, font=self.font, tags="txt")

    def _on_enter(self, event):
        self.current_bg = self.hover_color
        self._draw()

    def _on_leave(self, event):
        self.current_bg = self.bg_color
        self._draw()

    def _on_click(self, event):
        if self.command:
            self.command()

class CircularProgressRing(tk.Canvas):
    """Apple Screen Time style Circular Progress Ring with center countdown."""
    def __init__(self, parent, size=156, bg_color="#131c31"):
        super().__init__(parent, width=size, height=size, bg=bg_color, highlightthickness=0, bd=0)
        self.size = size
        self.minutes = 60
        self.max_minutes = 90
        self.bonus_minutes = 0
        self.draw_ring()

    def update_progress(self, remaining_min: int, max_min: int = 90, bonus_min: int = 0):
        self.minutes = remaining_min
        self.max_minutes = max(1, max_min)
        self.bonus_minutes = bonus_min
        self.draw_ring()

    def draw_ring(self):
        self.delete("all")
        pad = 12
        s = self.size
        self.create_oval(pad, pad, s - pad, s - pad, outline="#1e293b", width=11)

        pct = min(1.0, max(0.0, self.minutes / float(self.max_minutes)))
        extent = -pct * 359.9
        arc_color = "#f43f5e" if self.minutes <= 10 else "#f59e0b" if self.minutes <= 20 else "#10b981"

        if extent < -1:
            self.create_arc(pad, pad, s - pad, s - pad, start=90, extent=extent, style=tk.ARC, outline=arc_color, width=11)

        self.create_text(s // 2, s // 2 - 12, text=f"{self.minutes}", fill="#ffffff", font=("Segoe UI", 26, "bold"))
        self.create_text(s // 2, s // 2 + 15, text="PHÚT CÒN LẠI", fill="#94a3b8", font=("Segoe UI", 7, "bold"))
        if self.bonus_minutes > 0:
            self.create_text(s // 2, s // 2 + 30, text=f"✨ +{self.bonus_minutes}p thưởng", fill="#38bdf8", font=("Segoe UI", 8, "bold"))
