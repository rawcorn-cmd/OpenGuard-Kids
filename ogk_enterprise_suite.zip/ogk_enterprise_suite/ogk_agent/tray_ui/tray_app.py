import sys
import time
import json
import threading
import urllib.request
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

try:
    import pystray
    from PIL import Image, ImageDraw
    PYSTRAY_AVAILABLE = True
except ImportError:
    PYSTRAY_AVAILABLE = False

try:
    import psutil
except ImportError:
    psutil = None

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import SERVER_URL, IPC_HOST, IPC_PORT, SAFE_TEST_MODE
from local_cache import LocalCache
from tray_ui.sound_effects import play_sound
from tray_ui.dialogs import show_blocked_alert, show_request_more_time_dialog, show_parent_feedback_popup
from tray_ui.transparency_view import show_transparency_screen
from tray_ui.modern_widgets import CircularProgressRing, ModernPillButton

class ChildTrayCompanion:
    """
    OGK Companion App 2026 Edition:
    1. Independent 1.0s Background Sync Daemon Thread:
       - Syncs continuously even when window is minimized/withdrawn to system tray!
       - Directly polls both Local IPC (127.0.0.1:58000) AND Server API fallback so commands/notifications
         arrive in < 1 second regardless of window state!
    2. Fully Resizable & Scrollable Responsive Layout:
       - Uses Grid weight + Canvas Scrollable Frame so resizing never clips text or buttons.
    3. Live Active Applications Monitor ("🟢 Ứng dụng đang hoạt động"):
       - Displays real-time running apps, memory usage, time used, and individual daily quota!
    """
    def __init__(self):
        self.cache = LocalCache()
        self.server_url = SERVER_URL
        self.ipc_url = f"http://{IPC_HOST}:{IPC_PORT}"
        self.remaining_minutes = 60
        self.quota_minutes = 90
        self.used_minutes = 30
        self.extra_override_minutes = 0
        self.is_locked = False
        self.agent_online = False
        self.child_name = "Bé An"
        self.tray_icon = None
        self.running = True
        self.last_known_override = 0
        self.seen_notification_ids = set()
        self.app_quotas = []
        self.running_apps = []

        self.root = tk.Tk()
        self.root.title("OGK Companion 2.0 — Bạn Đồng Hành Số")
        self.root.geometry("460x720")
        self.root.minsize(390, 520)
        self.root.resizable(True, True)
        self.root.configure(bg="#0b0f19")
        self.root.protocol("WM_DELETE_WINDOW", self.hide_to_tray)

        self._build_responsive_ui()
        self._start_tray_icon()

        # Start independent background sync daemon thread (never paused when window is withdrawn!)
        threading.Thread(target=self._background_sync_daemon, daemon=True).start()

    def _build_responsive_ui(self):
        # Configure root grid: Row 0 = Header, Row 1 = Scrollable Body, Row 2 = Fixed Footer
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        # 1. Fixed Top Header
        hdr = tk.Frame(self.root, bg="#0b0f19", padx=20, pady=12)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_columnconfigure(0, weight=1)

        top_row = tk.Frame(hdr, bg="#0b0f19")
        top_row.pack(fill=tk.X)
        tk.Label(top_row, text="🛡️ OGK COMPANION 2.0", font=("Segoe UI", 12, "bold"), fg="#38bdf8", bg="#0b0f19").pack(side=tk.LEFT)
        self.lbl_mode_pill = tk.Label(top_row, text="● SAFE MODE", font=("Segoe UI", 8, "bold"), fg="#34d399", bg="#064e3b", padx=8, pady=2)
        self.lbl_mode_pill.pack(side=tk.RIGHT)

        now_h = datetime.now().hour
        greet = "Chào buổi sáng năng lượng! ☀️" if now_h < 12 else "Buổi chiều học tập vui nhé! 🚀" if now_h < 18 else "Buổi tối thư giãn an toàn! 🌙"
        tk.Label(hdr, text=greet, font=("Segoe UI", 9), fg="#94a3b8", bg="#0b0f19").pack(anchor="w", pady=(2, 0))

        # 2. Scrollable Responsive Middle Body (Never clips when resized!)
        body_outer = tk.Frame(self.root, bg="#0b0f19", padx=16)
        body_outer.grid(row=1, column=0, sticky="nsew")
        body_outer.grid_columnconfigure(0, weight=1)
        body_outer.grid_rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(body_outer, bg="#131c31", highlightthickness=1, highlightbackground="#1e293b", bd=0)
        self.scrollbar = ttk.Scrollbar(body_outer, orient="vertical", command=self.canvas.yview)
        self.scrollable_card = tk.Frame(self.canvas, bg="#131c31", padx=18, pady=14)

        self.scrollable_card.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_card, anchor="nw")

        def _on_canvas_configure(event):
            self.canvas.itemconfig(self.canvas_window, width=event.width)
            if hasattr(self, "lbl_app_limits_list"):
                self.lbl_app_limits_list.config(wraplength=max(240, event.width - 55))

        self.canvas.bind("<Configure>", _on_canvas_configure)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")

        # Enable mousewheel scrolling
        def _on_mousewheel(event):
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        self.canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # --- Content inside Scrollable Card ---
        ring_holder = tk.Frame(self.scrollable_card, bg="#131c31")
        ring_holder.pack(pady=(2, 10))
        self.progress_ring = CircularProgressRing(ring_holder, size=156, bg_color="#131c31")
        self.progress_ring.pack()

        # Responsive Action Pill Buttons (fill=tk.X so they resize with window!)
        btn_box = tk.Frame(self.scrollable_card, bg="#131c31")
        btn_box.pack(fill=tk.X, pady=2)

        ModernPillButton(
            btn_box, text="⚡ Xin Ba Mẹ Thêm 15 Phút",
            bg_color="#4f46e5", hover_color="#6366f1", parent_bg="#131c31",
            height=40, command=self.on_request_more_time
        ).pack(fill=tk.X, pady=3)

        ModernPillButton(
            btn_box, text="🌟 Nhiệm Vụ Nhận Thưởng Giờ (+15p)",
            bg_color="#d97706", hover_color="#f59e0b", text_color="#090d16", parent_bg="#131c31",
            height=40, command=self.on_show_reward_tasks
        ).pack(fill=tk.X, pady=3)

        ModernPillButton(
            btn_box, text="🟢 Theo Dõi Ứng Dụng Đang Hoạt Động",
            bg_color="#059669", hover_color="#10b981", parent_bg="#131c31",
            height=40, command=self.on_show_active_apps
        ).pack(fill=tk.X, pady=3)

        ModernPillButton(
            btn_box, text="🛡️ Báo Trang Web Bị Chặn Nhầm",
            bg_color="#1e293b", hover_color="#334155", parent_bg="#131c31",
            height=38, command=self.on_report_wrong_block
        ).pack(fill=tk.X, pady=3)

        ModernPillButton(
            btn_box, text="📊 Hôm Nay Em Đã Dùng Gì? (Minh Bạch)",
            bg_color="#0f172a", hover_color="#1e293b", text_color="#38bdf8", parent_bg="#131c31",
            height=38, command=self.on_show_transparency
        ).pack(fill=tk.X, pady=3)

        # Per-App Time Limits & Active Apps Summary Card
        self.app_limits_frame = tk.Frame(self.scrollable_card, bg="#0f172a", padx=12, pady=10, highlightbackground="#1e293b", highlightthickness=1)
        self.app_limits_frame.pack(fill=tk.X, pady=(8, 4))
        tk.Label(self.app_limits_frame, text="⏱️ HẠN MỨC & ỨNG DỤNG ĐANG CHẠY", font=("Segoe UI", 8, "bold"), fg="#94a3b8", bg="#0f172a").pack(anchor="w")
        self.lbl_app_limits_list = tk.Label(
            self.app_limits_frame,
            text="• roblox.exe: Tối đa 45p/ngày\n• msedge.exe: Tối đa 60p/ngày\n• zoom.exe: Không giới hạn (∞)",
            font=("Consolas", 8), fg="#38bdf8", bg="#0f172a", justify="left", wraplength=360
        )
        self.lbl_app_limits_list.pack(anchor="w", fill=tk.X, pady=(4, 0))

        # Safe Lock Simulation Banner
        self.lock_banner = tk.Frame(self.scrollable_card, bg="#4c0519", padx=10, pady=8, highlightbackground="#f43f5e", highlightthickness=1)
        tk.Label(self.lock_banner, text="⏰ ĐÃ HẾT THỜI GIAN SỬ DỤNG HÔM NAY", font=("Segoe UI", 8, "bold"), fg="#fda4af", bg="#4c0519").pack()
        tk.Button(self.lock_banner, text="🔓 Mở khóa thử nghiệm (+15p)", font=("Segoe UI", 8, "bold"), bg="#e11d48", fg="#ffffff", relief=tk.FLAT, command=self._unlock_test).pack(pady=3)

        # 3. Fixed Bottom Status Bar (Always visible, never pushed off screen!)
        footer = tk.Frame(self.root, bg="#0b0f19", padx=20, pady=10)
        footer.grid(row=2, column=0, sticky="ew")
        self.lbl_service_status = tk.Label(footer, text="● Đang đồng bộ thời gian thực...", font=("Segoe UI", 8, "bold"), fg="#10b981", bg="#0b0f19")
        self.lbl_service_status.pack(side=tk.LEFT)
        tk.Button(footer, text="Thu nhỏ xuống khay ↘", font=("Segoe UI", 8, "bold"), fg="#94a3b8", bg="#131c31", activebackground="#1e293b", activeforeground="#ffffff", relief=tk.FLAT, padx=10, pady=4, cursor="hand2", command=self.hide_to_tray).pack(side=tk.RIGHT)

    def _unlock_test(self):
        play_sound("success")
        self.extra_override_minutes += 15
        self.is_locked = False
        self.lock_banner.pack_forget()

    # ==============================================================================
    # INDEPENDENT 1.0s BACKGROUND SYNC DAEMON (WORKS EVEN WHEN MINIMIZED/WITHDRAWN!)
    # ==============================================================================
    def _background_sync_daemon(self):
        while self.running:
            try:
                self._sync_once()
                # Schedule UI widget update on Tkinter thread
                self.root.after(0, self._refresh_ui_widgets)
            except Exception:
                pass
            time.sleep(1.5)

    def _sync_once(self):
        ipc_ok = False
        # 1. Try polling local Agent Service IPC (127.0.0.1:58000)
        try:
            req = urllib.request.urlopen(f"{self.ipc_url}/status", timeout=1.0)
            data = json.loads(req.read().decode("utf-8"))
            self.remaining_minutes = data.get("remaining_minutes", self.remaining_minutes)
            self.quota_minutes = data.get("quota_minutes", 90)
            self.used_minutes = data.get("used_minutes", self.used_minutes)
            self.extra_override_minutes = data.get("extra_override_minutes", 0)
            self.is_locked = data.get("is_locked", False)
            self.child_name = data.get("child_name", self.child_name)
            self.app_quotas = data.get("app_quotas", [])
            self.running_apps = data.get("running_apps", [])
            self.agent_online = True
            ipc_ok = True

            self._process_incoming_notifications(data.get("notifications", []))
        except Exception:
            self.agent_online = False

        # 2. Direct Fallback to Server API if Agent Service is not running (so Tray UI ALWAYS syncs!)
        if not ipc_ok:
            creds = self.cache.load_device_credentials()
            if creds and "access_token" in creds:
                headers = {"Content-Type": "application/json", "Authorization": f"Bearer {creds['access_token']}"}
                # Scan local running apps if psutil is available
                local_running = self._scan_local_processes_fallback()
                self.running_apps = local_running
                payload = json.dumps({
                    "policy_version": (self.cache.load_policy() or {}).get("version", 1),
                    "used_quota_today_sec": self.used_minutes * 60,
                    "system_status": "ok",
                    "agent_uptime_sec": 60,
                    "running_apps": local_running
                }).encode("utf-8")
                try:
                    hb_req = urllib.request.Request(f"{self.server_url}/api/v1/heartbeat", data=payload, headers=headers, method="POST")
                    hb_res = urllib.request.urlopen(hb_req, timeout=1.5)
                    hb_data = json.loads(hb_res.read().decode("utf-8"))
                    self.agent_online = True

                    if hb_data.get("policy_outdated"):
                        p_req = urllib.request.Request(f"{self.server_url}/api/v1/policy", headers=headers)
                        p_res = urllib.request.urlopen(p_req, timeout=2.0)
                        self.cache.save_policy(json.loads(p_res.read().decode("utf-8")))

                    for cmd in hb_data.get("commands", []):
                        c_name = cmd.get("command")
                        c_params = cmd.get("params", {})
                        if c_name in ("add_minutes_15", "add_time_15"):
                            mins = int(c_params.get("minutes", 15))
                            self.extra_override_minutes += mins
                        elif c_name == "lock_now":
                            self.is_locked = True
                        elif c_name == "unlock":
                            self.is_locked = False
                        elif c_name == "child_notification":
                            notif_item = {
                                "id": f"srv-{time.time()}",
                                "title": c_params.get("title", "Thông báo từ Ba Mẹ"),
                                "message": c_params.get("message", ""),
                                "decision": c_params.get("decision", "approved"),
                                "sound": c_params.get("sound", "success")
                            }
                            self._process_incoming_notifications([notif_item])
                except Exception:
                    pass

            policy = self.cache.load_policy()
            if policy:
                now = datetime.now()
                base_q = (policy["daily_quota_weekend_sec"] if now.weekday() >= 5 else policy["daily_quota_weekday_sec"]) // 60
                self.quota_minutes = base_q + self.extra_override_minutes
                self.remaining_minutes = max(0, self.quota_minutes - self.used_minutes)

        if self.extra_override_minutes > self.last_known_override:
            play_sound("bonus_time")
            self.last_known_override = self.extra_override_minutes

        if self.tray_icon:
            try:
                self.tray_icon.title = f"OGK - Còn lại: {self.remaining_minutes} phút"
            except Exception:
                pass

    def _scan_local_processes_fallback(self) -> list:
        if not psutil:
            return []
        ignore = {"svchost.exe", "explorer.exe", "dwm.exe", "conhost.exe", "runtimebroker.exe", "taskhostw.exe", "csrss.exe", "wininit.exe", "services.exe", "lsass.exe"}
        policy = self.cache.load_policy() or {}
        rules = policy.get("app_rules", [])
        res = []
        seen = set()
        for proc in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                name = (proc.info.get('name') or '').lower()
                if not name or name in ignore or name in seen or proc.info['pid'] <= 4:
                    continue
                seen.add(name)
                rule = next((r for r in rules if r["name"].lower() == name), None)
                lim = int(rule.get("daily_limit_minutes", 0) or 0) if rule else 0
                mem = round(proc.info['memory_info'].rss / (1024 * 1024), 1) if proc.info.get('memory_info') else 0.0
                res.append({
                    "pid": proc.info['pid'],
                    "name": name,
                    "memory_mb": mem,
                    "used_minutes": 5.0,
                    "daily_limit_minutes": lim,
                    "remaining_minutes": max(0.0, lim - 5.0) if lim > 0 else None,
                    "status": rule.get("action", "allow") if rule else "allow"
                })
            except Exception:
                continue
        res.sort(key=lambda x: x["memory_mb"], reverse=True)
        return res[:12]

    def _process_incoming_notifications(self, notifs: list):
        for notif in notifs:
            nid = notif.get("id") or f"{notif.get('title')}:{notif.get('ts')}"
            if nid not in self.seen_notification_ids:
                self.seen_notification_ids.add(nid)
                title = notif.get("title", "💬 Thông báo từ Ba Mẹ")
                msg = notif.get("message", "")
                dec = notif.get("decision", "approved")
                snd = notif.get("sound", "success")

                if self.tray_icon:
                    try:
                        self.tray_icon.notify(title=title, message=msg[:120])
                    except Exception:
                        pass

                # Trigger popup on main thread even if main window is hidden!
                self.root.after(0, lambda t=title, m=msg, d=dec, s=snd: show_parent_feedback_popup(t, m, d, s, parent=self.root))

    def _refresh_ui_widgets(self):
        if not self.running:
            return
        self.progress_ring.update_progress(self.remaining_minutes, self.quota_minutes, self.extra_override_minutes)

        if self.agent_online:
            self.lbl_service_status.config(text="● Đã kết nối đồng bộ thời gian thực (Live 1.5s)", fg="#10b981")
        else:
            self.lbl_service_status.config(text="○ Chế độ ngoại tuyến (Đang lưu đệm cục bộ)", fg="#f59e0b")

        # Update Per-App quotas & active apps summary
        lines = []
        if self.app_quotas:
            for a in [x for x in self.app_quotas if x.get("action") == "allow"][:3]:
                lim = a.get("daily_limit_minutes", 0)
                used = a.get("used_minutes", 0)
                if lim > 0:
                    lines.append(f"• {a['name']}: Đã dùng {used}p / Giới hạn {lim}p (Còn {a.get('remaining_minutes')}p)")
                else:
                    lines.append(f"• {a['name']}: Đã dùng {used}p (Không giới hạn ∞)")
        if self.running_apps:
            top_names = ", ".join([a["name"] for a in self.running_apps[:3]])
            lines.append(f"🟢 Đang chạy ({len(self.running_apps)}): {top_names}")

        if lines and hasattr(self, "lbl_app_limits_list"):
            self.lbl_app_limits_list.config(text="\n".join(lines))

        if self.is_locked:
            self.lock_banner.pack(fill=tk.X, pady=4)
        else:
            self.lock_banner.pack_forget()

    # ==============================================================================
    # LIVE ACTIVE APPLICATIONS MONITOR MODAL ("🟢 Theo Dõi Ứng Dụng Đang Hoạt Động")
    # ==============================================================================
    def on_show_active_apps(self):
        play_sound("click")
        dlg = tk.Toplevel(self.root)
        dlg.title("🟢 Theo Dõi Ứng Dụng Đang Hoạt Động Thời Gian Thực")
        dlg.geometry("560x440")
        dlg.minsize(460, 340)
        dlg.resizable(True, True)
        dlg.attributes("-topmost", True)
        dlg.configure(bg="#0b0f19")

        dlg.grid_columnconfigure(0, weight=1)
        dlg.grid_rowconfigure(1, weight=1)

        hdr = tk.Frame(dlg, bg="#131c31", padx=18, pady=12)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text="🟢 Tiến Trình & Ứng Dụng Đang Chạy Trên Máy", font=("Segoe UI", 12, "bold"), fg="#34d399", bg="#131c31").pack(anchor="w")
        tk.Label(hdr, text="Cập nhật trực tiếp bộ nhớ RAM, thời gian đã dùng và hạn mức riêng của từng ứng dụng", font=("Segoe UI", 8), fg="#94a3b8", bg="#131c31").pack(anchor="w")

        body = tk.Frame(dlg, bg="#0b0f19", padx=16, pady=12)
        body.grid(row=1, column=0, sticky="nsew")
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        cols = ("name", "pid", "mem", "used", "limit", "status")
        tree = ttk.Treeview(body, columns=cols, show="headings", height=12)
        tree.heading("name", text="Tên Ứng Dụng (.exe)")
        tree.heading("pid", text="PID")
        tree.heading("mem", text="RAM (MB)")
        tree.heading("used", text="Đã Dùng")
        tree.heading("limit", text="Hạn Mức Ngày")
        tree.heading("status", text="Trạng Thái")

        tree.column("name", width=150, anchor="w")
        tree.column("pid", width=55, anchor="center")
        tree.column("mem", width=75, anchor="e")
        tree.column("used", width=75, anchor="center")
        tree.column("limit", width=95, anchor="center")
        tree.column("status", width=85, anchor="center")

        vsb = ttk.Scrollbar(body, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")

        def populate():
            if not dlg.winfo_exists():
                return
            for item in tree.get_children():
                tree.delete(item)
            apps_list = self.running_apps if self.running_apps else self._scan_local_processes_fallback()
            for a in apps_list:
                lim = a.get("daily_limit_minutes", 0)
                lim_str = f"{lim} phút" if lim > 0 else "∞ KGH"
                st_str = "🚫 Chặn" if a.get("status") == "block" else "✅ Cho phép"
                tree.insert("", tk.END, values=(
                    a.get("name"),
                    a.get("pid"),
                    f"{a.get('memory_mb', 0)} MB",
                    f"{a.get('used_minutes', 0)}p",
                    lim_str,
                    st_str
                ))
            dlg.after(2500, populate)

        populate()

        btn_bar = tk.Frame(dlg, bg="#0b0f19", padx=16, pady=10)
        btn_bar.grid(row=2, column=0, sticky="ew")
        tk.Button(btn_bar, text="Đóng", font=("Segoe UI", 9, "bold"), bg="#1e293b", fg="#ffffff", relief=tk.FLAT, padx=16, pady=5, command=dlg.destroy).pack(side=tk.RIGHT)

    def _start_tray_icon(self):
        if not PYSTRAY_AVAILABLE:
            return
        image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle([4, 4, 60, 60], radius=16, fill="#4f46e5", outline="#818cf8", width=2)
        draw.ellipse([16, 16, 48, 48], fill="#0b0f19")
        draw.text((22, 18), "🛡️", fill="#38bdf8")

        menu = pystray.Menu(
            pystray.MenuItem("🛡️ OGK Companion 2.0", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(lambda item: f"⏱️ Còn lại: {self.remaining_minutes} phút", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("⚡ Xin thêm 15 phút", lambda: self.root.after(0, self.on_request_more_time)),
            pystray.MenuItem("🌟 Nhiệm vụ nhận thưởng", lambda: self.root.after(0, self.on_show_reward_tasks)),
            pystray.MenuItem("🟢 Ứng dụng đang chạy", lambda: self.root.after(0, self.on_show_active_apps)),
            pystray.MenuItem("📊 Nhật ký minh bạch", lambda: self.root.after(0, self.on_show_transparency)),
            pystray.MenuItem("💻 Mở giao diện chính", lambda: self.root.after(0, self.show_window), default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Thoát", lambda: self.root.after(0, self.quit_app))
        )
        self.tray_icon = pystray.Icon("OGK-Agent", image, "OGK Companion 2.0", menu)
        try:
            self.tray_icon.run_detached()
        except Exception:
            pass

    def hide_to_tray(self):
        play_sound("click")
        self.root.withdraw()

    def show_window(self):
        play_sound("click")
        self.root.deiconify()
        self.root.lift()

    def quit_app(self):
        self.running = False
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.destroy()
        sys.exit(0)

    def check_enrollment(self) -> bool:
        creds = self.cache.load_device_credentials()
        if not creds or "access_token" not in creds:
            messagebox.showwarning("Chưa ghép đôi", "Máy tính chưa được ghép đôi với ba mẹ!\nHãy mở '2_GHEP_DOI_AGENT.bat' trước nhé!")
            return False
        return True

    def submit_child_request(self, req_type: str, subject: str, reason: str):
        def _send():
            creds = self.cache.load_device_credentials()
            if not creds or "access_token" not in creds:
                return
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {creds['access_token']}"}
            payload = json.dumps({"type": req_type, "subject": subject, "reason": reason}).encode("utf-8")
            try:
                req = urllib.request.Request(f"{self.server_url}/api/v1/requests", data=payload, headers=headers, method="POST")
                urllib.request.urlopen(req, timeout=3.5)
            except Exception:
                self.cache.queue_event("unlock_request", f"{req_type}:{reason}")
        threading.Thread(target=_send, daemon=True).start()

    def on_request_more_time(self):
        if not self.check_enrollment():
            return
        show_request_more_time_dialog(submit_callback=self.submit_child_request, parent=self.root)

    def on_report_wrong_block(self):
        if not self.check_enrollment():
            return
        play_sound("click")
        dlg = tk.Toplevel(self.root)
        dlg.title("Báo trang web bị chặn nhầm")
        dlg.geometry("460x290")
        dlg.minsize(380, 250)
        dlg.resizable(True, True)
        dlg.attributes("-topmost", True)
        dlg.configure(bg="#0b0f19")

        dlg.grid_columnconfigure(0, weight=1)
        dlg.grid_rowconfigure(1, weight=1)

        hdr = tk.Frame(dlg, bg="#131c31", padx=18, pady=12)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text="🛡️ Báo Trang Web Bị Chặn Nhầm", font=("Segoe UI", 11, "bold"), fg="#38bdf8", bg="#131c31").pack(anchor="w")

        frame = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=12)
        frame.grid(row=1, column=0, sticky="nsew")

        tk.Label(frame, text="Tên miền cần mở (ví dụ: facebook.com, scratch.mit.edu):", font=("Segoe UI", 9, "bold"), bg="#0b0f19", fg="#94a3b8").pack(anchor="w")
        domain_entry = tk.Entry(frame, font=("Consolas", 10), bg="#131c31", fg="#ffffff", insertbackground="white", relief=tk.FLAT)
        domain_entry.pack(fill=tk.X, pady=6, ipady=5)

        tk.Label(frame, text="Lời nhắn gửi ba mẹ:", font=("Segoe UI", 9, "bold"), bg="#0b0f19", fg="#94a3b8").pack(anchor="w")
        reason_entry = tk.Entry(frame, font=("Segoe UI", 9), bg="#131c31", fg="#ffffff", insertbackground="white", relief=tk.FLAT)
        reason_entry.insert(0, "Trang này phục vụ học tập trên lớp của con")
        reason_entry.pack(fill=tk.X, pady=6, ipady=5)

        status_lbl = tk.Label(frame, text="", font=("Segoe UI", 9, "bold"), fg="#10b981", bg="#0b0f19")
        status_lbl.pack(anchor="w")

        btn_bar = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=10)
        btn_bar.grid(row=2, column=0, sticky="ew")

        def submit():
            d = domain_entry.get().strip()
            r = reason_entry.get().strip()
            if d:
                self.submit_child_request("unblock_domain", d, r)
                play_sound("success")
                status_lbl.config(text="✓ Đã gửi yêu cầu mở trang tới ba mẹ!")
                dlg.after(900, dlg.destroy)

        tk.Button(btn_bar, text="Gửi Yêu Cầu 🚀", font=("Segoe UI", 9, "bold"), bg="#4f46e5", fg="white", relief=tk.FLAT, padx=14, pady=6, cursor="hand2", command=submit).pack(side=tk.RIGHT, padx=4)
        tk.Button(btn_bar, text="Hủy", font=("Segoe UI", 9), bg="#1e293b", fg="#94a3b8", relief=tk.FLAT, padx=12, pady=6, command=dlg.destroy).pack(side=tk.RIGHT)

    def on_show_reward_tasks(self):
        play_sound("click")
        dlg = tk.Toplevel(self.root)
        dlg.title("Nhiệm Vụ Nhận Thưởng Giờ 🌟")
        dlg.geometry("500x440")
        dlg.minsize(420, 340)
        dlg.resizable(True, True)
        dlg.attributes("-topmost", True)
        dlg.configure(bg="#0b0f19")

        dlg.grid_columnconfigure(0, weight=1)
        dlg.grid_rowconfigure(1, weight=1)

        hdr = tk.Frame(dlg, bg="#131c31", padx=18, pady=14)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text="🌟 Nhiệm Vụ Săn Giờ Thưởng", font=("Segoe UI", 12, "bold"), fg="#fbbf24", bg="#131c31").pack(anchor="w")
        tk.Label(hdr, text="Hoàn thành thử thách ba mẹ giao để nhận ngay phút sử dụng máy tính!", font=("Segoe UI", 8), fg="#94a3b8", bg="#131c31").pack(anchor="w")

        body = tk.Frame(dlg, bg="#0b0f19", padx=16, pady=12)
        body.grid(row=1, column=0, sticky="nsew")
        list_container = tk.Frame(body, bg="#0b0f19")
        list_container.pack(fill=tk.BOTH, expand=True)
        status_lbl = tk.Label(body, text="", font=("Segoe UI", 9, "bold"), fg="#10b981", bg="#0b0f19")
        status_lbl.pack(anchor="w", pady=4)

        def load_tasks():
            creds = self.cache.load_device_credentials()
            headers = {"Authorization": f"Bearer {creds['access_token']}"} if (creds and "access_token" in creds) else {}
            tasks = []
            try:
                req = urllib.request.Request(f"{self.server_url}/api/v1/children/agent/tasks", headers=headers)
                res = urllib.request.urlopen(req, timeout=3.0)
                tasks = json.loads(res.read().decode("utf-8"))
            except Exception:
                tasks = [
                    {"id": 1, "title": "Hoàn thành 5 bài tập Toán trên OLM.vn", "reward_minutes": 15, "status": "assigned"},
                    {"id": 2, "title": "Đọc 1 chương sách Khoa học tự nhiên", "reward_minutes": 20, "status": "assigned"}
                ]

            def render():
                if not dlg.winfo_exists():
                    return
                for w in list_container.winfo_children():
                    w.destroy()
                for t in tasks[:4]:
                    row = tk.Frame(list_container, bg="#131c31", padx=14, pady=10, highlightbackground="#1e293b", highlightthickness=1)
                    row.pack(fill=tk.X, pady=5)
                    info = tk.Frame(row, bg="#131c31")
                    info.pack(side=tk.LEFT, fill=tk.X, expand=True)
                    tk.Label(info, text=f"🎯 {t['title']}", font=("Segoe UI", 9, "bold"), fg="#ffffff", bg="#131c31", wraplength=300, justify="left").pack(anchor="w")
                    tk.Label(info, text=f"Phần thưởng: +{t['reward_minutes']} phút", font=("Segoe UI", 8, "bold"), fg="#fbbf24", bg="#131c31").pack(anchor="w")

                    if t["status"] == "rewarded":
                        tk.Label(row, text="✓ Đã nhận", font=("Segoe UI", 8, "bold"), fg="#34d399", bg="#064e3b", padx=8, pady=4).pack(side=tk.RIGHT)
                    elif t["status"] == "completed_by_child":
                        tk.Label(row, text="⏳ Chờ duyệt", font=("Segoe UI", 8, "bold"), fg="#fbbf24", bg="#451a03", padx=8, pady=4).pack(side=tk.RIGHT)
                    else:
                        def mark_done(tid=t["id"]):
                            play_sound("success")
                            try:
                                r = urllib.request.Request(f"{self.server_url}/api/v1/children/agent/tasks/{tid}/complete", headers=headers, method="POST")
                                urllib.request.urlopen(r, timeout=3.0)
                            except Exception:
                                pass
                            status_lbl.config(text="✓ Đã gửi báo cáo hoàn thành tới ba mẹ!")
                            dlg.after(500, load_tasks)
                        tk.Button(row, text="Báo hoàn thành 🙋", font=("Segoe UI", 8, "bold"), bg="#f59e0b", fg="#090d16", relief=tk.FLAT, padx=10, pady=5, cursor="hand2", command=mark_done).pack(side=tk.RIGHT)
            dlg.after(50, render)

        threading.Thread(target=load_tasks, daemon=True).start()

    def on_show_transparency(self):
        creds = self.cache.load_device_credentials()
        token = creds.get("access_token", "") if creds else ""
        show_transparency_screen(self.server_url, token, parent=self.root)

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = ChildTrayCompanion()
    app.run()
