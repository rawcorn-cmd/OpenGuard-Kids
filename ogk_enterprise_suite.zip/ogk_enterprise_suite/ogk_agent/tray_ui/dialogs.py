import tkinter as tk
import threading
from tray_ui.sound_effects import play_sound

def _bind_dynamic_wrap(widget, padding=44):
    def _on_cfg(event):
        if event.width > 100:
            widget.config(wraplength=max(200, event.width - padding))
    widget.master.bind("<Configure>", _on_cfg)

def show_blocked_alert(title: str, message: str, on_request_unblock=None, parent=None):
    play_sound("warning")
    dlg = tk.Toplevel(parent) if (parent and parent.winfo_exists()) else tk.Tk()
    dlg.title(title)
    dlg.geometry("480x280")
    dlg.minsize(380, 230)
    dlg.resizable(True, True)
    dlg.attributes("-topmost", True)
    dlg.configure(bg="#0b0f19")

    dlg.grid_columnconfigure(0, weight=1)
    dlg.grid_rowconfigure(1, weight=1)

    hdr = tk.Frame(dlg, bg="#4c0519", padx=18, pady=12)
    hdr.grid(row=0, column=0, sticky="ew")
    tk.Label(hdr, text="🛡️ OGK Guard — Giải Thích Minh Bạch (NT4)", font=("Segoe UI", 11, "bold"), fg="#fda4af", bg="#4c0519").pack(anchor="w")

    body = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=14)
    body.grid(row=1, column=0, sticky="nsew")
    msg_lbl = tk.Label(body, text=message, font=("Segoe UI", 10), fg="#e2e8f0", bg="#0b0f19", wraplength=420, justify="left")
    msg_lbl.pack(anchor="w", fill=tk.BOTH, expand=True)
    _bind_dynamic_wrap(msg_lbl, 40)

    btn_box = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=12)
    btn_box.grid(row=2, column=0, sticky="ew")
    tk.Button(btn_box, text="Đã hiểu ✓", font=("Segoe UI", 9, "bold"), bg="#e11d48", fg="white", relief=tk.FLAT, padx=16, pady=6, cursor="hand2", command=dlg.destroy).pack(side=tk.RIGHT)

    if not parent or not parent.winfo_exists():
        dlg.mainloop()

def show_request_more_time_dialog(submit_callback, parent=None):
    play_sound("click")
    dlg = tk.Toplevel(parent) if (parent and parent.winfo_exists()) else tk.Tk()
    dlg.title("Xin Thêm 15 Phút")
    dlg.geometry("460x280")
    dlg.minsize(380, 240)
    dlg.resizable(True, True)
    dlg.attributes("-topmost", True)
    dlg.configure(bg="#0b0f19")

    dlg.grid_columnconfigure(0, weight=1)
    dlg.grid_rowconfigure(1, weight=1)

    hdr = tk.Frame(dlg, bg="#131c31", padx=18, pady=12)
    hdr.grid(row=0, column=0, sticky="ew")
    tk.Label(hdr, text="⚡ Xin Ba Mẹ Thêm 15 Phút", font=("Segoe UI", 12, "bold"), fg="#38bdf8", bg="#131c31").pack(anchor="w")

    body = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=14)
    body.grid(row=1, column=0, sticky="nsew")
    tk.Label(body, text="Nhập lý do gửi tới ba mẹ:", font=("Segoe UI", 9, "bold"), fg="#94a3b8", bg="#0b0f19").pack(anchor="w")

    reason_entry = tk.Entry(body, font=("Segoe UI", 10), bg="#131c31", fg="white", insertbackground="white", relief=tk.FLAT)
    reason_entry.insert(0, "Con cần thêm 15 phút để hoàn thành nốt bài tập")
    reason_entry.pack(fill=tk.X, pady=8, ipady=6)

    status_lbl = tk.Label(body, text="", font=("Segoe UI", 9, "bold"), fg="#10b981", bg="#0b0f19", wraplength=400, justify="left")
    status_lbl.pack(anchor="w", fill=tk.X)
    _bind_dynamic_wrap(status_lbl, 40)

    btn_box = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=12)
    btn_box.grid(row=2, column=0, sticky="ew")

    def do_submit():
        reason = reason_entry.get().strip()
        status_lbl.config(text="Đang truyền tín hiệu tới ba mẹ...", fg="#38bdf8")
        submit_btn.config(state="disabled")
        def run_net():
            if submit_callback:
                submit_callback("more_time_15", "15_mins", reason)
            dlg.after(100, on_done)
        def on_done():
            play_sound("success")
            status_lbl.config(text="✓ Đã gửi thành công tới Dashboard ba mẹ!", fg="#10b981")
            dlg.after(1000, dlg.destroy)
        threading.Thread(target=run_net, daemon=True).start()

    submit_btn = tk.Button(btn_box, text="Gửi Yêu Cầu 🚀", font=("Segoe UI", 9, "bold"), bg="#4f46e5", fg="white", relief=tk.FLAT, padx=14, pady=6, cursor="hand2", command=do_submit)
    submit_btn.pack(side=tk.RIGHT, padx=4)
    tk.Button(btn_box, text="Đóng", font=("Segoe UI", 9), bg="#1e293b", fg="#94a3b8", relief=tk.FLAT, padx=12, pady=6, cursor="hand2", command=dlg.destroy).pack(side=tk.RIGHT)

    if not parent or not parent.winfo_exists():
        dlg.mainloop()

def show_parent_feedback_popup(title: str, message: str, decision: str = "approved", sound: str = "success", parent=None):
    """
    Displays an instant, independent popup on top of the screen even when the main Tray UI window is hidden!
    """
    play_sound(sound if sound else ("bonus_time" if decision == "approved" else "warning"))
    dlg = tk.Toplevel(parent) if (parent and parent.winfo_exists()) else tk.Tk()
    dlg.title(title)
    dlg.geometry("480x260")
    dlg.minsize(380, 220)
    dlg.resizable(True, True)
    dlg.attributes("-topmost", True)
    dlg.configure(bg="#0b0f19")
    dlg.deiconify()
    dlg.lift()

    dlg.grid_columnconfigure(0, weight=1)
    dlg.grid_rowconfigure(1, weight=1)

    is_positive = (decision == "approved")
    hdr_bg = "#064e3b" if is_positive else "#4c0519"
    hdr_fg = "#34d399" if is_positive else "#fda4af"
    btn_bg = "#10b981" if is_positive else "#e11d48"

    hdr = tk.Frame(dlg, bg=hdr_bg, padx=18, pady=12)
    hdr.grid(row=0, column=0, sticky="ew")
    tk.Label(hdr, text=title, font=("Segoe UI", 11, "bold"), fg=hdr_fg, bg=hdr_bg).pack(anchor="w")

    body = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=14)
    body.grid(row=1, column=0, sticky="nsew")
    msg_lbl = tk.Label(body, text=message, font=("Segoe UI", 10), fg="#f8fafc", bg="#0b0f19", wraplength=430, justify="left")
    msg_lbl.pack(anchor="w", fill=tk.BOTH, expand=True)
    _bind_dynamic_wrap(msg_lbl, 40)

    btn_box = tk.Frame(dlg, bg="#0b0f19", padx=18, pady=12)
    btn_box.grid(row=2, column=0, sticky="ew")
    tk.Button(btn_box, text="Dạ, con cảm ơn ba mẹ! ✨" if is_positive else "Dạ, con đã hiểu ✓", font=("Segoe UI", 9, "bold"), bg=btn_bg, fg="#090d16" if is_positive else "#ffffff", relief=tk.FLAT, padx=16, pady=6, cursor="hand2", command=dlg.destroy).pack(side=tk.RIGHT)

    dlg.after(15000, lambda: dlg.destroy() if dlg.winfo_exists() else None)
