import sys
import threading
import time

try:
    import winsound
    WINSOUND_AVAILABLE = True
except ImportError:
    WINSOUND_AVAILABLE = False

def _play_beeps(notes):
    """Plays sequence of (frequency, duration_ms) notes in background thread."""
    if not WINSOUND_AVAILABLE:
        return
    try:
        for freq, dur in notes:
            winsound.Beep(freq, dur)
            time.sleep(0.02)
    except Exception:
        pass

def play_sound(sound_type: str):
    """
    Plays cute sound effects for child companion actions:
    - click: Gentle bubbly tick
    - success: Sweet cheerful chime (Do-Mi-Sol)
    - bonus_time: Joyful triumphant fan-fare (+15 mins)
    - warning: Gentle reminder tone
    - lock: Soft bedtime chime
    """
    if not WINSOUND_AVAILABLE:
        return

    notes_map = {
        "click": [(1400, 35)],
        "success": [(523, 80), (659, 80), (784, 140)], # C5 - E5 - G5
        "bonus_time": [(440, 70), (554, 70), (659, 80), (880, 160)], # A4 - C#5 - E5 - A5
        "warning": [(587, 100), (440, 150)], # D5 - A4
        "lock": [(659, 120), (523, 120), (392, 220)] # E5 - C5 - G4
    }

    notes = notes_map.get(sound_type, [(1000, 50)])
    threading.Thread(target=_play_beeps, args=(notes,), daemon=True).start()

if __name__ == "__main__":
    print("Sound effects module loaded.")
