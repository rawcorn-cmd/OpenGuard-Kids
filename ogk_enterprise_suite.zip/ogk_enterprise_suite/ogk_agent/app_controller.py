import os
import hashlib
import time
import logging
from typing import Dict, Any, Tuple, Optional, Callable
try:
    import psutil
except ImportError:
    psutil = None

from config import SAFE_TEST_MODE
from tray_ui.sound_effects import play_sound

logger = logging.getLogger("OGK-AppController")


SYSTEM_PROCESS_IGNORE = {
    "system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe",
    "services.exe", "lsass.exe", "svchost.exe", "fontdrvhost.exe", "winlogon.exe",
    "dwm.exe", "SearchIndexer.exe", "taskhostw.exe", "explorer.exe", "RuntimeBroker.exe",
    "ApplicationFrameHost.exe", "sihost.exe", "ctfmon.exe", "conhost.exe", "dllhost.exe",
    "WmiPrvSE.exe", "spoolsv.exe", "SearchApp.exe", "StartMenuExperienceHost.exe",
    "TextInputHost.exe", "SecurityHealthService.exe", "MsMpEng.exe", "NisSrv.exe"
}

class AppController:
    """
    Scans running processes and verifies executable SHA-256 hashes:
    1. Terminates blocked processes immediately (matching name OR SHA-256 hash).
    2. Tracks daily usage duration (in seconds) for EVERY allowed application!
    3. Enforces per-application daily time limits (daily_limit_minutes > 0):
       - Warns when 5 minutes remaining for that specific app.
       - Closes/terminates the app when its individual daily quota is exhausted!
    """
    def __init__(self, policy_provider, event_logger=None, notification_callback=None):
        self.policy_provider = policy_provider
        self.event_logger = event_logger
        self.notification_callback = notification_callback
        self.hash_cache: Dict[str, Tuple[float, str]] = {} # exe_path -> (mtime, sha256)
        self.app_usage_today_sec: Dict[str, int] = {} # app_name -> seconds used today
        self.app_warned_5m: Dict[str, bool] = {} # app_name -> bool
        self.app_limit_notified: Dict[str, float] = {} # app_name -> last_notified_ts
        self.last_scan_mono = time.monotonic()
        self.currently_running_apps: List[Dict[str, Any]] = []

    def calculate_sha256(self, exe_path: str) -> Optional[str]:
        if not os.path.exists(exe_path):
            return None
        try:
            mtime = os.path.getmtime(exe_path)
            if exe_path in self.hash_cache:
                cached_mtime, cached_hash = self.hash_cache[exe_path]
                if cached_mtime == mtime:
                    return cached_hash

            hasher = hashlib.sha256()
            with open(exe_path, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            hash_str = hasher.hexdigest().lower()
            self.hash_cache[exe_path] = (mtime, hash_str)
            return hash_str
        except Exception as e:
            logger.debug(f"Could not hash {exe_path}: {e}")
            return None

    def get_running_apps(self) -> list:
        """Returns list of currently active user applications with usage duration and policy status."""
        return list(self.currently_running_apps)

    def get_app_quotas_status(self) -> list:
        """Returns live usage vs limit for all configured apps in policy."""
        policy = self.policy_provider()
        if not policy or "app_rules" not in policy:
            return []
        result = []
        for rule in policy["app_rules"]:
            name = rule["name"].lower()
            limit_min = int(rule.get("daily_limit_minutes", 0) or 0)
            used_sec = self.app_usage_today_sec.get(name, 0)
            result.append({
                "name": name,
                "action": rule.get("action", "allow"),
                "used_minutes": round(used_sec / 60.0, 1),
                "used_seconds": used_sec,
                "daily_limit_minutes": limit_min,
                "remaining_minutes": max(0, round((limit_min * 60 - used_sec) / 60.0, 1)) if limit_min > 0 else None
            })
        return result

    def scan_and_enforce(self):
        now_mono = time.monotonic()
        delta_sec = max(1, int(now_mono - self.last_scan_mono))
        self.last_scan_mono = now_mono

        if psutil is None:
            return
        policy = self.policy_provider()
        if not policy or "app_rules" not in policy:
            return

        rules = policy["app_rules"]
        seen_apps_in_tick = set()
        active_list = []

        for proc in psutil.process_iter(['pid', 'name', 'exe', 'memory_info']):
            try:
                p_name = (proc.info.get('name') or '').lower()
                p_exe = proc.info.get('exe')
                p_pid = proc.info.get('pid')

                if not p_name or p_pid <= 4:
                    continue

                p_hash = self.calculate_sha256(p_exe) if p_exe else None

                for rule in rules:
                    rule_name = rule["name"].lower()
                    rule_hash = rule.get("sha256", "*").lower()
                    rule_action = rule.get("action", "allow")
                    limit_min = int(rule.get("daily_limit_minutes", 0) or 0)
                    reason = rule.get("reason", "Ứng dụng bị giới hạn")

                    name_match = (p_name == rule_name)
                    hash_match = (rule_hash != "*" and p_hash == rule_hash)

                    if name_match or hash_match:
                        # 1. If action is BLOCK -> terminate immediately
                        if rule_action == "block":
                            self._enforce_termination(proc, p_name, p_pid, reason, is_quota_exceeded=False)
                            break

                        # 2. If action is ALLOW -> increment usage counter once per scan tick
                        if rule_name not in seen_apps_in_tick:
                            seen_apps_in_tick.add(rule_name)
                            self.app_usage_today_sec[rule_name] = self.app_usage_today_sec.get(rule_name, 0) + delta_sec

                        # 3. Check per-app daily time limit (if limit_min > 0)
                        if limit_min > 0:
                            used_sec = self.app_usage_today_sec.get(rule_name, 0)
                            limit_sec = limit_min * 60
                            rem_sec = limit_sec - used_sec

                            # 5-minute warning for this specific app
                            if 0 < rem_sec <= 300 and not self.app_warned_5m.get(rule_name):
                                self.app_warned_5m[rule_name] = True
                                play_sound("warning")
                                if self.notification_callback:
                                    self.notification_callback(
                                        title=f"⏳ Sắp hết giờ dùng {rule_name}",
                                        message=f"Con chỉ còn {max(1, rem_sec // 60)} phút sử dụng ứng dụng '{rule_name}' hôm nay (Hạn mức: {limit_min} phút/ngày)."
                                    )

                            # Quota exceeded for this specific app!
                            if used_sec >= limit_sec:
                                quota_reason = f"Đã hết hạn mức thời gian cho phép ({limit_min} phút/ngày) đối với ứng dụng '{rule_name}'."
                                self._enforce_termination(proc, p_name, p_pid, quota_reason, is_quota_exceeded=True)
                        break
                # Also record active user applications for Live Active Apps Monitor
                if p_name not in {x.lower() for x in SYSTEM_PROCESS_IGNORE} and p_name not in seen_apps_in_tick:
                    seen_apps_in_tick.add(p_name)
                    self.app_usage_today_sec[p_name] = self.app_usage_today_sec.get(p_name, 0) + delta_sec

                if p_name not in {x.lower() for x in SYSTEM_PROCESS_IGNORE} and not any(a["name"] == p_name for a in active_list):
                    used_s = self.app_usage_today_sec.get(p_name, 0)
                    matched_rule = next((r for r in rules if r["name"].lower() == p_name), None)
                    limit_m = int(matched_rule.get("daily_limit_minutes", 0) or 0) if matched_rule else 0
                    mem_mb = round(proc.info['memory_info'].rss / (1024 * 1024), 1) if proc.info.get('memory_info') else 0.0
                    active_list.append({
                        "pid": p_pid,
                        "name": p_name,
                        "sha256": (p_hash[:12] + "...") if p_hash else "N/A",
                        "memory_mb": mem_mb,
                        "used_minutes": round(used_s / 60.0, 1),
                        "daily_limit_minutes": limit_m,
                        "remaining_minutes": max(0.0, round((limit_m * 60 - used_s) / 60.0, 1)) if limit_m > 0 else None,
                        "status": matched_rule.get("action", "allow") if matched_rule else "allow"
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        # Sort active apps by used_minutes desc, then memory_mb desc
        active_list.sort(key=lambda x: (x["used_minutes"], x["memory_mb"]), reverse=True)
        self.currently_running_apps = active_list[:15]

    def _enforce_termination(self, proc, p_name: str, p_pid: int, reason: str, is_quota_exceeded: bool = False):
        now = time.time()
        last_notif = self.app_limit_notified.get(p_name, 0)

        if SAFE_TEST_MODE:
            if now - last_notif > 15: # Throttle notification in safe mode to once every 15s
                self.app_limit_notified[p_name] = now
                play_sound("warning")
                title = f"⏰ Hết giờ dùng {p_name} [Chế độ An toàn]" if is_quota_exceeded else f"🚫 Phát hiện ứng dụng bị chặn [Chế độ An toàn]"
                if self.notification_callback:
                    self.notification_callback(
                        title=title,
                        message=f"Ứng dụng '{p_name}' đã chạm giới hạn và sẽ tự đóng trong chế độ thực tế.\nLý do: {reason}"
                    )
        else:
            try:
                proc.terminate()
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            if now - last_notif > 5:
                self.app_limit_notified[p_name] = now
                play_sound("warning")
                title = f"⏰ Đã đóng {p_name} (Hết giờ)" if is_quota_exceeded else f"🚫 Đã đóng ứng dụng {p_name}"
                if self.notification_callback:
                    self.notification_callback(
                        title=title,
                        message=f"Ứng dụng '{p_name}' đã được đóng lại an toàn.\nLý do: {reason}"
                    )

        if self.event_logger and (now - last_notif <= 1):
            self.event_logger("blocked_app", p_name)
