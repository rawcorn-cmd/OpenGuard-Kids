import time
import sys
import ctypes
import logging
from datetime import datetime
from typing import Tuple, Optional, Callable
from config import SAFE_TEST_MODE
from tray_ui.sound_effects import play_sound

logger = logging.getLogger("OGK-PolicyEnforcer")

class PolicyEnforcer:
    """
    Enforces 7x48 matrix schedule and daily quota:
    - SAFE_TEST_MODE: Safe simulation mode (does NOT lock real Windows workstation, shows cute mock overlay).
    - PRODUCTION_MODE: Calls ctypes.windll.user32.LockWorkStation().
    """
    def __init__(self, policy_provider, time_tracker, event_logger=None, warning_callback=None, lock_callback=None):
        self.policy_provider = policy_provider
        self.time_tracker = time_tracker
        self.event_logger = event_logger
        self.warning_callback = warning_callback
        self.lock_callback = lock_callback
        self.warned_10 = False
        self.warned_5 = False
        self.warned_1 = False
        self.grace_period_start = None
        self.locked = False

    def is_current_slot_allowed(self, matrix: list) -> bool:
        now = datetime.now()
        day = now.weekday()
        slot = (now.hour * 2) + (1 if now.minute >= 30 else 0)
        try:
            return matrix[day][slot] == 1
        except Exception:
            return True

    def lock_screen(self):
        self.locked = True
        logger.info(f"Lock triggered. (SAFE_TEST_MODE = {SAFE_TEST_MODE})")
        play_sound("lock")

        if self.event_logger:
            self.event_logger("locked", "Hết hạn mức thời gian hoặc ngoài khung giờ")

        if SAFE_TEST_MODE:
            logger.info("[CHẾ ĐỘ AN TOÀN] Không khóa cứng Windows. Kích hoạt giao diện mô phỏng khóa máy an toàn.")
            if self.lock_callback:
                self.lock_callback(True)
        else:
            if sys.platform == "win32":
                try:
                    ctypes.windll.user32.LockWorkStation()
                except Exception as e:
                    logger.error(f"Failed to LockWorkStation: {e}")

    def unlock_screen(self):
        self.locked = False
        self.grace_period_start = None
        play_sound("success")
        logger.info("Workstation unlocked.")
        if self.lock_callback:
            self.lock_callback(False)

    def check_and_enforce(self):
        policy = self.policy_provider()
        if not policy:
            return

        used_sec, _ = self.time_tracker.tick()
        now = datetime.now()
        is_weekend = (now.weekday() >= 5)

        base_quota_sec = policy["daily_quota_weekend_sec"] if is_weekend else policy["daily_quota_weekday_sec"]
        total_allowed_sec = base_quota_sec + (self.time_tracker.extra_minutes_override * 60)
        remaining_sec = max(0, total_allowed_sec - used_sec)

        # 1. Schedule Matrix
        if not self.is_current_slot_allowed(policy.get("schedule_matrix", [])):
            if not self.locked:
                self.lock_screen()
            return

        # 2. Warnings with cute sounds
        rem_min = remaining_sec // 60
        if 9 < rem_min <= 10 and not self.warned_10:
            self.warned_10 = True
            play_sound("warning")
            if self.warning_callback:
                self.warning_callback("Bé ơi còn 10 phút nè ⏰", "Bé còn 10 phút nữa thôi nhé, chuẩn bị lưu bài học nha!")
        elif 4 < rem_min <= 5 and not self.warned_5:
            self.warned_5 = True
            play_sound("warning")
            if self.warning_callback:
                self.warning_callback("Nhắc nhở yêu thương ⏳", "Chỉ còn 5 phút nữa thôi! Nhớ lưu lại bài tập cẩn thận nha bé.")
        elif 0 < rem_min <= 1 and not self.warned_1:
            self.warned_1 = True
            play_sound("warning")
            if self.warning_callback:
                self.warning_callback("Sắp hết giờ rồi nè 🚨", "Con còn 1 phút cuối cùng! Hệ thống tặng 60 giây ân hạn để lưu bài.")

        # 3. Quota Exceeded -> Grace Period -> Lock
        if remaining_sec <= 0:
            if not self.grace_period_start:
                self.grace_period_start = time.time()
                play_sound("warning")
                if self.warning_callback:
                    self.warning_callback("Khoảng ân hạn 60 giây 🌟", "Đã hết thời gian cho phép rồi. Bé có 60 giây để lưu lại bài tập nhé!")
            elif time.time() - self.grace_period_start > 60:
                if not self.locked:
                    self.lock_screen()
        else:
            if self.locked:
                self.unlock_screen()
