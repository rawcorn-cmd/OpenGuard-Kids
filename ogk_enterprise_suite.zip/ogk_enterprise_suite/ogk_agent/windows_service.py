import sys
import os
import time
import logging
from pathlib import Path

# Try importing pywin32 service modules
try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
    PYWIN32_AVAILABLE = True
except ImportError:
    PYWIN32_AVAILABLE = False

from agent_service import OGKAgent

class OGKWindowsService:
    """
    Windows Service Wrapper for OGK-Agent:
    - Runs under LocalSystem account
    - Managed by Service Control Manager (SCM)
    - Auto-recovery enabled via SCM failure actions
    """
    _svc_name_ = "OGKAgentService"
    _svc_display_name_ = "OGK Child Guardian Agent Service"
    _svc_description_ = "Dich vu giam sat va bao ve tre em tren Windows (Open Guardian Kid) - Khoi chay DNS Proxy va Policy Enforcer."

    def __init__(self, args):
        if PYWIN32_AVAILABLE:
            import win32serviceutil
            win32serviceutil.ServiceFramework.__init__(self, args)
            self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.agent = None

    def SvcStop(self):
        if PYWIN32_AVAILABLE:
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self.stop_event)
        if self.agent:
            self.agent.stop()

    def SvcDoRun(self):
        if PYWIN32_AVAILABLE:
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, "")
            )
        self.agent = OGKAgent()
        self.agent.start()

if __name__ == '__main__':
    if len(sys.argv) == 1:
        # Run directly as standalone daemon if invoked without arguments
        print("Starting OGK-Agent in standalone mode (Ctrl+C to stop)...")
        agent = OGKAgent()
        agent.start()
    else:
        if PYWIN32_AVAILABLE:
            win32serviceutil.HandleCommandLine(OGKWindowsService)
        else:
            print("pywin32 is not installed. To install Windows Service, run: pip install pywin32")
            print("Starting in standalone daemon mode instead...")
            agent = OGKAgent()
            agent.start()
