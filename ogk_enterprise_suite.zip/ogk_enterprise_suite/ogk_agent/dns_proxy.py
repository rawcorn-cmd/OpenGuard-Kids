import socket
import threading
import struct
import logging
from typing import Tuple, List, Set, Optional
from config import DNS_BIND_IP, DNS_BIND_PORT, UPSTREAM_DNS, SAFESEARCH_IPS

logger = logging.getLogger("OGK-DNSProxy")

class DNSProxy:
    """
    Local DNS Proxy Server running on 127.0.0.1:53:
    1. Wildcard domain blocking (*.tiktok.com, *.facebook.com)
    2. CNAME / IP redirection for SafeSearch enforcement (Google, Bing, YouTube)
    3. Blocks DoH endpoints (cloudflare-dns.com, dns.google) to prevent DNS circumvention
    4. Permanent whitelist for Emergency 111, Education & School portals
    """
    def __init__(self, policy_provider, event_logger=None, bind_ip=DNS_BIND_IP, bind_port=DNS_BIND_PORT):
        self.policy_provider = policy_provider
        self.event_logger = event_logger
        self.bind_ip = bind_ip
        self.bind_port = bind_port
        self.running = False
        self.sock = None

        # Permanent Whitelist (NT6 - An toan co uu tien tuyet doi)
        self.permanent_whitelist: Set[str] = {
            "tongdai111.vn", "chinhphu.vn", "edu.vn", "bvdkhanoi.vn", "who.int"
        }

        # DoH Endpoints to block (F2 / Phu luc)
        self.doh_endpoints: Set[str] = {
            "cloudflare-dns.com", "dns.google", "dns.quad9.net", 
            "doh.opendns.com", "dns.adguard-dns.com"
        }

    def start(self):
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            self.sock.bind((self.bind_ip, self.bind_port))
            logger.info(f"DNS Proxy bound to {self.bind_ip}:{self.bind_port}")
        except Exception as e:
            logger.warning(f"Could not bind 127.0.0.1:53 (might require Administrator privileges): {e}")
            return

        thread = threading.Thread(target=self._listen_loop, daemon=True)
        thread.start()

    def stop(self):
        self.running = False
        if self.sock:
            self.sock.close()

    def _listen_loop(self):
        while self.running:
            try:
                data, addr = self.sock.recvfrom(4096)
                if not data:
                    continue
                threading.Thread(target=self._handle_query, args=(data, addr), daemon=True).start()
            except Exception:
                break

    def _parse_domain_name(self, data: bytes, offset: int = 12) -> Tuple[str, int]:
        labels = []
        curr = offset
        while curr < len(data):
            length = data[curr]
            if length == 0:
                curr += 1
                break
            if (length & 0xC0) == 0xC0:
                curr += 2
                break
            curr += 1
            labels.append(data[curr:curr + length].decode("latin1", errors="ignore"))
            curr += length
        return ".".join(labels).lower(), curr

    def _is_subdomain_match(self, domain: str, rule_domain: str) -> bool:
        rule = rule_domain.lower().lstrip("*.")
        if domain == rule or domain.endswith("." + rule):
            return True
        return False

    def check_domain_action(self, domain: str) -> Tuple[str, str, Optional[str]]:
        # 1. Check Permanent Whitelist (NT6)
        for w in self.permanent_whitelist:
            if self._is_subdomain_match(domain, w):
                return "allow", "Miễn chặn vĩnh viễn (An toàn & Cứu hộ 111)", None

        # 2. Check DoH endpoints
        policy = self.policy_provider()
        if policy and policy.get("doh_blocked", True):
            for doh in self.doh_endpoints:
                if self._is_subdomain_match(domain, doh):
                    return "block", "Chặn điểm cuối DoH để bảo vệ trẻ em", "0.0.0.0"

        # 3. Check SafeSearch enforcement
        if policy and policy.get("safe_search_enabled", True):
            if "google." in domain and ("www." in domain or domain.startswith("google.")):
                return "safesearch", "Cưỡng chế SafeSearch Google", SAFESEARCH_IPS["google"]
            if "bing.com" in domain:
                return "safesearch", "Cưỡng chế SafeSearch Bing", SAFESEARCH_IPS["bing"]
            if "youtube.com" in domain:
                return "safesearch", "Cưỡng chế Chế độ giới hạn YouTube", SAFESEARCH_IPS["youtube"]

        # 4. Check Blocklist in Policy
        if policy and "domain_rules" in policy:
            for rule in policy["domain_rules"]:
                if self._is_subdomain_match(domain, rule["domain"]):
                    if rule.get("action") == "block":
                        return "block", rule.get("reason", "Ten mien bi phu huynh han che"), "0.0.0.0"
                    elif rule.get("action") == "allow":
                        return "allow", rule.get("reason", "Duoc phep"), None

        return "allow", "Binh thuong", None

    def _build_dns_response(self, query_data: bytes, domain: str, ip_answer: str) -> bytes:
        trans_id = query_data[:2]
        flags = bytes([0x81, 0x80])
        qdcount = struct.pack(">H", 1)
        ancount = struct.pack(">H", 1)
        nscount = struct.pack(">H", 0)
        arcount = struct.pack(">H", 0)
        header = trans_id + flags + qdcount + ancount + nscount + arcount

        qname_parts = domain.split(".")
        qname = b"".join(bytes([len(p)]) + p.encode("latin1") for p in qname_parts) + bytes([0])
        qtype = struct.pack(">H", 1)
        qclass = struct.pack(">H", 1)
        question = qname + qtype + qclass

        ans_name = bytes([0xC0, 0x0C])
        ans_type = struct.pack(">H", 1)
        ans_class = struct.pack(">H", 1)
        ans_ttl = struct.pack(">I", 60)
        ip_bytes = socket.inet_aton(ip_answer)
        ans_len = struct.pack(">H", len(ip_bytes))
        answer = ans_name + ans_type + ans_class + ans_ttl + ans_len + ip_bytes

        return header + question + answer

    def _handle_query(self, query_data: bytes, client_addr: Tuple[str, int]):
        if len(query_data) < 12:
            return

        domain, _ = self._parse_domain_name(query_data)
        if not domain:
            return

        action, reason, override_ip = self.check_domain_action(domain)

        if self.event_logger:
            ev_type = "blocked_domain" if action == "block" else "domain_query"
            self.event_logger(ev_type, domain)

        if action in ("block", "safesearch") and override_ip:
            resp = self._build_dns_response(query_data, domain, override_ip)
            self.sock.sendto(resp, client_addr)
            return

        try:
            forwarder = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            forwarder.settimeout(3.0)
            forwarder.sendto(query_data, UPSTREAM_DNS)
            upstream_resp, _ = forwarder.recvfrom(4096)
            self.sock.sendto(upstream_resp, client_addr)
            forwarder.close()
        except Exception:
            pass
