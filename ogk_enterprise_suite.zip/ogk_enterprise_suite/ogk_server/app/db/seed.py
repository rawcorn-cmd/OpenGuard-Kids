import json
import time
import uuid
from app.db.database import get_db
from app.core.security import hash_password, sign_policy

def get_default_schedule_matrix() -> list:
    matrix = []
    for day in range(7):
        day_slots = [0] * 48
        if day < 5:
            for s in range(13, 15): # 06:30 - 07:30
                day_slots[s] = 1
            for s in range(34, 41): # 17:00 - 20:30
                day_slots[s] = 1
        else:
            for s in range(16, 23): # 08:00 - 11:30
                day_slots[s] = 1
            for s in range(28, 41): # 14:00 - 20:30
                day_slots[s] = 1
        matrix.append(day_slots)
    return matrix

def get_default_app_rules() -> list:
    return [
        {"name": "discord.exe", "sha256": "*", "action": "block", "daily_limit_minutes": 0, "reason": "Mạng xã hội không phù hợp lứa tuổi 6-11"},
        {"name": "telegram.exe", "sha256": "*", "action": "block", "daily_limit_minutes": 0, "reason": "Ứng dụng nhắn tin mở không phù hợp lứa tuổi 6-11"},
        {"name": "roblox.exe", "sha256": "*", "action": "allow", "daily_limit_minutes": 45, "reason": "Trò chơi giải trí giới hạn tối đa 45 phút/ngày"},
        {"name": "zoom.exe", "sha256": "*", "action": "allow", "daily_limit_minutes": 0, "reason": "Phần mềm học trực tuyến (Không giới hạn)"},
        {"name": "teams.exe", "sha256": "*", "action": "allow", "daily_limit_minutes": 0, "reason": "Phần mềm học trực tuyến (Không giới hạn)"},
        {"name": "msedge.exe", "sha256": "*", "action": "allow", "daily_limit_minutes": 60, "reason": "Trình duyệt web học tập (Giới hạn 60 phút/ngày)"}
    ]

def get_default_domain_rules() -> list:
    return [
        {"domain": "tongdai111.vn", "action": "allow", "category": "education", "reason": "Tổng đài quốc gia bảo vệ trẻ em (Miễn chặn vĩnh viễn)"},
        {"domain": "chinhphu.vn", "action": "allow", "category": "education", "reason": "Cổng thông tin chính phủ (Miễn chặn vĩnh viễn)"},
        {"domain": "edu.vn", "action": "allow", "category": "education", "reason": "Cổng giáo dục quốc gia"},
        {"domain": "khanacademy.org", "action": "allow", "category": "education", "reason": "Học tập trực tuyến"},
        {"domain": "scratch.mit.edu", "action": "allow", "category": "education", "reason": "Lập trình trẻ em"},
        {"domain": "tiktok.com", "action": "block", "category": "social", "reason": "Mạng xã hội hạn chế lứa tuổi dưới 13"},
        {"domain": "facebook.com", "action": "block", "category": "social", "reason": "Mạng xã hội hạn chế lứa tuổi dưới 13"},
        {"domain": "instagram.com", "action": "block", "category": "social", "reason": "Mạng xã hội hạn chế lứa tuổi dưới 13"},
        {"domain": "roblox.com", "action": "block", "category": "gaming", "reason": "Trò chơi ngoài giờ cho phép"}
    ]

def seed_default_data():
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        
        # 1. Parent
        cursor.execute("SELECT id FROM parents WHERE email = 'phuhuynh@ogk.vn';")
        parent = cursor.fetchone()
        if not parent:
            pwd_hash = hash_password("MatKhauPhuHuynh2026!")
            cursor.execute('''
            INSERT INTO parents (email, full_name, password_hash, role, created_at)
            VALUES (?, ?, ?, 'parent', ?);
            ''', ('phuhuynh@ogk.vn', 'Nguyễn Văn Phụ Huynh', pwd_hash, now))
            parent_id = cursor.lastrowid
        else:
            parent_id = parent["id"]

        # 2. Child: Bé An
        cursor.execute("SELECT id FROM children WHERE parent_id = ? AND name = 'Bé An';", (parent_id,))
        child = cursor.fetchone()
        if not child:
            cursor.execute('''
            INSERT INTO children (parent_id, name, birth_year, avatar, created_at)
            VALUES (?, 'Bé An', 2017, '👦', ?);
            ''', (parent_id, now))
            child_id = cursor.lastrowid
        else:
            child_id = child["id"]

        # 3. Policy
        cursor.execute("SELECT id FROM policies WHERE child_id = ?;", (child_id,))
        if not cursor.fetchone():
            sched = get_default_schedule_matrix()
            app_rules = get_default_app_rules()
            dom_rules = get_default_domain_rules()
            
            policy_payload = {
                "child_id": child_id,
                "version": 1,
                "daily_quota_weekday_sec": 5400,
                "daily_quota_weekend_sec": 7200,
                "schedule_matrix": sched,
                "app_rules": app_rules,
                "domain_rules": dom_rules,
                "safe_search_enabled": 1,
                "doh_blocked": 1
            }
            sig = sign_policy(policy_payload)

            cursor.execute('''
            INSERT INTO policies (
                child_id, version, daily_quota_weekday_sec, daily_quota_weekend_sec,
                schedule_matrix_json, app_rules_json, domain_rules_json,
                safe_search_enabled, doh_blocked, hmac_signature, updated_at, updated_by
            ) VALUES (?, 1, ?, ?, ?, ?, ?, 1, 1, ?, ?, 'system');
            ''', (
                child_id, 5400, 7200,
                json.dumps(sched),
                json.dumps(app_rules, ensure_ascii=False),
                json.dumps(dom_rules, ensure_ascii=False),
                sig, now
            ))
            
            cursor.execute('''
            INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
            VALUES ('system', ?, 'init_default_policy', 'policy', NULL, 'Chính sách mặc định lứa tuổi 6-11', '127.0.0.1', ?);
            ''', (child_id, now))

        # 4. Demo Device: Laptop Bé An
        dev_id = "demo-device-bean-01"
        cursor.execute("SELECT id FROM devices WHERE id = ?;", (dev_id,))
        if not cursor.fetchone():
            cursor.execute('''
            INSERT INTO devices (id, child_id, device_name, fingerprint, status, last_heartbeat, used_quota_today, created_at)
            VALUES (?, ?, 'Laptop-Bé-An-Win11', 'WIN11-DEMO-FINGERPRINT', 'active', 0, 2400, ?);
            ''', (dev_id, child_id, now - (86400 * 7)))

        # 5. Demo 7-Day Usage Activity
        cursor.execute("SELECT COUNT(*) as count FROM events WHERE child_id = ?;", (child_id,))
        if cursor.fetchone()["count"] == 0:
            sample_apps = [
                ("zoom.exe", 1800),
                ("msedge.exe", 1200),
                ("scratch.exe", 900),
                ("word.exe", 600)
            ]
            sample_domains = ["khanacademy.org", "scratch.mit.edu", "wikipedia.org", "olm.vn", "code.org"]

            for day_offset in range(6, -1, -1):
                day_ts = now - (day_offset * 86400)
                for app_name, dur in sample_apps:
                    cursor.execute('''
                    INSERT INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
                    VALUES (?, ?, ?, ?, 'app_start', ?, ?, 1);
                    ''', (str(uuid.uuid4()), day_ts, dev_id, child_id, app_name, dur))
                for dom in sample_domains:
                    cursor.execute('''
                    INSERT INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
                    VALUES (?, ?, ?, ?, 'domain_query', ?, 0, 1);
                    ''', (str(uuid.uuid4()), day_ts, dev_id, child_id, dom))

            # Blocked events
            cursor.execute('''
            INSERT INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
            VALUES (?, ?, ?, ?, 'blocked_app', 'discord.exe', 0, 1);
            ''', (str(uuid.uuid4()), now - 1800, dev_id, child_id))
            cursor.execute('''
            INSERT INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
            VALUES (?, ?, ?, ?, 'blocked_domain', 'tiktok.com', 0, 1);
            ''', (str(uuid.uuid4()), now - 900, dev_id, child_id))

        # 6. Sample Child Request
        cursor.execute("SELECT id FROM child_requests WHERE child_id = ?;", (child_id,))
        if not cursor.fetchone():
            cursor.execute('''
            INSERT INTO child_requests (child_id, device_id, type, subject, reason, status, created_at)
            VALUES (?, ?, 'more_time_15', '15_mins', 'Con cần thêm 15 phút để nộp bài tập toán trên OLM', 'pending', ?);
            ''', (child_id, dev_id, now - 300))


        # 7. Sample Reward Tasks (F1 Bonus)
        cursor.execute("SELECT COUNT(*) as count FROM reward_tasks WHERE child_id = ?;", (child_id,))
        if cursor.fetchone()["count"] == 0:
            cursor.execute('''
            INSERT INTO reward_tasks (child_id, title, description, reward_minutes, status, created_at)
            VALUES 
                (?, 'Hoàn thành 5 bài tập Toán trên OLM.vn', 'Làm đúng tối thiểu 80% số câu hỏi', 15, 'completed_by_child', ?),
                (?, 'Đọc 1 chương sách Khoa học tự nhiên', 'Tóm tắt lại 3 ý chính cho ba mẹ nghe', 20, 'assigned', ?),
                (?, 'Dọn dẹp góc học tập gọn gàng', 'Sắp xếp lại sách vở sau khi học xong', 15, 'assigned', ?);
            ''', (child_id, now - 1200, child_id, now - 600, child_id, now - 300))

        # Ensure existing policies have daily_limit_minutes in app_rules
        cursor.execute("SELECT id, app_rules_json FROM policies WHERE child_id = ?;", (child_id,))
        existing_pol = cursor.fetchone()
        if existing_pol:
            rules = json.loads(existing_pol["app_rules_json"])
            changed = False
            for r in rules:
                if "daily_limit_minutes" not in r:
                    changed = True
                    if r["name"] == "roblox.exe":
                        r["action"] = "allow"
                        r["daily_limit_minutes"] = 45
                    elif r["name"] == "msedge.exe":
                        r["daily_limit_minutes"] = 60
                    else:
                        r["daily_limit_minutes"] = 0
            if changed:
                cursor.execute("UPDATE policies SET app_rules_json = ? WHERE id = ?;", (json.dumps(rules, ensure_ascii=False), existing_pol["id"]))
