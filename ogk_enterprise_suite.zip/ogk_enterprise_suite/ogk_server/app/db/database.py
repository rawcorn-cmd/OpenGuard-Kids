import sqlite3
import json
import time
from contextlib import contextmanager
from typing import Generator
from app.core.config import DB_PATH

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn

@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS parents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            totp_secret TEXT,
            totp_enabled INTEGER DEFAULT 0,
            failed_login_count INTEGER DEFAULT 0,
            locked_until INTEGER DEFAULT 0,
            role TEXT DEFAULT 'parent',
            created_at INTEGER NOT NULL
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS children (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id INTEGER NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            birth_year INTEGER NOT NULL,
            avatar TEXT DEFAULT '👦',
            created_at INTEGER NOT NULL
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS devices (
            id TEXT PRIMARY KEY,
            child_id INTEGER NOT NULL REFERENCES children(id) ON DELETE CASCADE,
            device_name TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            status TEXT DEFAULT 'active',
            last_heartbeat INTEGER DEFAULT 0,
            used_quota_today INTEGER DEFAULT 0,
            extra_minutes_today INTEGER DEFAULT 0,
            running_apps_json TEXT DEFAULT '[]',
            created_at INTEGER NOT NULL
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS enrollment_codes (
            code TEXT PRIMARY KEY,
            child_id INTEGER NOT NULL REFERENCES children(id) ON DELETE CASCADE,
            created_by_parent_id INTEGER NOT NULL,
            expires_at INTEGER NOT NULL,
            is_used INTEGER DEFAULT 0,
            device_fingerprint TEXT
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER UNIQUE NOT NULL REFERENCES children(id) ON DELETE CASCADE,
            version INTEGER DEFAULT 1,
            daily_quota_weekday_sec INTEGER DEFAULT 5400,
            daily_quota_weekend_sec INTEGER DEFAULT 7200,
            category_quotas_json TEXT DEFAULT '{"education": 0, "gaming": 2700, "social": 1800, "entertainment": 3600}',
            schedule_matrix_json TEXT NOT NULL,
            app_rules_json TEXT NOT NULL,
            domain_rules_json TEXT NOT NULL,
            safe_search_enabled INTEGER DEFAULT 1,
            doh_blocked INTEGER DEFAULT 1,
            hmac_signature TEXT NOT NULL,
            updated_at INTEGER NOT NULL,
            updated_by TEXT NOT NULL
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            idempotency_key TEXT UNIQUE NOT NULL,
            ts INTEGER NOT NULL,
            device_id TEXT NOT NULL,
            child_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            subject TEXT NOT NULL,
            duration_sec INTEGER DEFAULT 0,
            policy_id INTEGER NOT NULL
        );
        ''')
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_child_ts ON events(child_id, ts);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_idempotency ON events(idempotency_key);")

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS child_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER NOT NULL REFERENCES children(id) ON DELETE CASCADE,
            device_id TEXT NOT NULL,
            type TEXT NOT NULL,
            subject TEXT NOT NULL,
            reason TEXT,
            status TEXT DEFAULT 'pending',
            created_at INTEGER NOT NULL,
            resolved_at INTEGER,
            resolved_by TEXT
        );
        ''')

        # Tasks & Reward System (F1 Bonus - Cơ chế thưởng giờ khi hoàn thành nhiệm vụ)
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS reward_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER NOT NULL REFERENCES children(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            description TEXT,
            reward_minutes INTEGER DEFAULT 15,
            status TEXT DEFAULT 'assigned', -- assigned, completed_by_child, rewarded
            created_at INTEGER NOT NULL,
            completed_at INTEGER,
            rewarded_at INTEGER
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT NOT NULL,
            child_id INTEGER,
            action TEXT NOT NULL,
            target_type TEXT NOT NULL,
            old_value TEXT,
            new_value TEXT,
            ip_address TEXT,
            timestamp INTEGER NOT NULL
        );
        ''')
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_child ON audit_logs(child_id, timestamp);")

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS pending_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT NOT NULL,
            command TEXT NOT NULL,
            parameters_json TEXT,
            created_at INTEGER NOT NULL,
            delivered INTEGER DEFAULT 0
        );
        ''')
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_commands_device ON pending_commands(device_id, delivered);")

        # Auto-migrations for existing databases
        for col_sql in [
            "ALTER TABLE devices ADD COLUMN extra_minutes_today INTEGER DEFAULT 0;",
            "ALTER TABLE parents ADD COLUMN totp_secret TEXT;",
            "ALTER TABLE parents ADD COLUMN totp_enabled INTEGER DEFAULT 0;",
            "ALTER TABLE policies ADD COLUMN category_quotas_json TEXT;",
            "ALTER TABLE devices ADD COLUMN running_apps_json TEXT DEFAULT '[]';"
        ]:
            try:
                cursor.execute(col_sql)
            except sqlite3.OperationalError:
                pass
