import json
import logging
from typing import Dict, Any, Optional
from fastapi import WebSocket

logger = logging.getLogger("OGK-WebSocket")

class WebSocketManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, device_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[device_id] = websocket
        logger.info(f"Agent device connected via WebSocket: {device_id}")

    def disconnect(self, device_id: str):
        if device_id in self.active_connections:
            del self.active_connections[device_id]
            logger.info(f"Agent device disconnected: {device_id}")

    def is_online(self, device_id: str) -> bool:
        return device_id in self.active_connections

    async def send_command(self, device_id: str, command: str, params: Optional[Dict[str, Any]] = None) -> bool:
        payload = {
            "type": "command",
            "command": command,
            "params": params or {}
        }
        if device_id in self.active_connections:
            ws = self.active_connections[device_id]
            try:
                await ws.send_text(json.dumps(payload))
                logger.info(f"Command '{command}' sent to {device_id} over WebSocket")
                return True
            except Exception as e:
                logger.error(f"Failed to send command over WebSocket to {device_id}: {e}")
                self.disconnect(device_id)
        return False

ws_manager = WebSocketManager()
