import hashlib
import hmac
import base64
import json
import os
import secrets
import struct
import time
from typing import Tuple, Optional, Dict, Any
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.core.config import SECRET_KEY, HMAC_POLICY_KEY

# Derive 256-bit AES key from master SECRET_KEY
AES_KEY = hashlib.sha256(SECRET_KEY.encode('utf-8')).digest()

# --- 1. Scrypt Password Hashing (F5) ---

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    key = hashlib.scrypt(password.encode('utf-8'), salt=salt, n=16384, r=8, p=1, maxmem=0)
    return f"scrypt$16384$8$1${salt.hex()}${key.hex()}"

def verify_password(password: str, hashed_str: str) -> bool:
    try:
        parts = hashed_str.split("$")
        if len(parts) != 6 or parts[0] != "scrypt":
            return False
        n = int(parts[1])
        r = int(parts[2])
        p = int(parts[3])
        salt = bytes.fromhex(parts[4])
        expected_key = bytes.fromhex(parts[5])
        computed_key = hashlib.scrypt(password.encode('utf-8'), salt=salt, n=n, r=r, p=p, maxmem=0)
        return secrets.compare_digest(computed_key, expected_key)
    except Exception:
        return False

def validate_password_strength(password: str) -> Tuple[bool, str]:
    if len(password) < 10:
        return False, "Mật khẩu phải có tối thiểu 10 ký tự theo quy định bảo mật F5."
    return True, ""

# --- 2. AES-256-GCM Field Encryption (F5 Storage Security) ---

def encrypt_sensitive_field(plaintext: str) -> str:
    """Encrypts sensitive strings using AES-256-GCM with a random 96-bit nonce."""
    if not plaintext:
        return ""
    aesgcm = AESGCM(AES_KEY)
    nonce = os.urandom(12)
    ct = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
    return "aesgcm$" + base64.urlsafe_b64encode(nonce + ct).decode('utf-8')

def decrypt_sensitive_field(ciphertext: str) -> str:
    """Decrypts AES-256-GCM encrypted strings."""
    if not ciphertext or not ciphertext.startswith("aesgcm$"):
        return ciphertext
    try:
        raw = base64.urlsafe_b64decode(ciphertext[7:].encode('utf-8'))
        nonce, ct = raw[:12], raw[12:]
        aesgcm = AESGCM(AES_KEY)
        return aesgcm.decrypt(nonce, ct, None).decode('utf-8')
    except Exception:
        return ciphertext

# --- 3. TOTP Two-Factor Authentication (RFC 6238 Bonus F5) ---

def generate_totp_secret() -> str:
    return base64.b32encode(os.urandom(10)).decode('utf-8')

def get_totp_code(secret_b32: str, time_step: int = 30, offset: int = 0) -> str:
    try:
        key = base64.b32decode(secret_b32.upper() + "=" * ((8 - len(secret_b32) % 8) % 8))
        counter = int(time.time() // time_step) + offset
        msg = struct.pack(">Q", counter)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        pos = digest[19] & 0x0F
        code_int = (struct.unpack(">I", digest[pos:pos+4])[0] & 0x7FFFFFFF) % 1000000
        return f"{code_int:06d}"
    except Exception:
        return "000000"

def verify_totp_code(secret_b32: str, code: str) -> bool:
    if not secret_b32 or not code:
        return False
    clean_code = code.strip()
    for offset in (-1, 0, 1):
        if secrets.compare_digest(get_totp_code(secret_b32, offset=offset), clean_code):
            return True
    return False

# --- 4. Signed Session & Device Tokens ---

def _b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode('utf-8').rstrip('=')

def _b64decode(s: str) -> bytes:
    padding = '=' * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + padding)

def create_signed_token(payload: Dict[str, Any], expires_in_seconds: int, secret: str = SECRET_KEY) -> str:
    payload_copy = dict(payload)
    payload_copy["exp"] = int(time.time()) + expires_in_seconds
    payload_copy["iat"] = int(time.time())
    data_str = json.dumps(payload_copy, sort_keys=True, separators=(',', ':'))
    data_b64 = _b64encode(data_str.encode('utf-8'))
    sig = hmac.new(secret.encode('utf-8'), data_b64.encode('utf-8'), hashlib.sha256).digest()
    sig_b64 = _b64encode(sig)
    return f"{data_b64}.{sig_b64}"

def verify_signed_token(token: str, secret: str = SECRET_KEY) -> Optional[Dict[str, Any]]:
    try:
        if not token or "." not in token:
            return None
        data_b64, sig_b64 = token.split(".", 1)
        expected_sig = hmac.new(secret.encode('utf-8'), data_b64.encode('utf-8'), hashlib.sha256).digest()
        actual_sig = _b64decode(sig_b64)
        if not secrets.compare_digest(expected_sig, actual_sig):
            return None
        payload = json.loads(_b64decode(data_b64).decode('utf-8'))
        if "exp" in payload and payload["exp"] < int(time.time()):
            return None
        return payload
    except Exception:
        return None

# --- 5. Policy HMAC Integrity Signature (F4) ---

def sign_policy(policy_data: Dict[str, Any], secret: str = HMAC_POLICY_KEY) -> str:
    canonical_json = json.dumps(policy_data, sort_keys=True, separators=(',', ':'))
    return hmac.new(secret.encode('utf-8'), canonical_json.encode('utf-8'), hashlib.sha256).hexdigest()

def verify_policy_signature(policy_data: Dict[str, Any], signature: str, secret: str = HMAC_POLICY_KEY) -> bool:
    expected_sig = sign_policy(policy_data, secret)
    return secrets.compare_digest(expected_sig, signature)

def generate_csrf_token() -> str:
    return secrets.token_hex(24)

def generate_enrollment_code() -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(8))
