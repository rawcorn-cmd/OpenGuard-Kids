import time
from fastapi import Request, HTTPException
from app.db.database import get_db
from app.core.security import verify_signed_token

def get_current_parent(request: Request) -> dict:
    token = request.cookies.get("ogk_session")
    if not token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1]

    if not token:
        raise HTTPException(status_code=401, detail="Vui lòng đăng nhập để tiếp tục.")

    payload = verify_signed_token(token)
    if not payload or payload.get("role") not in ("parent", "admin"):
        raise HTTPException(status_code=401, detail="Phiên làm việc hết hạn hoặc không hợp lệ.")

    parent_id = payload.get("sub")
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, full_name, role, locked_until FROM parents WHERE id = ?;", (parent_id,))
        parent = cursor.fetchone()
        if not parent:
            raise HTTPException(status_code=401, detail="Tài khoản không tồn tại.")
        if parent["locked_until"] > int(time.time()):
            raise HTTPException(status_code=403, detail="Tài khoản đang bị tạm khóa do nhập sai mật khẩu nhiều lần.")
        return dict(parent)

def get_current_device(request: Request) -> dict:
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Thiếu token xác thực thiết bị.")

    token = auth_header.split(" ", 1)[1]
    payload = verify_signed_token(token)
    if not payload or payload.get("type") != "device_access":
        raise HTTPException(status_code=401, detail="Token thiết bị hết hạn hoặc không hợp lệ.")

    device_id = payload.get("sub")
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM devices WHERE id = ? AND status = 'active';", (device_id,))
        device = cursor.fetchone()
        if not device:
            raise HTTPException(status_code=401, detail="Thiết bị không tồn tại hoặc đã bị thu hồi quyền truy cập.")
        return dict(device)
