import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = os.getenv("OGK_DB_PATH", str(DATA_DIR / "ogk_server.db"))
SECRET_KEY = os.getenv("OGK_SECRET_KEY", "ogk_super_secret_master_key_for_jwt_and_sessions_2026")
HMAC_POLICY_KEY = os.getenv("OGK_HMAC_POLICY_KEY", "ogk_policy_integrity_hmac_secret_key_v1")

SESSION_EXPIRE_HOURS = 12
ACCESS_TOKEN_EXPIRE_MINUTES = 15
REFRESH_TOKEN_EXPIRE_DAYS = 30
ENROLLMENT_CODE_EXPIRE_MINUTES = 10
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_MINUTES = 15
DATA_RETENTION_DAYS = 90
