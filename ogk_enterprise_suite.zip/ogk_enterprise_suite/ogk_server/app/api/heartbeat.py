import time
import json
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from app.db.database import get_db
from app.core.dependencies import get_current_device

router = APIRouter(prefix="/api/v1/heartbeat", tags=["Heartbeat"])

class HeartbeatRequest(BaseModel):
    policy_version: int
    used_quota_today_sec: int
    system_status: str = "ok"
    agent_uptime_sec: Optional[int] = 0
    running_apps: Optional[List[Dict[str, Any]]] = []

@router.post("")
def receive_heartbeat(req: HeartbeatRequest, device: dict = Depends(get_current_device)):
    now = int(time.time())
    device_id = device["id"]
    child_id = device["child_id"]
    running_apps_str = json.dumps(req.running_apps or [], ensure_ascii=False)

    with get_db() as conn:
        cursor = conn.cursor()
        
        cursor.execute('''
        UPDATE devices SET 
            last_heartbeat = ?, 
            used_quota_today = ?,
            running_apps_json = ?
        WHERE id = ?;
        ''', (now, req.used_quota_today_sec, running_apps_str, device_id))

        cursor.execute("SELECT version FROM policies WHERE child_id = ?;", (child_id,))
        policy_row = cursor.fetchone()
        latest_policy_version = policy_row["version"] if policy_row else 1

        cursor.execute('''
        SELECT id, command, parameters_json FROM pending_commands 
        WHERE device_id = ? AND delivered = 0 
        ORDER BY created_at ASC;
        ''', (device_id,))
        cmd_rows = cursor.fetchall()
        
        commands = []
        cmd_ids = []
        for row in cmd_rows:
            cmd_ids.append(row["id"])
            commands.append({
                "command": row["command"],
                "params": json.loads(row["parameters_json"]) if row["parameters_json"] else {}
            })

        if cmd_ids:
            placeholders = ",".join("?" * len(cmd_ids))
            cursor.execute(f"UPDATE pending_commands SET delivered = 1 WHERE id IN ({placeholders});", cmd_ids)

    return {
        "status": "success",
        "server_time": now,
        "latest_policy_version": latest_policy_version,
        "policy_outdated": (req.policy_version < latest_policy_version),
        "commands": commands
    }
