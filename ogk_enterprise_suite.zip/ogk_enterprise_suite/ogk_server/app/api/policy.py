import time
import json
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from typing import List, Dict, Any
from app.db.database import get_db
from app.core.security import sign_policy
from app.core.dependencies import get_current_parent, get_current_device
from app.services.ws_manager import ws_manager

router = APIRouter(prefix="/api/v1/policy", tags=["Policy"])

class PolicyUpdateRequest(BaseModel):
    daily_quota_weekday_sec: int
    daily_quota_weekend_sec: int
    schedule_matrix: List[List[int]]
    app_rules: List[Dict[str, Any]]
    domain_rules: List[Dict[str, Any]]
    safe_search_enabled: bool = True
    doh_blocked: bool = True

@router.get("")
def get_policy_for_device(device: dict = Depends(get_current_device)):
    child_id = device["child_id"]
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM policies WHERE child_id = ?;", (child_id,))
        policy = cursor.fetchone()
        if not policy:
            raise HTTPException(status_code=404, detail="Chưa có chính sách nào cho trẻ này.")

        data = {
            "child_id": policy["child_id"],
            "version": policy["version"],
            "daily_quota_weekday_sec": policy["daily_quota_weekday_sec"],
            "daily_quota_weekend_sec": policy["daily_quota_weekend_sec"],
            "schedule_matrix": json.loads(policy["schedule_matrix_json"]),
            "app_rules": json.loads(policy["app_rules_json"]),
            "domain_rules": json.loads(policy["domain_rules_json"]),
            "safe_search_enabled": bool(policy["safe_search_enabled"]),
            "doh_blocked": bool(policy["doh_blocked"]),
            "updated_at": policy["updated_at"],
            "hmac_signature": policy["hmac_signature"]
        }
        return data

@router.get("/child/{child_id}")
def get_policy_for_parent(child_id: int, parent: dict = Depends(get_current_parent)):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ thuộc quyền quản lý.")

        cursor.execute("SELECT * FROM policies WHERE child_id = ?;", (child_id,))
        policy = cursor.fetchone()
        if not policy:
            raise HTTPException(status_code=404, detail="Chưa thiết lập chính sách cho trẻ này.")

        return {
            "child_id": policy["child_id"],
            "version": policy["version"],
            "daily_quota_weekday_sec": policy["daily_quota_weekday_sec"],
            "daily_quota_weekend_sec": policy["daily_quota_weekend_sec"],
            "schedule_matrix": json.loads(policy["schedule_matrix_json"]),
            "app_rules": json.loads(policy["app_rules_json"]),
            "domain_rules": json.loads(policy["domain_rules_json"]),
            "safe_search_enabled": bool(policy["safe_search_enabled"]),
            "doh_blocked": bool(policy["doh_blocked"]),
            "updated_at": policy["updated_at"]
        }

@router.put("/child/{child_id}")
async def update_policy(child_id: int, req: PolicyUpdateRequest, request: Request, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    client_ip = request.client.host if request.client else "127.0.0.1"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        child = cursor.fetchone()
        if not child:
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ thuộc quyền quản lý.")

        cursor.execute("SELECT * FROM policies WHERE child_id = ?;", (child_id,))
        old_policy = cursor.fetchone()
        new_version = (old_policy["version"] + 1) if old_policy else 1

        policy_payload = {
            "child_id": child_id,
            "version": new_version,
            "daily_quota_weekday_sec": req.daily_quota_weekday_sec,
            "daily_quota_weekend_sec": req.daily_quota_weekend_sec,
            "schedule_matrix": req.schedule_matrix,
            "app_rules": req.app_rules,
            "domain_rules": req.domain_rules,
            "safe_search_enabled": int(req.safe_search_enabled),
            "doh_blocked": int(req.doh_blocked)
        }
        sig = sign_policy(policy_payload)

        matrix_json = json.dumps(req.schedule_matrix)
        app_rules_json = json.dumps(req.app_rules, ensure_ascii=False)
        domain_rules_json = json.dumps(req.domain_rules, ensure_ascii=False)

        if old_policy:
            old_summary = f"v{old_policy['version']} (Quota: {old_policy['daily_quota_weekday_sec']//60}p / {old_policy['daily_quota_weekend_sec']//60}p)"
            cursor.execute('''
            UPDATE policies SET
                version = ?,
                daily_quota_weekday_sec = ?,
                daily_quota_weekend_sec = ?,
                schedule_matrix_json = ?,
                app_rules_json = ?,
                domain_rules_json = ?,
                safe_search_enabled = ?,
                doh_blocked = ?,
                hmac_signature = ?,
                updated_at = ?,
                updated_by = ?
            WHERE child_id = ?;
            ''', (
                new_version,
                req.daily_quota_weekday_sec,
                req.daily_quota_weekend_sec,
                matrix_json,
                app_rules_json,
                domain_rules_json,
                int(req.safe_search_enabled),
                int(req.doh_blocked),
                sig,
                now,
                parent["email"],
                child_id
            ))
        else:
            old_summary = "Chưa có chính sách"
            cursor.execute('''
            INSERT INTO policies (
                child_id, version, daily_quota_weekday_sec, daily_quota_weekend_sec,
                schedule_matrix_json, app_rules_json, domain_rules_json,
                safe_search_enabled, doh_blocked, hmac_signature, updated_at, updated_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ''', (
                child_id, new_version,
                req.daily_quota_weekday_sec, req.daily_quota_weekend_sec,
                matrix_json, app_rules_json, domain_rules_json,
                int(req.safe_search_enabled), int(req.doh_blocked),
                sig, now, parent["email"]
            ))

        new_summary = f"v{new_version} (Quota: {req.daily_quota_weekday_sec//60}p / {req.daily_quota_weekend_sec//60}p)"

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'update_policy', 'policy', ?, ?, ?, ?);
        ''', (parent["email"], child_id, old_summary, new_summary, client_ip, now))

        cursor.execute("SELECT id FROM devices WHERE child_id = ? AND status = 'active';", (child_id,))
        devices = cursor.fetchall()

    for dev in devices:
        await ws_manager.send_command(dev["id"], "reload_policy", {"version": new_version})

    return {
        "status": "success",
        "message": f"Cập nhật chính sách thành công (phiên bản v{new_version})",
        "version": new_version,
        "hmac_signature": sig
    }
