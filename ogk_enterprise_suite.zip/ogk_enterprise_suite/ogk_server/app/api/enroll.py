import json
import time
import uuid
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from app.db.database import get_db
from app.core.config import ENROLLMENT_CODE_EXPIRE_MINUTES, ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_DAYS
from app.core.security import generate_enrollment_code, create_signed_token, verify_signed_token
from app.core.dependencies import get_current_parent

router = APIRouter(prefix="/api/v1/enroll", tags=["Enrollment"])

class CreateCodeRequest(BaseModel):
    child_id: int

class ClaimCodeRequest(BaseModel):
    code: str
    device_name: str
    fingerprint: str

class RefreshTokenRequest(BaseModel):
    refresh_token: str

@router.post("/create-code")
def create_code(req: CreateCodeRequest, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    expires_at = now + (ENROLLMENT_CODE_EXPIRE_MINUTES * 60)
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM children WHERE id = ? AND parent_id = ?;", (req.child_id, parent["id"]))
        child = cursor.fetchone()
        if not child:
            raise HTTPException(status_code=404, detail="Không tìm thấy hồ sơ của trẻ.")

        code = generate_enrollment_code()
        cursor.execute('''
        INSERT INTO enrollment_codes (code, child_id, created_by_parent_id, expires_at, is_used)
        VALUES (?, ?, ?, ?, 0);
        ''', (code, req.child_id, parent["id"], expires_at))

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'create_enrollment_code', 'device', NULL, ?, '127.0.0.1', ?);
        ''', (parent["email"], req.child_id, f"Tạo mã ghép đôi {code} (hạn 10 phút)", now))

    return {
        "status": "success",
        "code": code,
        "child_name": child["name"],
        "expires_in_seconds": ENROLLMENT_CODE_EXPIRE_MINUTES * 60,
        "expires_at": expires_at
    }

@router.post("/claim")
def claim_code(req: ClaimCodeRequest):
    now = int(time.time())
    code_upper = req.code.strip().upper()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM enrollment_codes WHERE code = ?;", (code_upper,))
        record = cursor.fetchone()

        if not record:
            raise HTTPException(status_code=400, detail="Mã ghép đôi không tồn tại hoặc đã bị xóa.")
        if record["is_used"]:
            raise HTTPException(status_code=400, detail="Mã ghép đôi này đã được sử dụng.")
        if record["expires_at"] < now:
            raise HTTPException(status_code=400, detail="Mã ghép đôi đã hết hạn (quá 10 phút).")

        child_id = record["child_id"]
        device_id = str(uuid.uuid4())

        cursor.execute('''
        INSERT INTO devices (id, child_id, device_name, fingerprint, status, last_heartbeat, created_at)
        VALUES (?, ?, ?, ?, 'active', ?, ?);
        ''', (device_id, child_id, req.device_name, req.fingerprint, now, now))

        cursor.execute("UPDATE enrollment_codes SET is_used = 1, device_fingerprint = ? WHERE code = ?;", 
                       (req.fingerprint, code_upper))

        cursor.execute("SELECT name FROM children WHERE id = ?;", (child_id,))
        child = cursor.fetchone()

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES ('agent_client', ?, 'device_enrolled', 'device', NULL, ?, '127.0.0.1', ?);
        ''', (child_id, f"Ghép đôi thành công thiết bị '{req.device_name}' ({device_id[:8]})", now))

    access_token = create_signed_token(
        {"sub": device_id, "child_id": child_id, "type": "device_access"},
        ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )
    refresh_token = create_signed_token(
        {"sub": device_id, "child_id": child_id, "type": "device_refresh"},
        REFRESH_TOKEN_EXPIRE_DAYS * 86400
    )

    return {
        "status": "success",
        "device_id": device_id,
        "child_id": child_id,
        "child_name": child["name"] if child else "Bé",
        "access_token": access_token,
        "refresh_token": refresh_token,
        "access_token_expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }

@router.post("/refresh")
def refresh_token(req: RefreshTokenRequest):
    payload = verify_signed_token(req.refresh_token)
    if not payload or payload.get("type") != "device_refresh":
        raise HTTPException(status_code=401, detail="Refresh token không hợp lệ hoặc đã hết hạn.")

    device_id = payload.get("sub")
    child_id = payload.get("child_id")

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT status FROM devices WHERE id = ?;", (device_id,))
        device = cursor.fetchone()
        if not device or device["status"] != "active":
            raise HTTPException(status_code=401, detail="Thiết bị đã bị vô hiệu hóa.")

    new_access_token = create_signed_token(
        {"sub": device_id, "child_id": child_id, "type": "device_access"},
        ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )

    return {
        "status": "success",
        "access_token": new_access_token,
        "access_token_expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }


@router.get("/devices/child/{child_id}")
def list_child_devices(child_id: int, parent: dict = Depends(get_current_parent)):
    """Lists all enrolled devices for a child with live online status."""
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ.")

        cursor.execute('''
        SELECT id, device_name, fingerprint, status, last_heartbeat, used_quota_today, running_apps_json, created_at
        FROM devices WHERE child_id = ? AND status = 'active'
        ORDER BY last_heartbeat DESC;
        ''', (child_id,))
        rows = cursor.fetchall()

        devices = []
        for r in rows:
            is_online = (r["last_heartbeat"] > 0) and (now - r["last_heartbeat"] <= 30)
            try:
                running_apps = json.loads(r["running_apps_json"] or "[]")
            except Exception:
                running_apps = []
            devices.append({
                "id": r["id"],
                "device_name": r["device_name"],
                "fingerprint": r["fingerprint"],
                "is_online": is_online,
                "last_seen_sec_ago": now - r["last_heartbeat"],
                "used_quota_today_sec": r["used_quota_today"],
                "running_apps": running_apps
            })
        return devices
