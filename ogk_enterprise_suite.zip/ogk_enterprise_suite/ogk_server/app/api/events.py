import time
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from app.db.database import get_db
from app.core.config import DATA_RETENTION_DAYS
from app.core.dependencies import get_current_device, get_current_parent

router = APIRouter(prefix="/api/v1/events", tags=["Events"])

VALID_EVENT_TYPES = {
    "app_start", "app_stop", "domain_query", "blocked_app", 
    "blocked_domain", "quota_warning", "locked", "unlock_request", 
    "override_granted", "clock_tampering"
}

class EventItem(BaseModel):
    idempotency_key: str
    ts: int
    type: str
    subject: str
    duration_sec: int = 0
    policy_id: int = 1

class BatchEventsRequest(BaseModel):
    events: List[EventItem]

@router.post("/batch")
def receive_events_batch(req: BatchEventsRequest, device: dict = Depends(get_current_device)):
    device_id = device["id"]
    child_id = device["child_id"]
    inserted_count = 0
    duplicates_count = 0

    with get_db() as conn:
        cursor = conn.cursor()
        for ev in req.events:
            if ev.type not in VALID_EVENT_TYPES:
                continue

            clean_subject = ev.subject.replace("https://", "").replace("http://", "").split("/")[0]

            try:
                cursor.execute('''
                INSERT INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                ''', (ev.idempotency_key, ev.ts, device_id, child_id, ev.type, clean_subject, ev.duration_sec, ev.policy_id))
                inserted_count += 1
            except Exception:
                duplicates_count += 1

    return {
        "status": "success",
        "inserted": inserted_count,
        "duplicates_skipped": duplicates_count
    }

@router.delete("/purge/child/{child_id}")
def purge_child_data(child_id: int, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        child = cursor.fetchone()
        if not child:
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ thuộc quyền quản lý.")

        cursor.execute("DELETE FROM events WHERE child_id = ?;", (child_id,))
        deleted_events = cursor.rowcount

        cursor.execute("DELETE FROM child_requests WHERE child_id = ?;", (child_id,))
        cursor.execute("UPDATE devices SET used_quota_today = 0 WHERE child_id = ?;", (child_id,))

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'purge_all_child_data', 'privacy', ?, 'Đã xóa toàn bộ dữ liệu hoạt động', '127.0.0.1', ?);
        ''', (parent["email"], child_id, f"Xóa {deleted_events} bản ghi sự kiện", now))

    return {
        "status": "success",
        "message": f"Đã xóa vĩnh viễn toàn bộ {deleted_events} sự kiện và lịch sử của {child['name']}.",
        "deleted_events": deleted_events
    }

@router.post("/retention/cleanup")
def cleanup_expired_retention():
    cutoff_ts = int(time.time()) - (DATA_RETENTION_DAYS * 86400)
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM events WHERE ts < ?;", (cutoff_ts,))
        deleted_count = cursor.rowcount
    return {
        "status": "success",
        "message": f"Dọn dẹp hoàn tất: Đã xóa {deleted_count} sự kiện cũ quá {DATA_RETENTION_DAYS} ngày.",
        "deleted_count": deleted_count
    }
