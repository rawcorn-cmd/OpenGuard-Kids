import time
from fastapi import APIRouter, HTTPException, Request, Response, Depends
from pydantic import BaseModel
from app.db.database import get_db
from app.core.config import SESSION_EXPIRE_HOURS, MAX_LOGIN_ATTEMPTS, LOCKOUT_MINUTES
from app.core.security import hash_password, verify_password, validate_password_strength, create_signed_token
from app.core.dependencies import get_current_parent

router = APIRouter(prefix="/api/v1/auth", tags=["Auth"])

class RegisterRequest(BaseModel):
    email: str
    full_name: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

@router.post("/register")
def register(req: RegisterRequest, response: Response):
    valid, msg = validate_password_strength(req.password)
    if not valid:
        raise HTTPException(status_code=400, detail=msg)

    now = int(time.time())
    pwd_hash = hash_password(req.password)
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM parents WHERE email = ?;", (req.email,))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail="Email này đã được đăng ký.")

        cursor.execute('''
        INSERT INTO parents (email, full_name, password_hash, role, created_at)
        VALUES (?, ?, ?, 'parent', ?);
        ''', (req.email, req.full_name, pwd_hash, now))
        parent_id = cursor.lastrowid

    token = create_signed_token({"sub": parent_id, "role": "parent", "email": req.email}, SESSION_EXPIRE_HOURS * 3600)
    response.set_cookie(
        key="ogk_session",
        value=token,
        max_age=SESSION_EXPIRE_HOURS * 3600,
        httponly=True,
        samesite="lax",
        secure=False
    )
    return {"status": "success", "message": "Đăng ký tài khoản thành công", "parent_id": parent_id}

@router.post("/login")
def login(req: LoginRequest, response: Response):
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM parents WHERE email = ?;", (req.email,))
        parent = cursor.fetchone()
        
        if not parent:
            raise HTTPException(status_code=401, detail="Email hoặc mật khẩu không chính xác.")

        if parent["locked_until"] > now:
            remaining = (parent["locked_until"] - now) // 60 + 1
            raise HTTPException(status_code=403, detail=f"Tài khoản đang bị tạm khóa do nhập sai nhiều lần. Vui lòng thử lại sau {remaining} phút.")

        if not verify_password(req.password, parent["password_hash"]):
            failed = parent["failed_login_count"] + 1
            locked_until = 0
            if failed >= MAX_LOGIN_ATTEMPTS:
                locked_until = now + (LOCKOUT_MINUTES * 60)
            cursor.execute("UPDATE parents SET failed_login_count = ?, locked_until = ? WHERE id = ?;", (failed, locked_until, parent["id"]))
            conn.commit()
            
            if failed >= MAX_LOGIN_ATTEMPTS:
                raise HTTPException(status_code=403, detail="Bạn đã nhập sai quá 5 lần. Tài khoản tạm khóa 15 phút.")
            raise HTTPException(status_code=401, detail=f"Email hoặc mật khẩu không chính xác (còn {MAX_LOGIN_ATTEMPTS - failed} lần thử).")

        cursor.execute("UPDATE parents SET failed_login_count = 0, locked_until = 0 WHERE id = ?;", (parent["id"],))

    token = create_signed_token({"sub": parent["id"], "role": parent["role"], "email": parent["email"]}, SESSION_EXPIRE_HOURS * 3600)
    response.set_cookie(
        key="ogk_session",
        value=token,
        max_age=SESSION_EXPIRE_HOURS * 3600,
        httponly=True,
        samesite="lax",
        secure=False
    )
    return {"status": "success", "message": "Đăng nhập thành công", "role": parent["role"]}

@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(key="ogk_session")
    return {"status": "success", "message": "Đã đăng xuất"}

@router.get("/me")
def me(parent: dict = Depends(get_current_parent)):
    return {
        "id": parent["id"],
        "email": parent["email"],
        "full_name": parent["full_name"],
        "role": parent["role"]
    }
