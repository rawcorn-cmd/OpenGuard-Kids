import time
from datetime import datetime, date
from fastapi import APIRouter, HTTPException, Depends
from app.db.database import get_db
from app.core.dependencies import get_current_parent, get_current_device

router = APIRouter(prefix="/api/v1/reports", tags=["Reports"])

@router.get("/summary/{child_id}")
def get_child_summary(child_id: int, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    seven_days_ago = now - (7 * 86400)

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        child = cursor.fetchone()
        if not child:
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ thuộc quyền quản lý.")

        cursor.execute('''
        SELECT date(datetime(ts, 'unixepoch', 'localtime')) as day, 
               COALESCE(SUM(duration_sec), 0) as total_sec
        FROM events 
        WHERE child_id = ? AND ts >= ? AND type IN ('app_start', 'app_stop')
        GROUP BY day 
        ORDER BY day ASC;
        ''', (child_id, seven_days_ago))
        daily_trend = [dict(r) for r in cursor.fetchall()]

        cursor.execute('''
        SELECT subject as app_name, COALESCE(SUM(duration_sec), 0) as total_sec, COUNT(*) as launch_count
        FROM events
        WHERE child_id = ? AND ts >= ? AND type IN ('app_start', 'app_stop')
        GROUP BY app_name
        ORDER BY total_sec DESC
        LIMIT 10;
        ''', (child_id, seven_days_ago))
        top_apps = [dict(r) for r in cursor.fetchall()]

        cursor.execute('''
        SELECT subject as domain, COUNT(*) as query_count
        FROM events
        WHERE child_id = ? AND ts >= ? AND type = 'domain_query'
        GROUP BY domain
        ORDER BY query_count DESC
        LIMIT 10;
        ''', (child_id, seven_days_ago))
        top_domains = [dict(r) for r in cursor.fetchall()]

        cursor.execute('''
        SELECT type, COUNT(*) as count 
        FROM events 
        WHERE child_id = ? AND ts >= ? AND type IN ('blocked_app', 'blocked_domain')
        GROUP BY type;
        ''', (child_id, seven_days_ago))
        blocked_rows = cursor.fetchall()
        blocked_summary = {r["type"]: r["count"] for r in blocked_rows}

        today_start = int(datetime.combine(date.today(), datetime.min.time()).timestamp())
        cursor.execute('''
        SELECT COALESCE(SUM(duration_sec), 0) as today_sec
        FROM events
        WHERE child_id = ? AND ts >= ? AND type IN ('app_start', 'app_stop');
        ''', (child_id, today_start))
        today_sec = cursor.fetchone()["today_sec"]

        # Fetch policy and extra minutes inside DB context
        cursor.execute("SELECT daily_quota_weekday_sec, daily_quota_weekend_sec FROM policies WHERE child_id = ?;", (child_id,))
        pol = cursor.fetchone()
        now_dt = datetime.now()
        is_weekend = (now_dt.weekday() >= 5)
        base_quota_sec = (pol["daily_quota_weekend_sec"] if is_weekend else pol["daily_quota_weekday_sec"]) if pol else 5400
        base_quota_min = base_quota_sec // 60

        # Fetch extra minutes from active devices
        cursor.execute("SELECT COALESCE(SUM(extra_minutes_today), 0) as extra_min FROM devices WHERE child_id = ? AND status = 'active';", (child_id,))
        extra_row = cursor.fetchone()
        extra_min = extra_row["extra_min"] if extra_row else 0

        total_quota_min = base_quota_min + extra_min
        used_min = round(today_sec / 60, 1)
        remaining_min = max(0.0, round(total_quota_min - used_min, 1))

    return {
        "child_id": child_id,
        "child_name": child["name"],
        "today_minutes": used_min,
        "base_quota_minutes": base_quota_min,
        "extra_minutes_granted": extra_min,
        "total_allowed_minutes": total_quota_min,
        "remaining_minutes": remaining_min,
        "daily_trend": daily_trend,
        "top_apps": top_apps,
        "top_domains": top_domains,
        "blocked_apps_count": blocked_summary.get("blocked_app", 0),
        "blocked_domains_count": blocked_summary.get("blocked_domain", 0)
    }

@router.get("/transparency/today")
def get_transparency_view(device: dict = Depends(get_current_device)):
    child_id = device["child_id"]
    today_start = int(datetime.combine(date.today(), datetime.min.time()).timestamp())

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM children WHERE id = ?;", (child_id,))
        child = cursor.fetchone()

        cursor.execute('''
        SELECT subject as app_name, COALESCE(SUM(duration_sec), 0) as total_sec
        FROM events
        WHERE child_id = ? AND ts >= ? AND type IN ('app_start', 'app_stop')
        GROUP BY app_name
        ORDER BY total_sec DESC
        LIMIT 5;
        ''', (child_id, today_start))
        apps = [dict(r) for r in cursor.fetchall()]

        cursor.execute('''
        SELECT subject as domain, COUNT(*) as query_count
        FROM events
        WHERE child_id = ? AND ts >= ? AND type = 'domain_query'
        GROUP BY domain
        ORDER BY query_count DESC
        LIMIT 5;
        ''', (child_id, today_start))
        domains = [dict(r) for r in cursor.fetchall()]

        cursor.execute('''
        SELECT COUNT(*) as blocked_count
        FROM events
        WHERE child_id = ? AND ts >= ? AND type IN ('blocked_app', 'blocked_domain');
        ''', (child_id, today_start))
        blocked_total = cursor.fetchone()["blocked_count"]

        cursor.execute('''
        SELECT action, new_value, timestamp
        FROM audit_logs
        WHERE child_id = ?
        ORDER BY timestamp DESC
        LIMIT 10;
        ''', (child_id,))
        audits = [dict(r) for r in cursor.fetchall()]

    return {
        "greeting": f"Chào {child['name'] if child else 'bé'}! Đây là những gì em đã sử dụng máy tính hôm nay:",
        "apps_used": apps,
        "websites_visited": domains,
        "blocked_interventions": blocked_total,
        "parent_rules_history": audits
    }

@router.get("/audit-logs/{child_id}")
def get_audit_logs(child_id: int, parent: dict = Depends(get_current_parent)):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Không tìm thấy trẻ thuộc quyền quản lý.")

        cursor.execute('''
        SELECT id, actor, action, target_type, old_value, new_value, ip_address, 
               datetime(timestamp, 'unixepoch', 'localtime') as formatted_time
        FROM audit_logs
        WHERE child_id = ?
        ORDER BY timestamp DESC
        LIMIT 100;
        ''', (child_id,))
        logs = [dict(r) for r in cursor.fetchall()]
        return logs
