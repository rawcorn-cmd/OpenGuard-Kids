import time
import json
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List
from app.db.database import get_db
from app.db.seed import get_default_schedule_matrix, get_default_app_rules, get_default_domain_rules
from app.core.security import sign_policy
from app.core.dependencies import get_current_parent, get_current_device
from app.services.ws_manager import ws_manager

router = APIRouter(prefix="/api/v1/children", tags=["Children & Tasks"])

class CreateChildRequest(BaseModel):
    name: str
    birth_year: int = 2016
    avatar: str = "👦"
    daily_quota_weekday_min: int = 90
    daily_quota_weekend_min: int = 120

class CreateTaskRequest(BaseModel):
    child_id: int
    title: str
    description: Optional[str] = ""
    reward_minutes: int = 15

@router.get("")
def list_children(parent: dict = Depends(get_current_parent)):
    """Lists all children profiles belonging to the authenticated parent (1:n model)."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM children WHERE parent_id = ? ORDER BY id ASC;", (parent["id"],))
        rows = cursor.fetchall()
        return [dict(r) for r in rows]

@router.post("")
def create_child(req: CreateChildRequest, parent: dict = Depends(get_current_parent)):
    """Creates a new child profile with an initial default policy signed with HMAC."""
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO children (parent_id, name, birth_year, avatar, created_at)
        VALUES (?, ?, ?, ?, ?);
        ''', (parent["id"], req.name.strip(), req.birth_year, req.avatar, now))
        child_id = cursor.lastrowid

        sched = get_default_schedule_matrix()
        app_rules = get_default_app_rules()
        dom_rules = get_default_domain_rules()
        w_sec = req.daily_quota_weekday_min * 60
        we_sec = req.daily_quota_weekend_min * 60

        policy_payload = {
            "child_id": child_id,
            "version": 1,
            "daily_quota_weekday_sec": w_sec,
            "daily_quota_weekend_sec": we_sec,
            "schedule_matrix": sched,
            "app_rules": app_rules,
            "domain_rules": dom_rules,
            "safe_search_enabled": 1,
            "doh_blocked": 1
        }
        sig = sign_policy(policy_payload)

        cursor.execute('''
        INSERT INTO policies (
            child_id, version, daily_quota_weekday_sec, daily_quota_weekend_sec,
            schedule_matrix_json, app_rules_json, domain_rules_json,
            safe_search_enabled, doh_blocked, hmac_signature, updated_at, updated_by
        ) VALUES (?, 1, ?, ?, ?, ?, ?, 1, 1, ?, ?, ?);
        ''', (
            child_id, w_sec, we_sec,
            json.dumps(sched),
            json.dumps(app_rules, ensure_ascii=False),
            json.dumps(dom_rules, ensure_ascii=False),
            sig, now, parent["email"]
        ))

        # Seed default reward tasks for the new child
        cursor.execute('''
        INSERT INTO reward_tasks (child_id, title, description, reward_minutes, status, created_at)
        VALUES (?, 'Hoàn thành bài tập Toán trên OLM', 'Làm xong 5 bài tập về nhà cô giao', 15, 'assigned', ?);
        ''', (child_id, now))

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'create_child_profile', 'child', NULL, ?, '127.0.0.1', ?);
        ''', (parent["email"], child_id, f"Tạo hồ sơ trẻ: {req.name} ({req.birth_year})", now))

    return {"status": "success", "child_id": child_id, "message": f"Đã tạo hồ sơ cho {req.name} thành công!"}

# --- REWARD TASKS ENDPOINTS (F1 BONUS) ---

@router.get("/{child_id}/tasks")
def list_tasks_for_parent(child_id: int, parent: dict = Depends(get_current_parent)):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM children WHERE id = ? AND parent_id = ?;", (child_id, parent["id"]))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Không tìm thấy hồ sơ trẻ.")

        cursor.execute("SELECT * FROM reward_tasks WHERE child_id = ? ORDER BY created_at DESC;", (child_id,))
        return [dict(r) for r in cursor.fetchall()]

@router.post("/tasks")
def create_task(req: CreateTaskRequest, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM children WHERE id = ? AND parent_id = ?;", (req.child_id, parent["id"]))
        child = cursor.fetchone()
        if not child:
            raise HTTPException(status_code=404, detail="Không tìm thấy hồ sơ trẻ.")

        cursor.execute('''
        INSERT INTO reward_tasks (child_id, title, description, reward_minutes, status, created_at)
        VALUES (?, ?, ?, ?, 'assigned', ?);
        ''', (req.child_id, req.title.strip(), req.description, req.reward_minutes, now))
        task_id = cursor.lastrowid

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'assign_reward_task', 'task', NULL, ?, '127.0.0.1', ?);
        ''', (parent["email"], req.child_id, f"Giao nhiệm vụ: {req.title} (+{req.reward_minutes}p)", now))

    return {"status": "success", "task_id": task_id, "message": f"Đã giao nhiệm vụ mới (+{req.reward_minutes} phút thưởng)!"}

@router.post("/tasks/{task_id}/approve")
async def approve_task_reward(task_id: int, parent: dict = Depends(get_current_parent)):
    """Parent confirms task completion and grants reward minutes to the child's active devices."""
    now = int(time.time())
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        SELECT t.*, c.parent_id, c.name as child_name
        FROM reward_tasks t
        JOIN children c ON t.child_id = c.id
        WHERE t.id = ?;
        ''', (task_id,))
        task = cursor.fetchone()
        if not task or task["parent_id"] != parent["id"]:
            raise HTTPException(status_code=404, detail="Không tìm thấy nhiệm vụ.")

        if task["status"] == "rewarded":
            raise HTTPException(status_code=400, detail="Nhiệm vụ này đã được trao thưởng rồi.")

        mins = task["reward_minutes"]
        child_id = task["child_id"]

        cursor.execute("UPDATE reward_tasks SET status = 'rewarded', rewarded_at = ? WHERE id = ?;", (now, task_id))
        cursor.execute("UPDATE devices SET extra_minutes_today = extra_minutes_today + ? WHERE child_id = ? AND status = 'active';", (mins, child_id))

        cursor.execute("SELECT id FROM devices WHERE child_id = ? AND status = 'active';", (child_id,))
        devs = cursor.fetchall()
        for d in devs:
            cursor.execute('''
            INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
            VALUES (?, 'add_minutes_15', ?, ?, 0);
            ''', (d["id"], json.dumps({"minutes": mins, "reason": f"Thưởng hoàn thành: {task['title']}"}), now))
            notif_task = {
                "title": f"🌟 Chúc mừng! Con nhận được +{mins} phút!",
                "message": f"Ba mẹ đã xác nhận con hoàn thành nhiệm vụ:\n'{task['title']}'\nPhần thưởng +{mins} phút đã được cộng vào đồng hồ của con!",
                "decision": "approved",
                "sound": "bonus_time",
                "timestamp": now
            }
            cursor.execute('''
            INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
            VALUES (?, 'child_notification', ?, ?, 0);
            ''', (d["id"], json.dumps(notif_task, ensure_ascii=False), now))

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'grant_task_reward', 'task', ?, ?, '127.0.0.1', ?);
        ''', (parent["email"], child_id, task["title"], f"Đã trao thưởng +{mins} phút", now))

    for d in devs:
        await ws_manager.send_command(d["id"], "add_minutes_15", {"minutes": mins})

    return {"status": "success", "message": f"Đã trao thưởng +{mins} phút cho {task['child_name']}!"}

# --- AGENT ENDPOINTS FOR CHILD TASKS ---

@router.get("/agent/tasks")
def get_agent_tasks(device: dict = Depends(get_current_device)):
    child_id = device["child_id"]
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM reward_tasks WHERE child_id = ? ORDER BY created_at DESC LIMIT 10;", (child_id,))
        return [dict(r) for r in cursor.fetchall()]

@router.post("/agent/tasks/{task_id}/complete")
def mark_task_completed_by_child(task_id: int, device: dict = Depends(get_current_device)):
    now = int(time.time())
    child_id = device["child_id"]
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM reward_tasks WHERE id = ? AND child_id = ?;", (task_id, child_id))
        task = cursor.fetchone()
        if not task:
            raise HTTPException(status_code=404, detail="Không tìm thấy nhiệm vụ.")
        if task["status"] == "assigned":
            cursor.execute("UPDATE reward_tasks SET status = 'completed_by_child', completed_at = ? WHERE id = ?;", (now, task_id))
    return {"status": "success", "message": "Đã báo cáo hoàn thành nhiệm vụ cho ba mẹ!"}
