import time
import json
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, Any, Optional
from app.db.database import get_db
from app.core.dependencies import get_current_parent
from app.services.ws_manager import ws_manager

router = APIRouter(prefix="/api/v1/commands", tags=["Commands"])

class EmergencyCommandRequest(BaseModel):
    device_id: str
    command: str
    params: Optional[Dict[str, Any]] = None

@router.post("/emergency")
async def send_emergency_command(req: EmergencyCommandRequest, parent: dict = Depends(get_current_parent)):
    now = int(time.time())
    notif_data = None

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        SELECT d.id, d.device_name, c.id as child_id, c.name as child_name
        FROM devices d
        JOIN children c ON d.child_id = c.id
        WHERE d.id = ? AND c.parent_id = ?;
        ''', (req.device_id, parent["id"]))
        dev_info = cursor.fetchone()
        
        child_id = dev_info["child_id"] if dev_info else 1
        dev_name = dev_info["device_name"] if dev_info else req.device_id

        cursor.execute('''
        INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
        VALUES (?, ?, ?, ?, 0);
        ''', (req.device_id, req.command, json.dumps(req.params or {}), now))

        cmd_labels = {
            "lock_now": "Khóa máy ngay lập tức",
            "unlock": "Mở khóa máy",
            "add_minutes_15": "Cộng thêm 15 phút sử dụng"
        }
        cmd_text = cmd_labels.get(req.command, req.command)

        if req.command in ("add_minutes_15", "add_time_15"):
            cursor.execute("UPDATE devices SET extra_minutes_today = extra_minutes_today + 15 WHERE id = ?;", (req.device_id,))
            notif_data = {
                "title": "🎁 Ba mẹ vừa thưởng nóng +15 phút!",
                "message": "Ba mẹ vừa cộng thêm cho con 15 phút sử dụng máy tính hôm nay. Học tập và giải trí vui vẻ nhé!",
                "decision": "approved",
                "sound": "bonus_time",
                "timestamp": now
            }
            cursor.execute('''
            INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
            VALUES (?, 'child_notification', ?, ?, 0);
            ''', (req.device_id, json.dumps(notif_data, ensure_ascii=False), now))

        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'emergency_command', 'device', NULL, ?, '127.0.0.1', ?);
        ''', (parent["email"], child_id, f"Lệnh khẩn: {cmd_text} trên '{dev_name}'", now))

    delivered_live = await ws_manager.send_command(req.device_id, req.command, req.params)
    if notif_data:
        await ws_manager.send_command(req.device_id, "child_notification", notif_data)

    return {
        "status": "success",
        "delivered_immediately": delivered_live,
        "message": f"Đã gửi lệnh '{cmd_text}' thành công." + (" (Đã nhận ngay qua WebSocket)" if delivered_live else " (Sẽ nhận khi máy kết nối mạng)")
    }
