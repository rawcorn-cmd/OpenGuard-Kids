import json
import time
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from app.db.database import get_db
from app.core.security import sign_policy
from app.core.dependencies import get_current_parent, get_current_device
from app.services.ws_manager import ws_manager

router = APIRouter(prefix="/api/v1/requests", tags=["Requests"])

class ChildSubmitRequest(BaseModel):
    type: str # 'more_time_15', 'unblock_domain', 'unblock_app'
    subject: str
    reason: Optional[str] = "Con cần thêm thời gian để hoàn thành bài tập"

class ResolveRequest(BaseModel):
    decision: str # 'approve', 'reject'
    note: Optional[str] = None

@router.post("")
def submit_request(req: ChildSubmitRequest, device: dict = Depends(get_current_device)):
    now = int(time.time())
    child_id = device["child_id"]
    device_id = device["id"]

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO child_requests (child_id, device_id, type, subject, reason, status, created_at)
        VALUES (?, ?, ?, ?, ?, 'pending', ?);
        ''', (child_id, device_id, req.type, req.subject, req.reason, now))
        request_id = cursor.lastrowid

    return {
        "status": "success",
        "message": "Yêu cầu của con đã được gửi tới ba mẹ.",
        "request_id": request_id
    }

@router.get("")
def list_requests(status: Optional[str] = None, parent: dict = Depends(get_current_parent)):
    with get_db() as conn:
        cursor = conn.cursor()
        query = '''
        SELECT r.*, c.name as child_name, d.device_name
        FROM child_requests r
        JOIN children c ON r.child_id = c.id
        LEFT JOIN devices d ON r.device_id = d.id
        WHERE c.parent_id = ?
        '''
        params = [parent["id"]]
        if status:
            query += " AND r.status = ?"
            params.append(status)
        query += " ORDER BY r.created_at DESC;"

        cursor.execute(query, params)
        rows = cursor.fetchall()
        return [dict(r) for r in rows]

@router.post("/{request_id}/resolve")
async def resolve_request(request_id: int, req: ResolveRequest, parent: dict = Depends(get_current_parent)):
    """
    Resolves a child's request with full 2-way synchronization:
    1. If 'unblock_domain' is APPROVED:
       - Automatically updates the child's policy in DB (removes 'block' or sets to 'allow').
       - Increments policy version and re-signs HMAC-SHA256.
       - Dispatches 'reload_policy' command so Agent immediately unblocks DNS & cleans Windows hosts file!
    2. If 'more_time_15' is APPROVED:
       - Increments extra_minutes_today and dispatches 'add_minutes_15'.
    3. For BOTH Approve and Reject:
       - Dispatches 'child_notification' with title, message, sound_type, and parent's note so the child receives an instant popup & sound!
    """
    now = int(time.time())
    new_status = "approved" if req.decision == "approve" else "rejected"
    parent_note = req.note or ("Ba mẹ đồng ý nhé!" if new_status == "approved" else "Lúc này chưa phù hợp, con tập trung học trước nhé!")

    commands_to_push = [] # list of (device_id, cmd_name, cmd_params)

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        SELECT r.*, c.parent_id, c.name as child_name, d.id as dev_id, d.device_name
        FROM child_requests r
        JOIN children c ON r.child_id = c.id
        LEFT JOIN devices d ON r.device_id = d.id
        WHERE r.id = ?;
        ''', (request_id,))
        record = cursor.fetchone()

        if not record or record["parent_id"] != parent["id"]:
            raise HTTPException(status_code=404, detail="Không tìm thấy yêu cầu thuộc quyền quản lý của bạn.")

        child_id = record["child_id"]
        target_dev_id = record["device_id"]
        req_type = record["type"]
        req_subject = record["subject"].strip().lower()

        # Update request status
        cursor.execute('''
        UPDATE child_requests SET 
            status = ?, 
            resolved_at = ?, 
            resolved_by = ?
        WHERE id = ?;
        ''', (new_status, now, parent["email"], request_id))

        action_desc = "Đồng ý" if new_status == "approved" else "Từ chối"

        # ----------------------------------------------------------------------
        # CASE A: APPROVE UNBLOCK DOMAIN OR APP -> AUTO-UPDATE POLICY & HOSTS
        # ----------------------------------------------------------------------
        if new_status == "approved" and req_type in ("unblock_domain", "unblock_app"):
            cursor.execute("SELECT * FROM policies WHERE child_id = ?;", (child_id,))
            pol = cursor.fetchone()
            if pol:
                new_ver = pol["version"] + 1
                sched = json.loads(pol["schedule_matrix_json"])
                app_rules = json.loads(pol["app_rules_json"])
                dom_rules = json.loads(pol["domain_rules_json"])

                if req_type == "unblock_domain":
                    clean_dom = req_subject.replace("https://", "").replace("http://", "").split("/")[0].lstrip("*.")
                    updated = False
                    for r in dom_rules:
                        r_dom = r["domain"].lower().lstrip("*.")
                        if r_dom == clean_dom or clean_dom.endswith("." + r_dom):
                            r["action"] = "allow"
                            r["reason"] = f"Đã được phụ huynh mở chặn ({parent_note})"
                            updated = True
                    if not updated:
                        dom_rules.append({
                            "domain": clean_dom,
                            "category": "education",
                            "action": "allow",
                            "reason": f"Đã được phụ huynh mở chặn ({parent_note})"
                        })
                elif req_type == "unblock_app":
                    updated = False
                    for r in app_rules:
                        if r["name"].lower() == req_subject:
                            r["action"] = "allow"
                            r["reason"] = f"Đã được phụ huynh mở chặn ({parent_note})"
                            updated = True

                policy_payload = {
                    "child_id": child_id,
                    "version": new_ver,
                    "daily_quota_weekday_sec": pol["daily_quota_weekday_sec"],
                    "daily_quota_weekend_sec": pol["daily_quota_weekend_sec"],
                    "schedule_matrix": sched,
                    "app_rules": app_rules,
                    "domain_rules": dom_rules,
                    "safe_search_enabled": int(pol["safe_search_enabled"]),
                    "doh_blocked": int(pol["doh_blocked"])
                }
                sig = sign_policy(policy_payload)

                cursor.execute('''
                UPDATE policies SET
                    version = ?,
                    app_rules_json = ?,
                    domain_rules_json = ?,
                    hmac_signature = ?,
                    updated_at = ?,
                    updated_by = ?
                WHERE child_id = ?;
                ''', (
                    new_ver,
                    json.dumps(app_rules, ensure_ascii=False),
                    json.dumps(dom_rules, ensure_ascii=False),
                    sig,
                    now,
                    parent["email"],
                    child_id
                ))

                # Queue reload_policy for all active devices of this child
                cursor.execute("SELECT id FROM devices WHERE child_id = ? AND status = 'active';", (child_id,))
                for d_row in cursor.fetchall():
                    d_id = d_row["id"]
                    cursor.execute('''
                    INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
                    VALUES (?, 'reload_policy', ?, ?, 0);
                    ''', (d_id, json.dumps({"version": new_ver, "unblocked": req_subject}), now))
                    commands_to_push.append((d_id, "reload_policy", {"version": new_ver, "unblocked": req_subject}))

        # ----------------------------------------------------------------------
        # CASE B: APPROVE MORE TIME (+15 MINUTES)
        # ----------------------------------------------------------------------
        elif new_status == "approved" and req_type == "more_time_15" and target_dev_id:
            cursor.execute('''
            INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
            VALUES (?, 'add_minutes_15', ?, ?, 0);
            ''', (target_dev_id, json.dumps({"minutes": 15, "note": parent_note}), now))
            
            cursor.execute('''
            UPDATE devices SET extra_minutes_today = extra_minutes_today + 15 WHERE id = ?;
            ''', (target_dev_id,))
            commands_to_push.append((target_dev_id, "add_minutes_15", {"minutes": 15, "note": parent_note}))

        # ----------------------------------------------------------------------
        # CASE C: PUSH INSTANT NOTIFICATION TO CHILD FOR ALL DECISIONS (FIX 3)
        # ----------------------------------------------------------------------
        if target_dev_id:
            if new_status == "approved":
                if req_type == "more_time_15":
                    notif_title = "🎉 Ba mẹ đã đồng ý tặng thêm 15 phút!"
                    notif_msg = f"Yêu cầu xin thêm giờ của con đã được duyệt.\nLời nhắn từ ba mẹ: '{parent_note}'"
                    sound = "bonus_time"
                else:
                    notif_title = f"✅ Ba mẹ đã mở chặn [{req_subject}]!"
                    notif_msg = f"Trang web / ứng dụng '{req_subject}' đã được mở khóa tự động.\nLời nhắn từ ba mẹ: '{parent_note}'"
                    sound = "success"
            else:
                notif_title = "💬 Phản hồi từ ba mẹ về yêu cầu của con"
                notif_msg = f"Ba mẹ chưa đồng ý yêu cầu ({req_subject}).\nLời nhắn từ ba mẹ: '{parent_note}'"
                sound = "warning"

            notif_payload = {
                "title": notif_title,
                "message": notif_msg,
                "decision": new_status,
                "sound": sound,
                "timestamp": now
            }
            cursor.execute('''
            INSERT INTO pending_commands (device_id, command, parameters_json, created_at, delivered)
            VALUES (?, 'child_notification', ?, ?, 0);
            ''', (target_dev_id, json.dumps(notif_payload, ensure_ascii=False), now))
            commands_to_push.append((target_dev_id, "child_notification", notif_payload))

        # Audit log
        cursor.execute('''
        INSERT INTO audit_logs (actor, child_id, action, target_type, old_value, new_value, ip_address, timestamp)
        VALUES (?, ?, 'resolve_child_request', 'request', ?, ?, '127.0.0.1', ?);
        ''', (parent["email"], child_id, f"Yêu cầu: {req_type} ({req_subject})", f"{action_desc} - {parent_note}", now))

    # Dispatch all queued commands over WebSocket immediately
    for d_id, cmd_name, cmd_params in commands_to_push:
        await ws_manager.send_command(d_id, cmd_name, cmd_params)

    return {
        "status": "success",
        "message": f"Đã {action_desc.lower()} yêu cầu của {record['child_name']} và đồng bộ xuống máy trẻ!",
        "new_status": new_status
    }
