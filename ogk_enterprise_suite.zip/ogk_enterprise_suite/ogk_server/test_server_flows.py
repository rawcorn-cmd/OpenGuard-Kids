import uuid
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from starlette.testclient import TestClient
from main import app
from app.core.security import verify_policy_signature

with TestClient(app) as client:
    print("--- 1. Testing Root and Login Page ---")
    res = client.get("/", follow_redirects=False)
    assert res.status_code in (200, 302, 307), res.status_code
    print("Root redirect OK")

    res = client.get("/login")
    assert res.status_code == 200, res.status_code
    assert "OGK - Open Guardian Kid" in res.text
    print("Login page render OK")

    print("\n--- 2. Testing Parent Login ---")
    res = client.post("/api/v1/auth/login", json={
        "email": "phuhuynh@ogk.vn",
        "password": "MatKhauPhuHuynh2026!"
    })
    assert res.status_code == 200, res.text
    login_data = res.json()
    assert login_data["status"] == "success"
    session_cookie = res.cookies.get("ogk_session")
    assert session_cookie is not None
    print("Login successful, session cookie obtained!")

    print("\n--- 3. Testing Get Parent Profile ---")
    res = client.get("/api/v1/auth/me", cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    profile = res.json()
    assert profile["email"] == "phuhuynh@ogk.vn"
    print(f"Profile verified: {profile['full_name']} ({profile['email']})")

    print("\n--- 4. Testing Enrollment Pairing Code (8 chars, 10 min) ---")
    res = client.post("/api/v1/enroll/create-code", json={"child_id": 1}, cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    enroll_data = res.json()
    code = enroll_data["code"]
    assert len(code) == 8
    print(f"Created pairing code: {code} for {enroll_data['child_name']}")

    print("\n--- 5. Testing Agent Claim Pairing Code ---")
    res = client.post("/api/v1/enroll/claim", json={
        "code": code,
        "device_name": "Laptop-BeAn-Win11",
        "fingerprint": "WIN11-UUID-FINGERPRINT-TEST-12345"
    })
    assert res.status_code == 200, res.text
    claim_data = res.json()
    device_id = claim_data["device_id"]
    access_token = claim_data["access_token"]
    refresh_token = claim_data["refresh_token"]
    print(f"Agent enrolled successfully! device_id={device_id}, access_token={access_token[:20]}...")

    device_headers = {"Authorization": f"Bearer {access_token}"}

    print("\n--- 6. Testing Agent Fetch Policy & Verify HMAC ---")
    res = client.get("/api/v1/policy", headers=device_headers)
    assert res.status_code == 200, res.text
    policy = res.json()
    assert policy["child_id"] == 1
    assert "hmac_signature" in policy

    sig = policy["hmac_signature"]
    policy_payload = {
        "child_id": policy["child_id"],
        "version": policy["version"],
        "daily_quota_weekday_sec": policy["daily_quota_weekday_sec"],
        "daily_quota_weekend_sec": policy["daily_quota_weekend_sec"],
        "schedule_matrix": policy["schedule_matrix"],
        "app_rules": policy["app_rules"],
        "domain_rules": policy["domain_rules"],
        "safe_search_enabled": 1 if policy["safe_search_enabled"] else 0,
        "doh_blocked": 1 if policy["doh_blocked"] else 0
    }
    assert verify_policy_signature(policy_payload, sig)
    print("Policy fetched and HMAC integrity signature VERIFIED!")

    print("\n--- 7. Testing Heartbeat 60s ---")
    res = client.post("/api/v1/heartbeat", json={
        "policy_version": policy["version"],
        "used_quota_today_sec": 1800,
        "system_status": "ok",
        "agent_uptime_sec": 3600
    }, headers=device_headers)
    assert res.status_code == 200, res.text
    hb = res.json()
    assert hb["status"] == "success"
    assert "server_time" in hb
    print(f"Heartbeat OK: server_time={hb['server_time']}, latest_policy_version={hb['latest_policy_version']}")

    print("\n--- 8. Testing Batch Event Ingestion with Idempotency Key ---")
    events_batch = [
        {
            "idempotency_key": str(uuid.uuid4()),
            "ts": 1730550000,
            "type": "app_start",
            "subject": "zoom.exe",
            "duration_sec": 900,
            "policy_id": 1
        },
        {
            "idempotency_key": str(uuid.uuid4()),
            "ts": 1730550900,
            "type": "domain_query",
            "subject": "khanacademy.org",
            "duration_sec": 0,
            "policy_id": 1
        },
        {
            "idempotency_key": str(uuid.uuid4()),
            "ts": 1730551000,
            "type": "blocked_domain",
            "subject": "tiktok.com",
            "duration_sec": 0,
            "policy_id": 1
        }
    ]
    res = client.post("/api/v1/events/batch", json={"events": events_batch}, headers=device_headers)
    assert res.status_code == 200, res.text
    batch_res = res.json()
    assert batch_res["inserted"] == 3
    print("Batch events inserted: 3")

    res2 = client.post("/api/v1/events/batch", json={"events": events_batch}, headers=device_headers)
    batch_res2 = res2.json()
    assert batch_res2["inserted"] == 0
    assert batch_res2["duplicates_skipped"] == 3
    print("Idempotency deduplication verified! (0 inserted, 3 skipped)")

    print("\n--- 9. Testing Child Request (NT3 - Trẻ có tiếng nói) ---")
    res = client.post("/api/v1/requests", json={
        "type": "more_time_15",
        "subject": "15_mins",
        "reason": "Con cần thêm 15 phút để hoàn thành bài tập toán"
    }, headers=device_headers)
    assert res.status_code == 200, res.text
    req_data = res.json()
    req_id = req_data["request_id"]
    print(f"Child submitted request id={req_id}")

    res = client.post(f"/api/v1/requests/{req_id}/resolve", json={
        "decision": "approve",
        "note": "Ba đồng ý, con cố gắng làm bài xong nhé"
    }, cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    print("Parent approved request, command queued/dispatched!")

    print("\n--- 10. Testing Emergency Command (F4: sub-5s) ---")
    res = client.post("/api/v1/commands/emergency", json={
        "device_id": device_id,
        "command": "lock_now",
        "params": {"reason": "Đến giờ ăn cơm tối"}
    }, cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    cmd_res = res.json()
    print("Emergency command dispatched:", cmd_res["message"])

    print("\n--- 11. Testing Reports & Audit Log ---")
    res = client.get("/api/v1/reports/summary/1", cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    summary = res.json()
    print(f"Report Summary: today_minutes={summary['today_minutes']}, blocked_domains={summary['blocked_domains_count']}")

    res = client.get("/api/v1/reports/audit-logs/1", cookies={"ogk_session": session_cookie})
    assert res.status_code == 200, res.text
    logs = res.json()
    print(f"Audit logs count: {len(logs)} entries recorded!")

    print("\n========================================================")
    print(" ALL 11 TEST SUITES PASSED FLAWLESSLY! OGK-SERVER READY! ")
    print("========================================================")
