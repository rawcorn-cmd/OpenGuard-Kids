import sqlite3
import time
import uuid
from datetime import datetime, date, timedelta

DB_PATH = "data/ogk_server.db"
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

now = int(time.time())

# 1. Ensure sample device exists
dev_id = "demo-device-bean-01"
cursor.execute("SELECT id FROM devices WHERE id = ?;", (dev_id,))
if not cursor.fetchone():
    cursor.execute("""
    INSERT INTO devices (id, child_id, device_name, fingerprint, status, last_heartbeat, used_quota_today, created_at)
    VALUES (?, 1, 'Laptop-Bé-An-Win11', 'WIN11-DEMO-FINGERPRINT', 'active', ?, 2400, ?);
    """, (dev_id, now, now - 86400 * 7))

# 2. Insert sample events for past 7 days
sample_apps = [
    ("zoom.exe", 1800),
    ("msedge.exe", 1200),
    ("scratch.exe", 900),
    ("word.exe", 600),
    ("calculator.exe", 300)
]

sample_domains = [
    "khanacademy.org",
    "scratch.mit.edu",
    "wikipedia.org",
    "olm.vn",
    "code.org",
    "edu.vn",
    "tongdai111.vn"
]

for days_ago in range(6, -1, -1):
    day_ts = now - (days_ago * 86400)
    # Insert app usage events
    for app_name, dur in sample_apps:
        cursor.execute("""
        INSERT OR IGNORE INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
        VALUES (?, ?, ?, 1, 'app_start', ?, ?, 1);
        """, (str(uuid.uuid4()), day_ts, dev_id, app_name, dur))

    # Insert domain query events
    for dom in sample_domains:
        cursor.execute("""
        INSERT OR IGNORE INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
        VALUES (?, ?, ?, 1, 'domain_query', ?, 0, 1);
        """, (str(uuid.uuid4()), day_ts, dev_id, dom))

# 3. Insert sample blocked events
cursor.execute("""
INSERT OR IGNORE INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
VALUES (?, ?, ?, 1, 'blocked_app', 'discord.exe', 0, 1);
""", (str(uuid.uuid4()), now - 3600, dev_id))

cursor.execute("""
INSERT OR IGNORE INTO events (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id)
VALUES (?, ?, ?, 1, 'blocked_domain', 'tiktok.com', 0, 1);
""", (str(uuid.uuid4()), now - 1800, dev_id))

# 4. Insert sample pending request from child
cursor.execute("SELECT id FROM child_requests WHERE child_id = 1 AND status = 'pending';")
if not cursor.fetchone():
    cursor.execute("""
    INSERT INTO child_requests (child_id, device_id, type, subject, reason, status, created_at)
    VALUES (1, ?, 'more_time_15', '15_mins', 'Con cần thêm 15 phút để nộp bài tập toán trên OLM', 'pending', ?);
    """, (dev_id, now - 600))

conn.commit()
conn.close()
print("Demo activity data seeded successfully!")
