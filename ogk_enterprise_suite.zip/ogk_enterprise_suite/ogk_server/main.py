import sys
from pathlib import Path
from typing import Dict, Any, Optional

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware

from app.db.database import init_db
from app.db.seed import seed_default_data
from app.core.security import verify_signed_token
from app.services.ws_manager import ws_manager

from app.api.auth import router as auth_router
from app.api.enroll import router as enroll_router
from app.api.policy import router as policy_router
from app.api.heartbeat import router as heartbeat_router
from app.api.events import router as events_router
from app.api.commands import router as commands_router
from app.api.requests import router as requests_router
from app.api.reports import router as reports_router
from app.api.children import router as children_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_default_data()
    yield

app = FastAPI(
    title="OGK Server - Open Guardian Kid",
    description="Hệ thống quản lý sử dụng máy tính cho trẻ em (Công cụ đồng hành, không phải phần mềm theo dõi lén)",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))
static_dir = BASE_DIR / "app" / "static"
static_dir.mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

def render_view(name: str, request: Request, context: Optional[Dict[str, Any]] = None):
    """
    Dual-compatibility template renderer for both older and newer Starlette versions.
    Automatically handles the breaking change in Starlette 0.28+ / Python 3.14.
    """
    ctx = dict(context or {})
    ctx["request"] = request
    try:
        # Modern Starlette (Starlette >= 0.28+)
        return templates.TemplateResponse(request=request, name=name, context=ctx)
    except TypeError:
        # Legacy Starlette (Starlette < 0.28)
        return templates.TemplateResponse(name, ctx)

app.include_router(auth_router)
app.include_router(enroll_router)
app.include_router(policy_router)
app.include_router(heartbeat_router)
app.include_router(events_router)
app.include_router(commands_router)
app.include_router(requests_router)
app.include_router(reports_router)
app.include_router(children_router)



@app.websocket("/ws/agent/{device_id}")
async def websocket_agent_endpoint(websocket: WebSocket, device_id: str):
    await ws_manager.connect(device_id, websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(device_id)
    except Exception:
        ws_manager.disconnect(device_id)

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    token = request.cookies.get("ogk_session")
    if token and verify_signed_token(token):
        return RedirectResponse(url="/dashboard", status_code=302)
    return RedirectResponse(url="/login", status_code=302)

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return render_view("login.html", request)

@app.get("/login.html", response_class=HTMLResponse)
def login_html_alias(request: Request):
    return RedirectResponse(url="/login", status_code=301)

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard_page(request: Request):
    token = request.cookies.get("ogk_session")
    payload = verify_signed_token(token) if token else None
    if not payload:
        return RedirectResponse(url="/login", status_code=302)
    return render_view("dashboard.html", request)

@app.get("/dashboard.html", response_class=HTMLResponse)
def dashboard_html_alias(request: Request):
    return RedirectResponse(url="/dashboard", status_code=301)

@app.get("/index.html", response_class=HTMLResponse)
def index_html_alias(request: Request):
    return RedirectResponse(url="/", status_code=301)

if __name__ == "__main__":
    import uvicorn
    # Defaults to port 8080 to avoid conflicts on Windows
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)
