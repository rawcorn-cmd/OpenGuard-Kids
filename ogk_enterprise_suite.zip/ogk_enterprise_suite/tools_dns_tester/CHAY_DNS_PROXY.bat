@echo off
setlocal
title "OGK - DNS Proxy Tester Standalone"
set ROOT=%~dp0
cd /d "%ROOT%"

:: Auto-elevate to Administrator for Port 53 DNS and Network Adapter Configuration
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [THONG BAO] Dang yeu cau quyen Administrator de mo cong DNS 53...
    powershell -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
    exit /b
)

echo ================================================================
echo   KHOI CHAY OGK STANDALONE DNS PROXY TESTER (QUYEN ADMIN)
echo ================================================================

python dns_proxy_gui.py
pause
