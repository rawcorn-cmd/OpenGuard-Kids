import atexit
import signal

def cleanup_on_exit():
    if sys.platform == "win32":
        try:
            restore_windows_dns_dhcp()
            clean_hosts()
        except Exception:
            pass

atexit.register(cleanup_on_exit)

import sys
import os
import time
import socket
import struct
import threading
import subprocess
from datetime import datetime
import json
from pathlib import Path

# GUI imports (Tkinter built into Python)
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

HOSTS_FILE = r"C:\Windows\System32\drivers\etc\hosts" if sys.platform == "win32" else "/etc/hosts"
MARKER_START = "# --- OGK STANDALONE DNS PROXY BLOCKLIST START ---"
MARKER_END = "# --- OGK STANDALONE DNS PROXY BLOCKLIST END ---"

UPSTREAM_DNS = ("1.1.1.1", 53) # Cloudflare Public DNS

SAFESEARCH_IPS = {
    "google": "216.239.38.120", # forcesafesearch.google.com
    "bing": "204.79.197.220",    # strict.bing.com
    "youtube": "216.239.38.119"  # restrict.youtube.com
}

CONFIG_FILE = Path(__file__).resolve().parent / "blocked_domains.json"

DEFAULT_BLOCKLIST = [
    "tiktok.com",
    "facebook.com",
    "instagram.com",
    "roblox.com",
    "discord.com"
]

class StandaloneDNSProxyApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("OGK - Standalone DNS Proxy Tester (Thử Nghiệm Chặn Web)")
        self.root.geometry("820x680")
        self.root.minsize(750, 600)
        self.root.configure(bg="#f8fafc")

        self.running = False
        self.server_sock = None
        self.blocklist = self.load_blocklist()
        self.safesearch_enabled = tk.BooleanVar(value=True)
        self.use_hosts_duallayer = tk.BooleanVar(value=True)

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def load_blocklist(self) -> list:
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return list(DEFAULT_BLOCKLIST)

    def save_blocklist(self):
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.blocklist, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def _build_ui(self):
        # 1. Header Banner
        hdr = tk.Frame(self.root, bg="#1e293b", padx=20, pady=16)
        hdr.pack(fill=tk.X)
        
        hdr_top = tk.Frame(hdr, bg="#1e293b")
        hdr_top.pack(fill=tk.X)
        tk.Label(hdr_top, text="🛡️ DNS PROXY THỬ NGHIỆM ĐỘC LẬP", font=("Segoe UI", 14, "bold"), fg="#ffffff", bg="#1e293b").pack(side=tk.LEFT)
        
        self.lbl_status_badge = tk.Label(hdr_top, text="● ĐANG TẮT", font=("Segoe UI", 9, "bold"), fg="#f87171", bg="#334155", padx=10, pady=3)
        self.lbl_status_badge.pack(side=tk.RIGHT)

        tk.Label(hdr, text="Bắt gói tin cổng 53, chặn website theo danh sách, cưỡng chế SafeSearch và ghi nhật ký thời gian thực.", font=("Segoe UI", 8), fg="#94a3b8", bg="#1e293b").pack(anchor="w", pady=(4, 0))

        # Main Scrollable / Paned Container
        main_frame = tk.Frame(self.root, bg="#f8fafc", padx=15, pady=12)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 2. Control Bar (Start / Stop)
        ctrl_card = tk.LabelFrame(main_frame, text=" Điều Khiển DNS Proxy ", font=("Segoe UI", 9, "bold"), fg="#334155", bg="#ffffff", padx=15, pady=10)
        ctrl_card.pack(fill=tk.X, pady=(0, 10))

        self.btn_toggle = tk.Button(ctrl_card, text="▶ BẬT DNS PROXY & CHẶN WEB", font=("Segoe UI", 11, "bold"), bg="#16a34a", fg="#ffffff", activebackground="#15803d", padx=20, pady=8, relief=tk.FLAT, cursor="hand2", command=self.toggle_proxy)
        self.btn_toggle.pack(side=tk.LEFT, padx=(0, 10))
        tk.Button(ctrl_card, text="🔄 Khôi Phục Mạng Gốc", font=("Segoe UI", 9, "bold"), bg="#f1f5f9", fg="#475569", activebackground="#e2e8f0", relief=tk.GROOVE, padx=10, pady=8, cursor="hand2", command=self.manual_restore_network).pack(side=tk.LEFT, padx=(0, 15))

        opts_frame = tk.Frame(ctrl_card, bg="#ffffff")
        opts_frame.pack(side=tk.LEFT, fill=tk.Y)
        tk.Checkbutton(opts_frame, text="Cưỡng chế SafeSearch (Google, Bing, YouTube)", variable=self.safesearch_enabled, font=("Segoe UI", 9), bg="#ffffff", activebackground="#ffffff").pack(anchor="w")
        tk.Checkbutton(opts_frame, text="Cơ chế chặn kép (Đồng bộ Windows Hosts để chặn tuyệt đối)", variable=self.use_hosts_duallayer, font=("Segoe UI", 9), bg="#ffffff", activebackground="#ffffff").pack(anchor="w")

        # 3. Add Domain Section
        domain_card = tk.LabelFrame(main_frame, text=" Danh Sách Website Cần Chặn (Nhập URL hoặc Tên Miền) ", font=("Segoe UI", 9, "bold"), fg="#334155", bg="#ffffff", padx=15, pady=10)
        domain_card.pack(fill=tk.X, pady=(0, 10))

        input_frame = tk.Frame(domain_card, bg="#ffffff")
        input_frame.pack(fill=tk.X, pady=(0, 8))

        self.entry_domain = tk.Entry(input_frame, font=("Segoe UI", 10), relief=tk.SOLID, bd=1)
        self.entry_domain.insert(0, "shopee.vn")
        self.entry_domain.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8), ipady=4)
        self.entry_domain.bind("<Return>", lambda e: self.add_domain())

        btn_add = tk.Button(input_frame, text="+ Thêm Vào Danh Sách Chặn", font=("Segoe UI", 9, "bold"), bg="#2563eb", fg="#ffffff", activebackground="#1d4ed8", relief=tk.FLAT, padx=12, pady=4, cursor="hand2", command=self.add_domain)
        btn_add.pack(side=tk.RIGHT)

        # Blocklist Listbox & Buttons
        list_frame = tk.Frame(domain_card, bg="#ffffff")
        list_frame.pack(fill=tk.X)

        self.listbox = tk.Listbox(list_frame, height=4, font=("Consolas", 10), selectmode=tk.SINGLE, relief=tk.SOLID, bd=1)
        self.listbox.pack(side=tk.LEFT, fill=tk.X, expand=True)

        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side=tk.LEFT, fill=tk.Y)
        self.listbox.config(yscrollcommand=scrollbar.set)

        btn_list_col = tk.Frame(list_frame, bg="#ffffff", padx=8)
        btn_list_col.pack(side=tk.RIGHT, fill=tk.Y)
        tk.Button(btn_list_col, text="Xóa Mục Đã Chọn", font=("Segoe UI", 8), bg="#fee2e2", fg="#dc2626", relief=tk.FLAT, padx=8, pady=3, cursor="hand2", command=self.delete_selected).pack(fill=tk.X, pady=2)
        tk.Button(btn_list_col, text="Khôi Phục Mặc Định", font=("Segoe UI", 8), bg="#f1f5f9", fg="#475569", relief=tk.FLAT, padx=8, pady=3, cursor="hand2", command=self.reset_default_blocklist).pack(fill=tk.X, pady=2)

        self._refresh_listbox()

        # 4. Live DNS Log Console
        log_card = tk.LabelFrame(main_frame, text=" Nhật Ký Truy Vấn DNS Thời Gian Thực (Live Query Log) ", font=("Segoe UI", 9, "bold"), fg="#334155", bg="#ffffff", padx=10, pady=8)
        log_card.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.log_text = scrolledtext.ScrolledText(log_card, font=("Consolas", 9), bg="#0f172a", fg="#38bdf8", relief=tk.FLAT)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_message("Hệ thống sẵn sàng. Nhấn nút [BẬT DNS PROXY] để bắt đầu thử nghiệm chặn web.")

        # 5. Quick Test Bar
        test_bar = tk.Frame(main_frame, bg="#f8fafc")
        test_bar.pack(fill=tk.X)

        tk.Label(test_bar, text="Thử nhanh nslookup:", font=("Segoe UI", 8, "bold"), fg="#64748b", bg="#f8fafc").pack(side=tk.LEFT, padx=(0, 5))
        self.test_input = tk.Entry(test_bar, font=("Consolas", 9), width=20, relief=tk.SOLID, bd=1)
        self.test_input.insert(0, "tiktok.com")
        self.test_input.pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(test_bar, text="Kiểm Tra Ngay", font=("Segoe UI", 8, "bold"), bg="#475569", fg="#ffffff", relief=tk.FLAT, padx=10, pady=2, cursor="hand2", command=self.run_nslookup_test).pack(side=tk.LEFT)
        tk.Button(test_bar, text="⚡ Cắt Kết Nối Cũ (Flush Sockets)", font=("Segoe UI", 8, "bold"), bg="#f59e0b", fg="#ffffff", relief=tk.FLAT, padx=8, pady=2, cursor="hand2", command=self.manual_flush_sockets).pack(side=tk.RIGHT, padx=4)
        tk.Button(test_bar, text="Xóa Nhật Ký", font=("Segoe UI", 8), bg="#e2e8f0", fg="#475569", relief=tk.FLAT, padx=10, pady=2, cursor="hand2", command=lambda: self.log_text.delete("1.0", tk.END)).pack(side=tk.RIGHT)

    def log_message(self, msg: str):
        time_str = datetime.now().strftime("%H:%M:%S")
        line = f"[{time_str}] {msg}\n"
        def _append():
            self.log_text.insert(tk.END, line)
            self.log_text.see(tk.END)
        self.root.after(0, _append)

    def clean_domain(self, raw: str) -> str:
        d = raw.strip().lower()
        d = d.replace("https://", "").replace("http://", "").split("/")[0].split(":")[0]
        return d.lstrip("*.")

    def add_domain(self):
        raw = self.entry_domain.get()
        dom = self.clean_domain(raw)
        if not dom or "." not in dom:
            messagebox.showwarning("Lỗi", "Vui lòng nhập tên miền hợp lệ (ví dụ: tiktok.com, shopee.vn)!")
            return
        if dom not in self.blocklist:
            self.blocklist.append(dom)
            self.save_blocklist()
            self._refresh_listbox()
            self.log_message(f"✓ Đã thêm tên miền [{dom}] vào danh sách chặn.")
            if self.running and self.use_hosts_duallayer.get():
                self.sync_hosts()
        self.entry_domain.delete(0, tk.END)

    def delete_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        dom = self.blocklist[idx]
        del self.blocklist[idx]
        self.save_blocklist()
        self._refresh_listbox()
        self.log_message(f"✗ Đã xóa tên miền [{dom}] khỏi danh sách chặn.")
        if self.running and self.use_hosts_duallayer.get():
            self.sync_hosts()

    def reset_default_blocklist(self):
        self.blocklist = list(DEFAULT_BLOCKLIST)
        self.save_blocklist()
        self._refresh_listbox()
        self.log_message("Đã khôi phục danh sách chặn mặc định.")
        if self.running and self.use_hosts_duallayer.get():
            self.sync_hosts()

    def _refresh_listbox(self):
        self.listbox.delete(0, tk.END)
        for i, dom in enumerate(self.blocklist, 1):
            self.listbox.insert(tk.END, f"{i:2d}. {dom} (và toàn bộ *. {dom})")

    # ==============================================================================
    # PROXY TOGGLE & NETWORKING
    # ==============================================================================
    def toggle_proxy(self):
        if not self.running:
            self.start_proxy()
        else:
            self.stop_proxy()

    def start_proxy(self):
        try:
            self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.server_sock.bind(("127.0.0.1", 53))
        except Exception as e:
            messagebox.showerror(
                "Lỗi mở cổng DNS 53",
                f"Không thể mở cổng mạng 53 trên 127.0.0.1!\n\nNguyên nhân: {e}\n\n-> Hãy đảm bảo bạn chạy ứng dụng với quyền Quản trị viên (Run as administrator)!"
            )
            return

        self.running = True
        self.btn_toggle.config(text="⏹ TẮT DNS PROXY (Khôi phục mạng)", bg="#dc2626", activebackground="#b91c1c")
        self.lbl_status_badge.config(text="● ĐANG CHẠY (127.0.0.1:53)", fg="#22c55e", bg="#14532d")
        self.log_message(">>> DNS Proxy đã khởi động tại 127.0.0.1:53")

        # Start DNS listener thread
        threading.Thread(target=self._dns_listener_loop, daemon=True).start()

        # Set Windows DNS adapter & sync hosts
        if sys.platform == "win32":
            threading.Thread(target=self._apply_windows_network, daemon=True).start()

    def stop_proxy(self):
        self.running = False
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass

        self.btn_toggle.config(text="▶ BẬT DNS PROXY & CHẶN WEB", bg="#16a34a", activebackground="#15803d")
        self.lbl_status_badge.config(text="● ĐANG TẮT", fg="#f87171", bg="#334155")
        self.log_message("<<< DNS Proxy đã dừng. Đang khôi phục cài đặt mạng Windows...")

        # Restore Windows DNS & clean hosts
        if sys.platform == "win32":
            threading.Thread(target=self._restore_windows_network, daemon=True).start()

    def _apply_windows_network(self):
        self.log_message("Đang trỏ DNS card mạng về 127.0.0.1...")
        cmd = 'powershell -Command "Get-NetAdapter | Where-Object Status -eq Up | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses (\"127.0.0.1\", \"1.1.1.1\") }"'
        subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if self.use_hosts_duallayer.get():
            self.sync_hosts()
        subprocess.run("ipconfig /flushdns", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        kill_browser_active_connections()
        self.log_message("✓ Đã cấu hình DNS Windows & Cắt đứt toàn bộ kết nối cũ (Flushed sockets/cache)!")

    def _restore_windows_network(self):
        cmd = 'powershell -Command "Get-NetAdapter | Where-Object Status -eq Up | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }"'
        subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.clean_hosts()
        subprocess.run("ipconfig /flushdns", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.log_message("✓ Đã khôi phục DNS mạng về tự động (DHCP) và dọn sạch blocklist.")

    def sync_hosts(self):
        if sys.platform != "win32" or not os.path.exists(HOSTS_FILE):
            return
        try:
            with open(HOSTS_FILE, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            if MARKER_START in content and MARKER_END in content:
                pre = content.split(MARKER_START)[0]
                post = content.split(MARKER_END)[1]
                content = pre.rstrip() + "\n" + post.lstrip()

            block_lines = [MARKER_START]
            for dom in self.blocklist:
                clean = dom.strip().lower().lstrip("*.")
                if clean:
                    block_lines.append(f"0.0.0.0 {clean}")
                    block_lines.append(f"0.0.0.0 www.{clean}")
            block_lines.append(MARKER_END)

            new_content = content.rstrip() + "\n\n" + "\n".join(block_lines) + "\n"
            with open(HOSTS_FILE, "w", encoding="utf-8") as f:
                f.write(new_content)
            self.log_message(f"✓ Đã đồng bộ {len(self.blocklist)} tên miền vào Windows Hosts (Chặn tuyệt đối trên trình duyệt)")
        except Exception as e:
            self.log_message(f"[Cảnh báo] Không thể sửa file hosts (cần quyền Admin): {e}")

    def clean_hosts(self):
        if sys.platform != "win32" or not os.path.exists(HOSTS_FILE):
            return
        try:
            with open(HOSTS_FILE, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            if MARKER_START in content and MARKER_END in content:
                pre = content.split(MARKER_START)[0]
                post = content.split(MARKER_END)[1]
                with open(HOSTS_FILE, "w", encoding="utf-8") as f:
                    f.write(pre.rstrip() + "\n" + post.lstrip())
        except Exception:
            pass

    # ==============================================================================
    # DNS PACKET PARSING & PROXY ENGINE
    # ==============================================================================
    def _parse_qname(self, data: bytes, offset: int = 12):
        labels = []
        curr = offset
        while curr < len(data):
            length = data[curr]
            if length == 0:
                curr += 1
                break
            if (length & 0xC0) == 0xC0:
                curr += 2
                break
            curr += 1
            labels.append(data[curr:curr + length].decode("latin1", errors="ignore"))
            curr += length
        return ".".join(labels).lower(), curr

    def _is_match(self, domain: str, rule: str) -> bool:
        r = rule.lower().lstrip("*.")
        return domain == r or domain.endswith("." + r)

    def _build_response(self, query_data: bytes, domain: str, ip: str) -> bytes:
        trans_id = query_data[:2]
        flags = bytes([0x81, 0x80])
        qdcount = struct.pack(">H", 1)
        ancount = struct.pack(">H", 1)
        nscount = struct.pack(">H", 0)
        arcount = struct.pack(">H", 0)
        header = trans_id + flags + qdcount + ancount + nscount + arcount

        qname_parts = domain.split(".")
        qname = b"".join(bytes([len(p)]) + p.encode("latin1") for p in qname_parts) + bytes([0])
        question = qname + struct.pack(">H", 1) + struct.pack(">H", 1)

        ans_name = bytes([0xC0, 0x0C])
        ans_type = struct.pack(">H", 1)
        ans_class = struct.pack(">H", 1)
        ans_ttl = struct.pack(">I", 30)
        ip_bytes = socket.inet_aton(ip)
        ans_len = struct.pack(">H", len(ip_bytes))
        answer = ans_name + ans_type + ans_class + ans_ttl + ans_len + ip_bytes

        return header + question + answer

    def _dns_listener_loop(self):
        while self.running:
            try:
                data, addr = self.server_sock.recvfrom(4096)
                if not data or len(data) < 12:
                    continue
                threading.Thread(target=self._process_query, args=(data, addr), daemon=True).start()
            except Exception:
                break

    def _process_query(self, data: bytes, client_addr):
        domain, _ = self._parse_qname(data)
        if not domain:
            return

        # 1. Check SafeSearch
        if self.safesearch_enabled.get():
            if "google." in domain and ("www." in domain or domain.startswith("google.")):
                self.log_message(f"[SAFESEARCH 🛡️] {domain} -> {SAFESEARCH_IPS['google']}")
                resp = self._build_response(data, domain, SAFESEARCH_IPS["google"])
                self.server_sock.sendto(resp, client_addr)
                return
            if "bing.com" in domain:
                self.log_message(f"[SAFESEARCH 🛡️] {domain} -> {SAFESEARCH_IPS['bing']}")
                resp = self._build_response(data, domain, SAFESEARCH_IPS["bing"])
                self.server_sock.sendto(resp, client_addr)
                return

        # 2. Check Blocklist
        is_blocked = False
        for rule in self.blocklist:
            if self._is_match(domain, rule):
                is_blocked = True
                break

        if is_blocked:
            self.log_message(f"[BỊ CHẶN 🚫] {domain} -> 0.0.0.0 (Sinkhole)")
            resp = self._build_response(data, domain, "0.0.0.0")
            self.server_sock.sendto(resp, client_addr)
            return

        # 3. Forward to Upstream DNS (1.1.1.1)
        try:
            fwd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            fwd.settimeout(2.5)
            fwd.sendto(data, UPSTREAM_DNS)
            upstream_resp, _ = fwd.recvfrom(4096)
            self.server_sock.sendto(upstream_resp, client_addr)
            fwd.close()
            self.log_message(f"[CHO PHÉP ✅] {domain}")
        except Exception:
            pass

    def run_nslookup_test(self):
        test_dom = self.clean_domain(self.test_input.get())
        if not test_dom:
            return
        self.log_message(f"--- Bắt đầu kiểm tra nslookup cho [{test_dom}] ---")
        def _run():
            try:
                cmd = f"nslookup {test_dom} 127.0.0.1"
                proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                out = proc.stdout.strip()
                if "0.0.0.0" in out:
                    self.log_message(f"KẾT QUẢ: Tên miền [{test_dom}] ĐÃ BỊ CHẶN THÀNH CÔNG (trả về 0.0.0.0)!")
                else:
                    self.log_message(f"KẾT QUẢ:\n{out}")
            except Exception as e:
                self.log_message(f"Lỗi kiểm tra: {e}")
        threading.Thread(target=_run, daemon=True).start()

    def manual_flush_sockets(self):
        kill_browser_active_connections()
        self.log_message("⚡ [THÀNH CÔNG] Đã xóa sạch cache DNS và cắt đứt các kết nối TCP Keep-Alive cũ!")
        messagebox.showinfo("Đã cắt kết nối cũ", "Đã xóa sạch bộ đệm DNS và yêu cầu đóng các kết nối cũ.\n\nNếu bạn đang mở sẵn tab Facebook trên trình duyệt, hãy tắt tab đó đi và mở tab mới để thấy web bị chặn ngay lập tức!")

    def manual_restore_network(self):
        if self.running:
            self.stop_proxy()
        else:
            if sys.platform == "win32":
                threading.Thread(target=self._restore_windows_network, daemon=True).start()
        messagebox.showinfo("Đã khôi phục mạng", "Đã trả DNS về tự động (DHCP) và dọn sạch file hosts!\n\nMọi website hoạt động lại bình thường.")

    def on_close(self):
        if self.running:
            if messagebox.askyesno("Thoát", "DNS Proxy đang hoạt động. Bạn có muốn tắt Proxy và khôi phục cài đặt mạng trước khi thoát không?"):
                self.stop_proxy()
                time.sleep(0.5)
        self.root.destroy()
        sys.exit(0)

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = StandaloneDNSProxyApp()
    app.run()
