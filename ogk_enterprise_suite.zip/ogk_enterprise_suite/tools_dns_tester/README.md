# OGK STANDALONE DNS PROXY TESTER
*Công cụ thử nghiệm DNS Proxy độc lập với giao diện đồ họa Windows*

## 1. Mục đích
Công cụ này được thiết kế tách biệt hoàn toàn để bạn có thể:
- Thử nghiệm trực quan khả năng chặn website của DNS Proxy `127.0.0.1:53`.
- Nhập bất kỳ đường link / tên miền nào muốn chặn (như `tiktok.com`, `shopee.vn`, `facebook.com`...).
- Quan sát từng dòng truy vấn DNS phát sinh từ trình duyệt của bạn trong khung **Nhật ký thời gian thực (Live DNS Log)**.
- Kiểm chứng khả năng chặn thực tế trên trình duyệt web (Chrome, Edge, Firefox, Cốc Cốc) nhờ cơ chế chặn kép (DNS Proxy + Windows Hosts).

## 2. Hướng dẫn sử dụng
1. Nhấp đúp chuột vào file **`CHAY_DNS_PROXY.bat`** (Bấm *Yes* khi Windows hỏi quyền Administrator).
2. Trên giao diện vừa hiện ra:
   - Thêm tên miền bạn muốn chặn vào ô nhập (vd: `shopee.vn`) $ightarrow$ bấm **+ Thêm Vào Danh Sách Chặn**.
   - Bấm nút to màu xanh: **▶ BẬT DNS PROXY & CHẶN WEB**.
3. Mở trình duyệt web của bạn:
   - Thử vào: `https://www.tiktok.com` hoặc trang bạn vừa thêm $ightarrow$ Trình duyệt lập tức báo không thể truy cập (`ERR_CONNECTION_REFUSED`).
   - Nhìn vào khung nhật ký trên giao diện, bạn sẽ thấy dòng đỏ: `[BỊ CHẶN 🚫] tiktok.com -> 0.0.0.0`.
   - Thử tìm kiếm trên Google $ightarrow$ Tự động bật SafeSearch an toàn và ghi nhận dòng: `[SAFESEARCH 🛡️]`.
4. Khi muốn tắt:
   - Bấm nút đỏ: **⏹ TẮT DNS PROXY (Khôi phục mạng)**.
   - Ứng dụng tự động khôi phục DNS mạng về ban đầu (DHCP) và dọn sạch blocklist.
