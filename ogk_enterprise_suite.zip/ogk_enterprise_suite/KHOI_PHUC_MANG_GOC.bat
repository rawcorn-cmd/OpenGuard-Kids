@echo off
setlocal
title "OGK - Khoi Phuc Cai Dat Mang Goc"

:: Auto-elevate to Administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [THONG BAO] Dang yeu cau quyen Administrator de khoi phuc DNS va Hosts...
    powershell -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
    exit /b
)

echo ====================================================================
echo   OGK NETWORK RESET: DANG KHOI PHUC MANG WINDOWS VE MAC DINH...
echo ====================================================================

:: 1. Tra DNS card mang ve tu dong (DHCP)
echo 1. Dang tra DNS card mang ve tu dong (DHCP)...
powershell -Command "Get-NetAdapter | Where-Object Status -eq Up | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }"

:: 2. Don sach cac dong chan trong file hosts
echo 2. Dang don sach blocklist trong file hosts...
powershell -Command "$p='C:\Windows\System32\drivers\etc\hosts'; if (Test-Path $p) { $c = (Get-Content $p -Raw) -replace '(?s)# --- OGK.*?END ---', ''; Set-Content $p -Value $c.Trim() }"

:: 3. Xoa sach cache DNS cua Windows
echo 3. Dang xoa bo dem DNS (ipconfig /flushdns)...
ipconfig /flushdns >nul 2>&1

echo.
echo ====================================================================
echo   ✓ DA KHOI PHUC MANG HOAN TAT 100%!
echo   Tat ca website (Discord, Instagram,...) hoat dong lai binh thuong.
echo ====================================================================
echo.
pause
