# CHÍNH SÁCH QUYỀN RIÊNG TƯ VÀ MINH BẠCH DỮ LIỆU (PRIVACY.MD)

> **Dự án: OGK 2.0 (Open Guardian for Kids)**  
> *Triết lý cốt lõi: 'Công cụ đồng hành, không phải phần mềm theo dõi lén'*  
> *Tuân thủ: Nghị định 13/2023/NĐ-CP về Bảo vệ Dữ liệu Cá nhân & Luật Trẻ em 2016*

---

## 1. Tuyên bố Triết lý Thu thập Dữ liệu Tối thiểu (NT2)

Hệ thống OGK **tuyệt đối KHÔNG thu thập**:
- Không đọc nội dung tin nhắn, email, văn bản hoặc tài liệu cá nhân.
- Không ghi nhận lịch sử gõ phím (keylogger).
- Không chụp ảnh màn hình hoặc quay video màn hình (screen capture).
- Không lưu đường dẫn URL đầy đủ (chỉ lưu tên miền cấp hai/FQDN phục vụ lọc an toàn).
- Không thu thập tiêu đề chi tiết của cửa sổ duyệt web (window titles).
- Không gửi bất kỳ dữ liệu nào đến dịch vụ của bên thứ ba.

---

## 2. Bảng Đặc tả Thuộc tính Dữ liệu (Data Field Mapping Matrix)

Mọi trường dữ liệu trong lược đồ sự kiện `EventRecord` và cơ sở dữ liệu đều có mục đích xác đáng, thời hạn bảo lưu rõ ràng và quyền hạn truy cập minh bạch:

| Trường dữ liệu | Kiểu dữ liệu | Mục đích kỹ thuật & sử dụng | Thời hạn lưu trữ | Ai được xem? | Căn cứ bảo vệ |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `ts` | Dấu thời gian UNIX (float) | Xác định thời điểm xảy ra sự kiện để tính thời lượng sử dụng trong ngày và đối chiếu lịch tuần | 90 ngày (Tự động xóa) | Phụ huynh, Trẻ em, Hệ thống | Điều 9 Nghị định 13/2023 |
| `device_id` | Chuỗi ký tự định danh (UUID) | Định tuyến chính sách và lệnh khẩn cấp (khóa, mở) đến đúng máy tính của trẻ | Cho đến khi gỡ thiết bị | Phụ huynh, Trẻ em, Quản trị viên | Định danh kỹ thuật thiết bị |
| `child_id` | Chuỗi ký tự (UUID/Slug) | Phân tách hồ sơ và thời gian biểu độc lập giữa các con trong gia đình | Cho đến khi phụ huynh xóa hồ sơ | Phụ huynh, Trẻ em | Phân quyền IDOR |
| `type` | Enum (`app_start`, `app_stop`, `domain_query`, `blocked_app`, `blocked_domain`, `quota_warning`, `locked`, `unlock_request`, `override_granted`) | Phân loại hành động hệ thống để tính giờ thực tế, cảnh báo hạn mức và phát hiện chặn sai | 90 ngày (Tự động xóa) | Phụ huynh, Trẻ em | Minh bạch hai chiều (NT5) |
| `subject` | Chuỗi ký tự (Tên tiến trình exe hoặc Domain) | Tên ứng dụng (vd: `roblox.exe`) hoặc Tên miền (vd: `scratch.mit.edu`). **Tuyệt đối không lưu URL chi tiết hay tham số truy vấn.** | 90 ngày (Tự động xóa) | Phụ huynh, Trẻ em | Tối thiểu hóa dữ liệu (NT2) |
| `duration_sec` | Số nguyên (giây) | Thời lượng sử dụng thực tế (đã trừ thời gian máy khóa hoặc không thao tác > 5 phút) | 90 ngày (Tự động xóa) | Phụ huynh, Trẻ em | Đếm thực tế (F1) |
| `policy_id` | Chuỗi ký tự | Đối chiếu phiên bản chính sách đang áp dụng tại thời điểm ghi nhận sự kiện | 90 ngày (Tự động xóa) | Phụ huynh, Trẻ em | Kiểm toán chính sách (F4) |
| `idempotency_key` | Chuỗi UUID băm | Khóa chống trùng sự kiện khi đồng bộ theo lô sau thời gian máy hoạt động ngoại tuyến | 14 ngày | Chỉ hệ thống nội bộ | Chống trùng lặp dữ liệu |

---

## 3. Quyền của Trẻ em và Phụ huynh

### 3.1. Quyền được biết và Minh bạch hai chiều (NT1, NT5)
- Biểu tượng OGK luôn hiển thị thường trực tại Khay hệ thống (System Tray). Trẻ luôn nhận biết khi phần mềm đang hoạt động.
- Trẻ có màn hình **"Hôm nay em đã dùng gì"** hiển thị cùng tập số liệu (thời gian đã dùng, top ứng dụng, top trang web) mà phụ huynh thấy trên Dashboard.
- Trẻ được quyền xem toàn bộ **Nhật ký kiểm toán (Audit Log)** để biết phụ huynh đã điều chỉnh hạn mức hay thêm quy tắc chặn vào lúc nào.

### 3.2. Quyền có tiếng nói (NT3)
- Nút **"Xin thêm giờ"**: Trẻ có thể gửi yêu cầu xin thêm 15, 30 phút kèm lý do (ví dụ: làm bài tập nhóm).
- Nút **"Con nghĩ trang này bị chặn nhầm"**: Gửi kiến nghị mở khóa cho các trang web giáo dục/học tập bị nhận diện sai.
- Mọi yêu cầu được ghi nhận và có trạng thái phản hồi rõ ràng từ phụ huynh.

### 3.3. Quyền được lãng quên (Right to be Forgotten - F3)
- Phụ huynh có thể nhấn nút **"Xóa toàn bộ dữ liệu của con tôi"** bất cứ lúc nào trên Dashboard.
- Hệ thống lập tức xóa vĩnh viễn toàn bộ sự kiện, nhật ký sử dụng trên máy chủ OGK-Server và phát lệnh xóa sạch bộ nhớ đệm cục bộ trên OGK-Agent.
