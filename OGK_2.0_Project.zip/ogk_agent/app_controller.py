"""Application controller and process monitor.
Implements F2:
- Control apps by process name + SHA-256 hash of executable
- Gracefully terminate blocked processes (terminate -> kill)
- Display explanation dialog (NT4: Mọi hành động phải giải thích được, không im lặng)
- Record 'blocked_app', 'app_start', 'app_stop' events
"""

import ctypes
import os
import sys
import time
from typing import Callable, Dict, List, Optional, Set
import psutil
from ogk_shared.constants import Category, EventType
from ogk_shared.crypto import compute_file_sha256
from ogk_agent.local_cache import queue_event


def get_foreground_process_info() -> Optional[Dict]:
    """Retrieve process name, window title, and executable path of current foreground window."""
    if sys.platform != "win32":
        return None
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value:
            proc = psutil.Process(pid.value)
            buf = ctypes.create_unicode_buffer(512)
            user32.GetWindowTextW(hwnd, buf, 512)
            title = buf.value or ""
            return {
                "pid": pid.value,
                "name": proc.name().lower(),
                "title": title,
                "exe": proc.exe()
            }
    except Exception:
        pass
    return None


class AppController:
    def __init__(
        self,
        device_id: str,
        child_id: str,
        on_app_blocked: Optional[Callable[[str, str, str], None]] = None
    ):
        self.device_id = device_id
        self.child_id = child_id
        self.on_app_blocked = on_app_blocked
        self.policy: Optional[dict] = None

        # Known file hashes cache: file_path -> sha256
        self.hash_cache: Dict[str, str] = {}

        # Recently alerted PIDs to prevent repeated alert spam in single second
        self.recently_blocked_pids: Set[int] = set()

        # Active foreground app tracking
        self.active_app_name: Optional[str] = None
        self.active_app_title: Optional[str] = None
        self.active_app_start_ts: float = 0.0

    def get_current_foreground_info(self) -> dict:
        now = time.time()
        duration = int(now - self.active_app_start_ts) if self.active_app_start_ts > 0 else 0
        return {
            "name": self.active_app_name or "Chưa xác định",
            "title": self.active_app_title or "",
            "duration_seconds": duration
        }

    def update_policy(self, policy_dict: dict):
        self.policy = policy_dict

    def get_file_hash(self, exe_path: str) -> Optional[str]:
        if not exe_path or not os.path.isfile(exe_path):
            return None
        if exe_path in self.hash_cache:
            return self.hash_cache[exe_path]
        digest = compute_file_sha256(exe_path)
        if digest:
            self.hash_cache[exe_path] = digest
        return digest

    def scan_and_enforce(self, gaming_exceeded: bool = False) -> Optional[dict]:
        """Scan active processes against policy rules and SHA-256 hashes.
        Gracefully terminates violations and notifies UI.
        """
        if not self.policy:
            return None

        app_rules = self.policy.get("app_rules", [])
        policy_id = self.policy.get("policy_id", "default")
        blocked_info = None

        # Track foreground application for usage reporting
        fg_info = get_foreground_process_info()
        fg_name = fg_info["name"] if fg_info else None
        fg_title = fg_info.get("title", "") if fg_info else ""

        if fg_name != self.active_app_name:
            now = time.time()
            if self.active_app_name and self.active_app_start_ts > 0:
                duration = int(now - self.active_app_start_ts)
                if duration >= 5:  # Log sessions >= 5 seconds
                    queue_event(
                        self.device_id, self.child_id, EventType.APP_STOP.value,
                        self.active_app_name, duration, policy_id
                    )
            self.active_app_name = fg_name
            self.active_app_title = fg_title
            self.active_app_start_ts = now
            if fg_name:
                queue_event(
                    self.device_id, self.child_id, EventType.APP_START.value,
                    fg_name, 0, policy_id
                )
        else:
            self.active_app_title = fg_title

        # Iterate running processes
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                pid = proc.info["pid"]
                pname = (proc.info["name"] or "").lower()

                # Skip critical system processes
                if pid <= 4 or pname in ("explorer.exe", "svchost.exe", "csrss.exe", "services.exe", "lsass.exe", "python.exe"):
                    continue

                exe_path = None
                try:
                    exe_path = proc.exe()
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                file_hash = self.get_file_hash(exe_path) if exe_path else None

                # Check against app rules
                matched_rule = None
                for rule in app_rules:
                    rule_name = rule.get("name", "").lower()
                    rule_hash = (rule.get("sha256") or "").lower()
                    rule_action = rule.get("action", "block")

                    if rule_action != "block":
                        continue

                    # Match by process name
                    if rule_name and pname == rule_name:
                        matched_rule = rule
                        break

                    # Match by SHA-256 hash (Renamed binary evasion check!)
                    if rule_hash and file_hash and rule_hash == file_hash:
                        matched_rule = rule
                        break

                # Also check gaming budget enforcement
                if not matched_rule and gaming_exceeded:
                    is_game = any(r.get("name", "").lower() == pname and r.get("category") == Category.GAMING.value for r in app_rules)
                    if is_game:
                        matched_rule = {
                            "name": pname,
                            "display_name": pname,
                            "reason": "Hôm nay con đã dùng hết 45 phút ngân sách cho Trò chơi"
                        }


                if matched_rule:
                    reason = matched_rule.get("reason", "Ứng dụng bị giới hạn theo quy định cha mẹ")
                    display_name = matched_rule.get("display_name") or pname

                    # Terminate process gracefully
                    try:
                        proc.terminate()
                        proc.wait(timeout=1.0)
                    except (psutil.TimeoutExpired, Exception):
                        try:
                            proc.kill()
                        except Exception:
                            pass

                    # Record event once per process lifecycle
                    if pid not in self.recently_blocked_pids:
                        self.recently_blocked_pids.add(pid)
                        queue_event(
                            self.device_id, self.child_id, EventType.BLOCKED_APP.value,
                            pname, 0, policy_id
                        )

                        # Display explanation dialog via callback
                        if self.on_app_blocked:
                            self.on_app_blocked(display_name, reason, "Cha mẹ của em")

                        blocked_info = {
                            "name": display_name,
                            "reason": reason,
                            "by": "Cha mẹ của em"
                        }

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return blocked_info
