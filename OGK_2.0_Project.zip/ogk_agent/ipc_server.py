"""Local IPC HTTP server for communication between OGK Service and Tray UI.
Listens strictly on 127.0.0.1:51111 with token authentication.
"""

import json
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Callable, Dict, Optional
from ogk_agent.config import IPC_PORT, get_or_create_ipc_secret



class IPCHandler(BaseHTTPRequestHandler):
    # Class-level reference to the IPCServer controller
    server_controller = None

    def log_message(self, format, *args):
        # Suppress noisy HTTP request logging
        return

    def _send_json(self, status_code: int, data: dict):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def _check_auth(self) -> bool:
        auth_token = self.headers.get("X-OGK-IPC-Token")
        expected = get_or_create_ipc_secret()
        return auth_token == expected

    def do_GET(self):
        if not self._check_auth():
            self._send_json(401, {"error": "Unauthorized IPC request"})
            return

        if self.path == "/status":
            status = self.server_controller.get_status()
            self._send_json(200, status)
        elif self.path == "/last-blocked":
            info = self.server_controller.get_last_blocked()
            self._send_json(200, info or {})
        else:
            self._send_json(404, {"error": "Not Found"})

    def do_POST(self):
        if not self._check_auth():
            self._send_json(401, {"error": "Unauthorized IPC request"})
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        if self.path == "/notify-blocked":
            self.server_controller.trigger_blocked_popup(payload)
            self._send_json(200, {"status": "ok"})
        elif self.path == "/request-extra-time":
            res = self.server_controller.handle_extra_time_request(payload)
            self._send_json(200, res)
        elif self.path == "/report-false-positive":
            res = self.server_controller.handle_false_positive_request(payload)
            self._send_json(200, res)
        else:
            self._send_json(404, {"error": "Not Found"})


class IPCServer:
    def __init__(
        self,
        status_provider: Callable[[], dict],
        request_handler: Callable[[str, str, str], dict]
    ):
        self.status_provider = status_provider
        self.request_handler = request_handler
        self.httpd: Optional[HTTPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.last_blocked_info: Optional[dict] = None
        self.ui_popup_callback: Optional[Callable[[dict], None]] = None

    def get_status(self) -> dict:
        return self.status_provider()

    def get_last_blocked(self) -> Optional[dict]:
        return self.last_blocked_info

    def set_last_blocked(self, info: dict):
        self.last_blocked_info = info
        if self.ui_popup_callback:
            self.ui_popup_callback(info)

    def trigger_blocked_popup(self, info: dict):
        if "ts" not in info:
            info["ts"] = time.time()
        self.last_blocked_info = info
        if self.ui_popup_callback:
            self.ui_popup_callback(info)


    def handle_extra_time_request(self, payload: dict) -> dict:
        reason = payload.get("reason", "Con cần thêm thời gian để làm bài tập")
        minutes = payload.get("minutes", 15)
        return self.request_handler("extra_time", f"+{minutes} phút", reason)

    def handle_false_positive_request(self, payload: dict) -> dict:
        subject = payload.get("subject", "")
        reason = payload.get("reason", "Con nghĩ trang này bị chặn nhầm")
        return self.request_handler("false_positive", subject, reason)

    def start(self):
        IPCHandler.server_controller = self
        try:
            self.httpd = HTTPServer(("127.0.0.1", IPC_PORT), IPCHandler)
            self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
            self.thread.start()
            print(f"[+] IPC Server listening on 127.0.0.1:{IPC_PORT}")
        except OSError as e:
            print(f"[-] Could not start IPC server on port {IPC_PORT}: {e}")

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
