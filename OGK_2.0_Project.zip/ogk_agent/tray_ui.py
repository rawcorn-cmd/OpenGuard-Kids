"""System Tray UI for Child Session.
Implements:
- NT1: System tray icon always visible; startup notification; stops if tray cannot run (Anti-abuse).
- NT3: Buttons 'Xin thêm giờ' and 'Báo chặn nhầm'.
- NT4: Explanation dialog when an app or website is blocked.
- NT5: 'Hôm nay em đã dùng gì' child transparency viewer and parent audit log viewer.
"""

import json
import os
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Optional
import httpx
from PIL import Image, ImageDraw

from ogk_agent.config import IPC_PORT, get_or_create_ipc_secret
import pystray


def create_tray_icon_image(status_color: str = "#4f46e5") -> Image.Image:
    """Generate a high-res shield icon for the system tray."""
    img = Image.new("RGBA", (64, 64), color=(0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Draw shield polygon
    shield_coords = [
        (32, 6), (54, 14), (54, 38), (32, 58), (10, 38), (10, 14)
    ]
    draw.polygon(shield_coords, fill=status_color, outline="#ffffff")
    # Draw star or checkmark inside
    draw.ellipse([(26, 22), (38, 34)], fill="#ffffff")
    return img


class ChildTrayApp:
    def __init__(self, server_url: str = "http://127.0.0.1:8000"):
        self.server_url = server_url.rstrip("/")
        self.ipc_token = get_or_create_ipc_secret()
        self.ipc_url = f"http://127.0.0.1:{IPC_PORT}"

        self.icon: Optional[pystray.Icon] = None
        self.running = False
        self.last_status = {}

        # Tkinter root for GUI popups and dialogs
        self.tk_root: Optional[tk.Tk] = None

    def _ipc_get(self, endpoint: str) -> dict:
        try:
            with httpx.Client(timeout=0.6) as client:
                res = client.get(
                    f"{self.ipc_url}{endpoint}",
                    headers={"X-OGK-IPC-Token": self.ipc_token}
                )
                if res.status_code == 200:
                    return res.json()
        except Exception:
            pass
        return {}

    def _ipc_post(self, endpoint: str, payload: dict) -> dict:
        try:
            with httpx.Client(timeout=2.0) as client:
                res = client.post(
                    f"{self.ipc_url}{endpoint}",
                    json=payload,
                    headers={"X-OGK-IPC-Token": self.ipc_token}
                )
                if res.status_code == 200:
                    return res.json()
        except Exception as e:
            return {"error": str(e)}
        return {}

    def get_status(self) -> dict:
        return self._ipc_get("/status")

    def show_startup_notification(self):
        """NT1: Notify child that agent has started and is actively companioning."""
        if self.icon:
            self.icon.notify(
                "OGK 2.0 đã khởi động và đang hoạt động.\nCông cụ đồng hành, bảo vệ an toàn cho em!",
                "🛡️ OGK 2.0 Sẵn sàng"
            )

    def show_notification_dialog(self, noti: dict):
        """Display transparent, context-aware native Windows dialog according to notification type."""
        noti_type = noti.get("type", "domain")
        subject = noti.get("subject", "Thông báo")
        reason = noti.get("reason", "Hệ thống bảo vệ OGK")
        rule_by = noti.get("by", "Cha mẹ của em")

        # Dynamic styling according to notification type
        if noti_type == "reward":
            win_title = "🎉 Tin Vui Từ Cha Mẹ - OGK 2.0"
            bg_color = "#f0fdf4"
            card_border = "#86efac"
            header_color = "#15803d"
            header_icon = "🎉"
            header_text = subject
            obj_label = ""
            btn_primary_text = "Cảm ơn cha mẹ! (Đóng)"
            btn_primary_bg = "#16a34a"
            show_report_btn = False
            show_extra_time_btn = False
            report_btn_text = ""

        elif noti_type == "warning":
            win_title = "⏳ Nhắc Nhở Thời Gian - OGK 2.0"
            bg_color = "#fffbeb"
            card_border = "#fde68a"
            header_color = "#b45309"
            header_icon = "⏳"
            header_text = "Nhắc nhở: Sắp hết thời gian sử dụng hôm nay"
            obj_label = f"Thời lượng: {subject}"
            btn_primary_text = "Em đã hiểu"
            btn_primary_bg = "#d97706"
            show_report_btn = False
            show_extra_time_btn = True
            report_btn_text = ""

        elif noti_type == "lock":
            win_title = "🔒 Hết Giờ Sử Dụng - OGK 2.0"
            bg_color = "#f8fafc"
            card_border = "#cbd5e1"
            header_color = "#0f172a"
            header_icon = "🔒"
            header_text = "Đã đến giờ nghỉ ngơi theo thỏa thuận gia đình"
            obj_label = f"Trạng thái: {subject}"
            btn_primary_text = "Đóng thông báo"
            btn_primary_bg = "#475569"
            show_report_btn = False
            show_extra_time_btn = True
            report_btn_text = ""

        elif noti_type == "app":
            win_title = "🚫 Ứng Dụng Bị Hạn Chế - OGK 2.0"
            bg_color = "#fff5f5"
            card_border = "#fecaca"
            header_color = "#991b1b"
            header_icon = "🚫"
            header_text = "Ứng dụng tạm thời chưa được mở"
            obj_label = f"Ứng dụng: {subject}"
            btn_primary_text = "Em đã hiểu"
            btn_primary_bg = "#4f46e5"
            show_report_btn = True
            show_extra_time_btn = False
            report_btn_text = "Con nghĩ ứng dụng này bị chặn nhầm"

        elif noti_type == "command":
            is_good = any(w in subject.lower() for w in ["mở", "cộng", "thưởng", "duyệt"])
            win_title = "🔔 Thông Báo Từ Cha Mẹ - OGK 2.0"
            bg_color = "#f0fdf4" if is_good else "#f8fafc"
            card_border = "#86efac" if is_good else "#cbd5e1"
            header_color = "#15803d" if is_good else "#0f172a"
            header_icon = "✨" if is_good else "🔒"
            header_text = subject
            obj_label = ""
            btn_primary_text = "Em đã hiểu"
            btn_primary_bg = "#16a34a" if is_good else "#475569"
            show_report_btn = False
            show_extra_time_btn = False
            report_btn_text = ""

        else: # noti_type == "domain" or default
            win_title = "🌐 Trang Web Bị Hạn Chế - OGK 2.0"
            bg_color = "#fff5f5"
            card_border = "#fecaca"
            header_color = "#991b1b"
            header_icon = "🌐"
            header_text = "Trang web tạm thời chưa được phép truy cập"
            obj_label = f"Địa chỉ trang web: {subject}"
            btn_primary_text = "Em đã hiểu"
            btn_primary_bg = "#4f46e5"
            show_report_btn = True
            show_extra_time_btn = False
            report_btn_text = "Con nghĩ trang này bị chặn nhầm"

        def _gui():
            root = tk.Tk()
            root.title(win_title)
            root.geometry("520x330")
            root.resizable(False, False)
            root.attributes("-topmost", True)
            root.configure(bg=bg_color)

            # Center window
            root.update_idletasks()
            sw = root.winfo_screenwidth()
            sh = root.winfo_screenheight()
            x = max(0, (sw - 520) // 2)
            y = max(0, (sh - 330) // 2)
            root.geometry(f"520x330+{x}+{y}")

            frame = tk.Frame(root, bg=bg_color, padx=24, pady=20)
            frame.pack(fill="both", expand=True)

            # Header with icon
            hdr_box = tk.Frame(frame, bg=bg_color)
            hdr_box.pack(fill="x", pady=(0, 12))

            tk.Label(
                hdr_box,
                text=f"{header_icon} {header_text}",
                font=("Segoe UI", 13, "bold"),
                fg=header_color,
                bg=bg_color,
                wraplength=470,
                justify="left"
            ).pack(anchor="w")

            # Card box for details
            card = tk.Frame(frame, bg="#ffffff", padx=14, pady=12, highlightbackground=card_border, highlightthickness=1)
            card.pack(fill="x", pady=(0, 14))

            if obj_label:
                tk.Label(
                    card,
                    text=obj_label,
                    font=("Segoe UI", 11, "bold"),
                    fg="#0f172a",
                    bg="#ffffff",
                    wraplength=450,
                    justify="left"
                ).pack(anchor="w", pady=(0, 6))

            tk.Label(
                card,
                text=reason,
                font=("Segoe UI", 10),
                fg="#334155",
                bg="#ffffff",
                wraplength=450,
                justify="left"
            ).pack(anchor="w", pady=(0, 6))

            if rule_by:
                tk.Label(
                    card,
                    text=f"📌 {rule_by}",
                    font=("Segoe UI", 8, "italic"),
                    fg="#64748b",
                    bg="#ffffff"
                ).pack(anchor="w")

            # Buttons box
            btn_box = tk.Frame(frame, bg=bg_color)
            btn_box.pack(fill="x", pady=(6, 0))

            tk.Button(
                btn_box,
                text=btn_primary_text,
                bg=btn_primary_bg,
                fg="white",
                font=("Segoe UI", 9, "bold"),
                padx=16,
                pady=7,
                bd=0,
                cursor="hand2",
                command=root.destroy
            ).pack(side="right", padx=(8, 0))

            if show_report_btn:
                def on_report():
                    root.destroy()
                    self.action_report_false_positive(prefilled_subject=subject)

                tk.Button(
                    btn_box,
                    text=report_btn_text,
                    bg="#e2e8f0",
                    fg="#0f172a",
                    font=("Segoe UI", 9),
                    padx=12,
                    pady=7,
                    bd=0,
                    cursor="hand2",
                    command=on_report
                ).pack(side="right")

            if show_extra_time_btn:
                def on_req_time():
                    root.destroy()
                    self.action_request_extra_time()

                tk.Button(
                    btn_box,
                    text="⏱️ Xin cha mẹ cho thêm giờ",
                    bg="#e2e8f0",
                    fg="#0f172a",
                    font=("Segoe UI", 9),
                    padx=12,
                    pady=7,
                    bd=0,
                    cursor="hand2",
                    command=on_req_time
                ).pack(side="right")

            root.mainloop()

        threading.Thread(target=_gui, daemon=True).start()

    def show_block_explanation_dialog(self, subject: str, reason: str, rule_by: str = "Cha mẹ của em"):
        """NT4: Backward compatibility helper forwarding to show_notification_dialog."""
        self.show_notification_dialog({
            "type": "domain" if "." in subject else "app",
            "subject": subject,
            "reason": reason,
            "by": rule_by
        })

    def action_request_extra_time(self):
        """NT3: Child submits request for extra screen time."""
        def _gui():
            root = tk.Tk()
            root.title("⏱️ Xin thêm giờ - OGK 2.0")
            root.geometry("420x260")
            root.resizable(False, False)
            root.attributes("-topmost", True)
            root.configure(bg="#ffffff")

            frame = tk.Frame(root, bg="#ffffff", padx=20, pady=20)
            frame.pack(fill="both", expand=True)

            tk.Label(frame, text="⏱️ Gửi yêu cầu xin thêm giờ tới cha mẹ", font=("Segoe UI", 12, "bold"), fg="#1e293b", bg="#ffffff").pack(anchor="w", pady=(0, 10))

            tk.Label(frame, text="Số phút xin thêm:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(anchor="w")
            mins_var = tk.StringVar(value="15")
            combo = ttk.Combobox(frame, textvariable=mins_var, values=["15", "30", "45"], state="readonly", width=10)
            combo.pack(anchor="w", pady=(2, 10))

            tk.Label(frame, text="Lý do gửi bố mẹ:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(anchor="w")
            reason_entry = tk.Entry(frame, font=("Segoe UI", 9), width=45)
            reason_entry.insert(0, "Con cần thêm thời gian để hoàn thành bài tập nhóm.")
            reason_entry.pack(anchor="w", pady=(2, 15))

            def submit():
                mins = int(mins_var.get())
                reason = reason_entry.get().strip() or "Con xin thêm giờ"
                res = self._ipc_post("/request-extra-time", {"minutes": mins, "reason": reason})
                root.destroy()
                messagebox.showinfo("Đã gửi yêu cầu", "Yêu cầu đã được gửi đến bảng điều khiển của cha mẹ!\nCha mẹ sẽ xem và phản hồi sớm cho con.")

            tk.Button(frame, text="Gửi yêu cầu", bg="#10b981", fg="white", font=("Segoe UI", 9, "bold"), padx=15, pady=6, command=submit).pack(side="right")
            tk.Button(frame, text="Hủy", bg="#f1f5f9", font=("Segoe UI", 9), padx=10, pady=6, command=root.destroy).pack(side="right", padx=5)

            root.mainloop()

        threading.Thread(target=_gui, daemon=True).start()

    def action_report_false_positive(self, prefilled_subject: str = ""):
        """NT3: Child reports a site or app was blocked by mistake."""
        def _gui():
            root = tk.Tk()
            root.title("🌐 Báo chặn nhầm - OGK 2.0")
            root.geometry("440x260")
            root.resizable(False, False)
            root.attributes("-topmost", True)
            root.configure(bg="#ffffff")

            frame = tk.Frame(root, bg="#ffffff", padx=20, pady=20)
            frame.pack(fill="both", expand=True)

            tk.Label(frame, text="🌐 Báo cáo trang web/ứng dụng bị chặn nhầm", font=("Segoe UI", 12, "bold"), fg="#1e293b", bg="#ffffff").pack(anchor="w", pady=(0, 10))

            tk.Label(frame, text="Tên trang web hoặc ứng dụng:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(anchor="w")
            subj_entry = tk.Entry(frame, font=("Segoe UI", 9), width=45)
            if prefilled_subject:
                subj_entry.insert(0, prefilled_subject)
            subj_entry.pack(anchor="w", pady=(2, 10))

            tk.Label(frame, text="Lý do con nghĩ đây là chặn nhầm:", font=("Segoe UI", 9, "bold"), bg="#ffffff").pack(anchor="w")
            reason_entry = tk.Entry(frame, font=("Segoe UI", 9), width=45)
            reason_entry.insert(0, "Đây là trang web phục vụ việc học tập của con ở trường.")
            reason_entry.pack(anchor="w", pady=(2, 15))

            def submit():
                subj = subj_entry.get().strip()
                reason = reason_entry.get().strip()
                if not subj:
                    messagebox.showwarning("Thiếu thông tin", "Vui lòng nhập tên trang web hoặc ứng dụng.")
                    return
                self._ipc_post("/report-false-positive", {"subject": subj, "reason": reason})
                root.destroy()
                messagebox.showinfo("Đã gửi kiến nghị", f"Kiến nghị mở khóa cho '{subj}' đã được gửi tới cha mẹ!")

            tk.Button(frame, text="Gửi kiến nghị", bg="#0284c7", fg="white", font=("Segoe UI", 9, "bold"), padx=15, pady=6, command=submit).pack(side="right")
            tk.Button(frame, text="Hủy", bg="#f1f5f9", font=("Segoe UI", 9), padx=10, pady=6, command=root.destroy).pack(side="right", padx=5)

            root.mainloop()

        threading.Thread(target=_gui, daemon=True).start()

    def action_open_child_summary(self):
        """NT5: Open 'Hôm nay em đã dùng gì' Native Windows Transparency Window (NOT web browser)."""
        st = self.get_status()
        quota_sec = st.get("quota_seconds", 90 * 60)
        used_sec = st.get("used_seconds", 0)
        rem_sec = st.get("remaining_seconds", max(0, quota_sec - used_sec))
        apps_today = st.get("all_apps_today", [])

        quota_m = quota_sec // 60
        used_m = used_sec // 60
        rem_m = rem_sec // 60

        def _gui():
            root = tk.Tk()
            root.title("🌟 Hôm nay em đã dùng gì? - OGK 2.0 (Minh Bạch NT5)")
            root.geometry("560x620")
            root.resizable(False, False)
            root.attributes("-topmost", True)
            root.configure(bg="#f8fafc")

            # Main container with padding
            main_frame = tk.Frame(root, bg="#f8fafc", padx=20, pady=16)
            main_frame.pack(fill="both", expand=True)

            # Header Banner
            header = tk.Frame(main_frame, bg="#4f46e5", padx=16, pady=14)
            header.pack(fill="x", pady=(0, 14))
            tk.Label(header, text="🌟 NHẬT KÝ SỬ DỤNG HÔM NAY", font=("Segoe UI", 13, "bold"), fg="#ffffff", bg="#4f46e5").pack(anchor="w")
            tk.Label(header, text="Công cụ đồng hành, bảo vệ em an toàn • Minh bạch hai chiều (NT5)", font=("Segoe UI", 8), fg="#c7d2fe", bg="#4f46e5").pack(anchor="w", pady=(2, 0))

            # Screen Time Stats Card (White rounded card)
            stats_card = tk.Frame(main_frame, bg="#ffffff", padx=14, pady=12, highlightbackground="#cbd5e1", highlightthickness=1)
            stats_card.pack(fill="x", pady=(0, 14))

            tk.Label(stats_card, text="⏱️ THỜI GIAN MÀN HÌNH HÔM NAY", font=("Segoe UI", 9, "bold"), fg="#475569", bg="#ffffff").pack(anchor="w", pady=(0, 6))

            cols = tk.Frame(stats_card, bg="#ffffff")
            cols.pack(fill="x", pady=(0, 8))

            col1 = tk.Frame(cols, bg="#ffffff")
            col1.pack(side="left", expand=True, fill="x")
            tk.Label(col1, text=f"{quota_m} phút", font=("Segoe UI", 16, "bold"), fg="#1e293b", bg="#ffffff").pack(anchor="w")
            tk.Label(col1, text="Thời gian được cấp", font=("Segoe UI", 8), fg="#64748b", bg="#ffffff").pack(anchor="w")

            col2 = tk.Frame(cols, bg="#ffffff")
            col2.pack(side="left", expand=True, fill="x")
            tk.Label(col2, text=f"{used_m} phút", font=("Segoe UI", 16, "bold"), fg="#2563eb", bg="#ffffff").pack(anchor="w")
            tk.Label(col2, text="Đã sử dụng", font=("Segoe UI", 8), fg="#64748b", bg="#ffffff").pack(anchor="w")

            col3 = tk.Frame(cols, bg="#ffffff")
            col3.pack(side="left", expand=True, fill="x")
            rem_color = "#16a34a" if rem_m > 15 else "#dc2626"
            tk.Label(col3, text=f"{rem_m} phút", font=("Segoe UI", 16, "bold"), fg=rem_color, bg="#ffffff").pack(anchor="w")
            tk.Label(col3, text="Còn lại hôm nay", font=("Segoe UI", 8), fg="#64748b", bg="#ffffff").pack(anchor="w")

            # Progress Bar (Canvas)
            pct = min(1.0, used_sec / max(1, quota_sec))
            canv = tk.Canvas(stats_card, height=10, bg="#e2e8f0", highlightthickness=0)
            canv.pack(fill="x", pady=(4, 2))
            bar_color = "#22c55e" if pct < 0.8 else "#ef4444"
            canv.create_rectangle(0, 0, int(500 * pct), 10, fill=bar_color, width=0)

            # Apps Used List
            tk.Label(main_frame, text="📊 CÁC ỨNG DỤNG EM ĐÃ HOẠT ĐỘNG HÔM NAY", font=("Segoe UI", 9, "bold"), fg="#334155", bg="#f8fafc").pack(anchor="w", pady=(0, 4))

            list_frame = tk.Frame(main_frame, bg="#ffffff", highlightbackground="#cbd5e1", highlightthickness=1)
            list_frame.pack(fill="both", expand=True, pady=(0, 14))

            # Treeview table
            tree = ttk.Treeview(list_frame, columns=("App", "Title", "Time"), show="headings", height=7)
            tree.heading("App", text="Tên ứng dụng")
            tree.heading("Title", text="Tiêu đề cửa sổ")
            tree.heading("Time", text="Thời gian dùng")
            tree.column("App", width=120, anchor="w")
            tree.column("Title", width=250, anchor="w")
            tree.column("Time", width=100, anchor="e")

            if apps_today:
                for app in apps_today:
                    tree.insert("", "end", values=(app.get("name", ""), app.get("title", ""), f"{app.get('duration_minutes', 0)} phút"))
            else:
                tree.insert("", "end", values=("Chưa có ứng dụng", "Vừa mở máy tính", "0 phút"))

            scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)
            scrollbar.pack(side="right", fill="y")
            tree.pack(side="left", fill="both", expand=True)

            # Encouragement banner
            enc_box = tk.Frame(main_frame, bg="#e0f2fe", padx=10, pady=8)
            enc_box.pack(fill="x", pady=(0, 14))
            msg = "Chúc em có một ngày học tập và vui chơi thật vui vẻ, an toàn trên máy tính!"
            if rem_m <= 0:
                msg = "Hôm nay em đã dùng hết thời gian màn hình rồi, hãy nghỉ ngơi và tập thể dục nhé!"
            elif rem_m <= 15:
                msg = "Sắp hết thời gian sử dụng hôm nay rồi, em nhớ lưu bài tập và chuẩn bị nghỉ ngơi nhé!"
            tk.Label(enc_box, text=f"💡 {msg}", font=("Segoe UI", 8, "italic"), fg="#0369a1", bg="#e0f2fe", wraplength=500, justify="left").pack(anchor="w")

            # Action Buttons Row
            btn_row = tk.Frame(main_frame, bg="#f8fafc")
            btn_row.pack(fill="x")

            def on_request_time():
                root.destroy()
                self.action_request_extra_time()

            def on_report():
                root.destroy()
                self.action_report_false_positive()

            tk.Button(btn_row, text="Đóng", bg="#f1f5f9", fg="#334155", font=("Segoe UI", 9), padx=14, pady=5, command=root.destroy).pack(side="right")
            tk.Button(btn_row, text="⏱️ Xin thêm giờ", bg="#10b981", fg="#ffffff", font=("Segoe UI", 9, "bold"), padx=12, pady=5, command=on_request_time).pack(side="right", padx=6)
            tk.Button(btn_row, text="🌐 Báo chặn nhầm", bg="#0284c7", fg="#ffffff", font=("Segoe UI", 9), padx=10, pady=5, command=on_report).pack(side="right")

            root.mainloop()

        threading.Thread(target=_gui, daemon=True).start()

    def update_tooltip_loop(self):
        """Periodic background loop to update tray title and check for block notifications."""
        last_popup_ts = time.time()
        while self.running:
            try:
                st = self.get_status()
                if st:
                    quota_mins = st.get("quota_seconds", 90 * 60) // 60
                    rem_mins = st.get("remaining_seconds", 0) // 60
                    curr_app = st.get("current_app") or "Desktop"
                    is_idle = st.get("is_idle", False)
                    idle_tag = " [Nghỉ]" if is_idle else ""
                    self.last_status = st
                    if self.icon:
                        # Display BOTH Quota provided and Remaining time!
                        self.icon.title = f"OGK 2.0 | Còn: {rem_mins}p / Cấp: {quota_mins}p | {curr_app}{idle_tag}"

                # Check for new notification from service (blocks, warnings, locks, parent commands, rewards)
                noti = self._ipc_get("/last-blocked")
                if noti and noti.get("ts", 0) > last_popup_ts:
                    last_popup_ts = noti["ts"]
                    self.show_notification_dialog(noti)

            except Exception:
                pass
            time.sleep(1.0)


    def _menu_text_time(self, item=None) -> str:
        st = self.last_status or self.get_status()
        quota = st.get("quota_seconds", 90 * 60) // 60
        rem = st.get("remaining_seconds", 0) // 60
        return f"⏱️ Còn lại: {rem}p  |  Cấp: {quota}p"

    def _menu_text_app(self, item=None) -> str:
        st = self.last_status or self.get_status()
        app = st.get("current_app") or "Desktop"
        return f"💻 Đang mở: {app}"

    def _menu_text_state(self, item=None) -> str:
        st = self.last_status or self.get_status()
        if st.get("is_idle"):
            return "⏸️ Trạng thái: Đang nghỉ (Dừng đếm)"
        return "🟢 Trạng thái: Đang hoạt động"

    def run(self):
        """Start the system tray icon.
        NT1: If tray cannot run, the agent refuses to run silently (No stealth mode!).
        """
        self.running = True

        menu = pystray.Menu(
            pystray.MenuItem("🛡️ OGK 2.0 - Đồng hành minh bạch", lambda: None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(self._menu_text_time, lambda: None, enabled=False),
            pystray.MenuItem(self._menu_text_app, lambda: None, enabled=False),
            pystray.MenuItem(self._menu_text_state, lambda: None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("🌟 Hôm nay em đã dùng gì? (Minh bạch)", lambda: self.action_open_child_summary()),
            pystray.MenuItem("⏱️ Xin thêm giờ...", lambda: self.action_request_extra_time()),
            pystray.MenuItem("🌐 Con nghĩ trang này bị chặn nhầm...", lambda: self.action_report_false_positive()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("📞 Tổng đài Quốc gia 111 (Miễn cước)", lambda: import_webbrowser_open("https://tongdai111.vn")),
            pystray.MenuItem("Thoát", self.stop)
        )

        self.icon = pystray.Icon(
            "OGK2_Agent",
            create_tray_icon_image(),
            "OGK 2.0 (Bảo vệ con) — Đang hoạt động",
            menu
        )

        # Start background loop
        threading.Thread(target=self.update_tooltip_loop, daemon=True).start()

        # Startup notification
        threading.Thread(target=lambda: (time.sleep(1), self.show_startup_notification()), daemon=True).start()

        try:
            self.icon.run()
        except Exception as e:
            print(f"[!] System Tray UI cannot run: {e}")
            print("[!] NT1 Anti-abuse: Agent stops because Tray UI cannot be displayed silently!")
            sys.exit(1)

    def stop(self):
        self.running = False
        if self.icon:
            self.icon.stop()


def import_webbrowser_open(url: str):
    import webbrowser
    webbrowser.open(url)


if __name__ == "__main__":
    app = ChildTrayApp()
    app.run()
