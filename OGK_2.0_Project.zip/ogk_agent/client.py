"""HTTP and WebSocket client for OGK-Agent.
Handles enrollment, token renewal, HMAC policy verification, batch event sync, and urgent WebSocket commands.
"""

import asyncio
import json
import socket
import sys
import threading
import time
from typing import Callable, Dict, List, Optional
import httpx
import websockets

from ogk_shared.crypto import verify_policy_signature
from ogk_shared.schemas import PolicySchema
from ogk_agent.local_cache import (
    save_cached_policy, fetch_queued_events, remove_synced_events, wipe_local_cache
)


class OGKClient:
    def __init__(
        self,
        server_url: str = "http://127.0.0.1:8000",
        credentials: Optional[dict] = None,
        on_command_received: Optional[Callable[[str, dict], None]] = None,
        on_policy_updated: Optional[Callable[[dict], None]] = None
    ):
        self.server_url = server_url.rstrip("/")
        self.creds = credentials or {}
        self.on_command_received = on_command_received
        self.on_policy_updated = on_policy_updated

        self.ws_thread: Optional[threading.Thread] = None
        self.running = False

    @property
    def device_id(self) -> Optional[str]:
        return self.creds.get("device_id")

    @property
    def child_id(self) -> Optional[str]:
        return self.creds.get("child_id")

    @property
    def access_token(self) -> Optional[str]:
        return self.creds.get("access_token")

    @property
    def secret_key(self) -> Optional[str]:
        return self.creds.get("secret_key")

    def enroll(self, code: str) -> dict:
        """Enroll agent with 8-character parent code."""
        hostname = socket.gethostname()
        fingerprint = f"fp_{hostname}_{sys.platform}"
        payload = {
            "code": code.upper().strip(),
            "device_fingerprint": fingerprint,
            "hostname": hostname,
            "os_version": f"{sys.platform} x64"
        }

        with httpx.Client(timeout=10.0) as client:
            res = client.post(f"{self.server_url}/api/enroll/agent", json=payload)
            if res.status_code != 200:
                raise ValueError(res.json().get("detail", "Ghép đôi thất bại"))
            data = res.json()
            self.creds = {
                "server_url": self.server_url,
                "device_id": data["device_id"],
                "child_id": data["child_id"],
                "access_token": data["access_token"],
                "refresh_token": data["refresh_token"],
                "secret_key": data["secret_key"]
            }
            # Cache the received policy
            if "policy" in data:
                save_cached_policy(data["policy"])
            return self.creds

    def refresh_access_token(self) -> bool:
        """Exchange refresh token for new access token."""
        refresh_tok = self.creds.get("refresh_token")
        if not refresh_tok or not self.device_id:
            return False

        try:
            with httpx.Client(timeout=10.0) as client:
                res = client.post(f"{self.server_url}/api/enroll/refresh-token", json={
                    "device_id": self.device_id,
                    "refresh_token": refresh_tok
                })
                if res.status_code == 200:
                    data = res.json()
                    self.creds["access_token"] = data["access_token"]
                    return True
        except Exception:
            pass
        return False

    def fetch_policy(self) -> Optional[dict]:
        """Fetch latest policy from server and verify HMAC signature."""
        if not self.access_token or not self.secret_key:
            return None

        headers = {"X-OGK-Token": self.access_token}
        try:
            with httpx.Client(timeout=10.0) as client:
                res = client.get(f"{self.server_url}/api/policy/agent/me", headers=headers)
                if res.status_code == 401:
                    if self.refresh_access_token():
                        headers["X-OGK-Token"] = self.access_token
                        res = client.get(f"{self.server_url}/api/policy/agent/me", headers=headers)

                if res.status_code == 200:
                    policy_data = res.json()
                    sig = policy_data.get("signature")
                    # F4: Verify HMAC-SHA256 signature
                    if sig and verify_policy_signature(policy_data, sig, self.secret_key):
                        save_cached_policy(policy_data)
                        if self.on_policy_updated:
                            self.on_policy_updated(policy_data)
                        return policy_data
                    else:
                        print("[-] CẢNH BÁO: Chữ ký HMAC của chính sách không khớp! Từ chối chính sách sửa đổi.")
        except Exception as e:
            pass
        return None

    def sync_events(self) -> int:
        """Batch sync events from local offline SQLite queue with idempotency keys."""
        if not self.access_token:
            return 0

        queued = fetch_queued_events(limit=50)
        if not queued:
            return 0

        headers = {"X-OGK-Token": self.access_token}
        payload = {"events": queued}

        try:
            with httpx.Client(timeout=10.0) as client:
                res = client.post(f"{self.server_url}/api/events/batch", json=payload, headers=headers)
                if res.status_code == 401 and self.refresh_access_token():
                    headers["X-OGK-Token"] = self.access_token
                    res = client.post(f"{self.server_url}/api/events/batch", json=payload, headers=headers)

                if res.status_code == 200:
                    keys_to_remove = [item["idempotency_key"] for item in queued if item.get("idempotency_key")]
                    remove_synced_events(keys_to_remove)
                    return len(keys_to_remove)
        except Exception:
            pass
        return 0

    def send_heartbeat(
        self,
        status: str,
        used_seconds: int,
        policy_version: int,
        current_app: Optional[str] = None,
        window_title: Optional[str] = None,
        idle_seconds: float = 0.0,
        is_idle: bool = False,
        recent_domains: Optional[list] = None,
        remaining_seconds: Optional[int] = None,
        quota_seconds: Optional[int] = None,
        all_apps_today: Optional[list] = None
    ) -> Optional[dict]:
        """Fast periodic telemetry & fallback heartbeat (every 3s-15s)."""
        if not self.access_token or not self.device_id:
            return None

        headers = {"X-OGK-Token": self.access_token}
        payload = {
            "device_id": self.device_id,
            "child_id": self.child_id or "",
            "status": status,
            "quota_used_seconds": used_seconds,
            "policy_version": policy_version,
            "screen_locked": False,
            "idle_seconds": float(idle_seconds),
            "is_idle": bool(is_idle),
            "current_app": current_app,
            "window_title": window_title,
            "recent_domains": recent_domains or [],
            "remaining_seconds": remaining_seconds,
            "quota_seconds": quota_seconds,
            "all_apps_today": all_apps_today or []
        }

        try:
            with httpx.Client(timeout=8.0) as client:
                res = client.post(f"{self.server_url}/api/agent/heartbeat", json=payload, headers=headers)
                if res.status_code == 401 and self.refresh_access_token():
                    headers["X-OGK-Token"] = self.access_token
                    res = client.post(f"{self.server_url}/api/agent/heartbeat", json=payload, headers=headers)

                if res.status_code == 200:
                    data = res.json()
                    # Execute any pending commands received via heartbeat
                    for cmd in data.get("pending_commands", []):
                        action = cmd.get("action")
                        cmd_payload = cmd.get("payload", {})
                        if self.on_command_received and action:
                            self.on_command_received(action, cmd_payload)

                    # If server has newer policy version, fetch it
                    if data.get("latest_policy_version", 0) > policy_version:
                        self.fetch_policy()
                    return data
        except Exception:
            pass
        return None

    def submit_child_request(self, request_type: str, subject: str, reason: str) -> dict:
        """Submit child request: 'Xin thêm giờ' or 'Báo chặn nhầm'."""
        if not self.access_token:
            return {"status": "error", "message": "Chưa kết nối máy chủ"}

        headers = {"X-OGK-Token": self.access_token}
        payload = {
            "request_type": request_type,
            "subject": subject,
            "reason": reason
        }

        try:
            with httpx.Client(timeout=8.0) as client:
                res = client.post(f"{self.server_url}/api/requests/create", json=payload, headers=headers)
                if res.status_code == 200:
                    return {"status": "success", "message": "Đã gửi yêu cầu tới cha mẹ."}
                return {"status": "error", "message": res.json().get("detail", "Lỗi gửi yêu cầu")}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def start_websocket_listener(self):
        """Start background thread with asyncio loop for instant push WebSocket commands (< 5s)."""
        self.running = True
        self.ws_thread = threading.Thread(target=self._ws_worker, daemon=True)
        self.ws_thread.start()

    def _ws_worker(self):
        asyncio.run(self._ws_loop())

    async def _ws_loop(self):
        ws_base = self.server_url.replace("http://", "ws://").replace("https://", "wss://")
        while self.running:
            if not self.device_id or not self.access_token:
                await asyncio.sleep(2)
                continue

            ws_url = f"{ws_base}/ws/agent/{self.device_id}?token={self.access_token}"
            try:
                async with websockets.connect(ws_url, ping_interval=30, ping_timeout=10) as ws:
                    print(f"[+] WebSocket đã kết nối máy chủ! Sẵn sàng nhận lệnh khẩn cấp < 5 giây.")
                    while self.running:
                        msg = await ws.recv()
                        try:
                            cmd_data = json.loads(msg)
                            action = cmd_data.get("action")
                            payload = cmd_data.get("payload", {})
                            print(f"[⚡ WebSocket Live] Nhận lệnh từ phụ huynh: {action} ({payload})")
                            if action == "refresh_policy":
                                self.fetch_policy()
                            elif action == "wipe_cache":
                                wipe_local_cache()
                            elif self.on_command_received and action:
                                self.on_command_received(action, payload)
                        except Exception as e:
                            print(f"[-] Lỗi xử lý lệnh: {e}")
            except Exception as e:
                await asyncio.sleep(5)  # Retry connection in 5s

