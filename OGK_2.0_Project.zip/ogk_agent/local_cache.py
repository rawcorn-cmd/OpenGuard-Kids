"""Local SQLite caching and offline synchronization queue.
Handles offline resilience, idempotency keys, and cache wiping.
"""

import json
import os
import sqlite3
import time
import uuid
from typing import Dict, List, Optional
from ogk_agent.config import LOCAL_DB_PATH
from ogk_shared.schemas import PolicySchema


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(LOCAL_DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_local_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Events queue for offline sync
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS events_queue (
            idempotency_key TEXT PRIMARY KEY,
            ts REAL NOT NULL,
            device_id TEXT NOT NULL,
            child_id TEXT NOT NULL,
            type TEXT NOT NULL,
            subject TEXT NOT NULL,
            duration_sec INTEGER NOT NULL,
            policy_id TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    """)

    # Policy cache
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS policy_cache (
            id INTEGER PRIMARY KEY,
            policy_json TEXT NOT NULL,
            version INTEGER NOT NULL,
            signature TEXT,
            updated_at REAL NOT NULL
        )
    """)

    # Daily usage tracking (resistant to reboots and crashes)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS daily_usage (
            date_str TEXT PRIMARY KEY,
            used_seconds INTEGER NOT NULL,
            gaming_seconds INTEGER NOT NULL,
            last_monotonic REAL NOT NULL,
            last_wall_ts REAL NOT NULL
        )
    """)

    # Per-application daily accumulated usage tracking
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS app_daily_usage (
            date_str TEXT NOT NULL,
            app_name TEXT NOT NULL,
            window_title TEXT,
            duration_sec INTEGER NOT NULL,
            last_active_ts REAL NOT NULL,
            PRIMARY KEY (date_str, app_name)
        )
    """)

    conn.commit()
    conn.close()


def save_cached_policy(policy_dict: dict):
    conn = get_connection()
    cursor = conn.cursor()
    version = policy_dict.get("version", 1)
    sig = policy_dict.get("signature")
    cursor.execute("DELETE FROM policy_cache")
    cursor.execute(
        "INSERT INTO policy_cache (id, policy_json, version, signature, updated_at) VALUES (1, ?, ?, ?, ?)",
        (json.dumps(policy_dict), version, sig, time.time())
    )
    conn.commit()
    conn.close()


def load_cached_policy() -> Optional[dict]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT policy_json FROM policy_cache WHERE id = 1")
    row = cursor.fetchone()
    conn.close()
    if row:
        return json.loads(row[0])
    return None


def queue_event(
    device_id: str,
    child_id: str,
    event_type: str,
    subject: str,
    duration_sec: int,
    policy_id: str,
    ts: Optional[float] = None
) -> str:
    """Queue an event for synchronization with unique idempotency key."""
    conn = get_connection()
    cursor = conn.cursor()
    idempotency_key = str(uuid.uuid4())
    event_ts = ts or time.time()

    cursor.execute("""
        INSERT INTO events_queue (idempotency_key, ts, device_id, child_id, type, subject, duration_sec, policy_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (idempotency_key, event_ts, device_id, child_id, event_type, subject, duration_sec, policy_id, time.time()))

    conn.commit()
    conn.close()
    return idempotency_key


def fetch_queued_events(limit: int = 50) -> List[dict]:
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events_queue ORDER BY ts ASC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()

    events = []
    for r in rows:
        events.append({
            "idempotency_key": r["idempotency_key"],
            "ts": r["ts"],
            "device_id": r["device_id"],
            "child_id": r["child_id"],
            "type": r["type"],
            "subject": r["subject"],
            "duration_sec": r["duration_sec"],
            "policy_id": r["policy_id"]
        })
    return events


def remove_synced_events(idempotency_keys: List[str]):
    if not idempotency_keys:
        return
    conn = get_connection()
    cursor = conn.cursor()
    placeholders = ",".join("?" for _ in idempotency_keys)
    cursor.execute(f"DELETE FROM events_queue WHERE idempotency_key IN ({placeholders})", idempotency_keys)
    conn.commit()
    conn.close()


def record_time_tick(seconds: int, date_str: str, is_gaming: bool = False):
    """Add seconds to today's screen time usage in SQLite."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT used_seconds, gaming_seconds FROM daily_usage WHERE date_str = ?", (date_str,))
    row = cursor.fetchone()

    now_mono = time.monotonic()
    now_wall = time.time()

    if row:
        new_used = row[0] + seconds
        new_gaming = row[1] + (seconds if is_gaming else 0)
        cursor.execute("""
            UPDATE daily_usage
            SET used_seconds = ?, gaming_seconds = ?, last_monotonic = ?, last_wall_ts = ?
            WHERE date_str = ?
        """, (new_used, new_gaming, now_mono, now_wall, date_str))
    else:
        cursor.execute("""
            INSERT INTO daily_usage (date_str, used_seconds, gaming_seconds, last_monotonic, last_wall_ts)
            VALUES (?, ?, ?, ?, ?)
        """, (date_str, seconds, (seconds if is_gaming else 0), now_mono, now_wall))

    conn.commit()
    conn.close()


def get_daily_usage(date_str: str) -> dict:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT used_seconds, gaming_seconds, last_wall_ts FROM daily_usage WHERE date_str = ?", (date_str,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"used_seconds": row[0], "gaming_seconds": row[1], "last_wall_ts": row[2]}
    return {"used_seconds": 0, "gaming_seconds": 0, "last_wall_ts": 0}


def record_app_tick(seconds: int, app_name: str, window_title: str, date_str: str):
    """Accumulate usage seconds for specific application today in SQLite."""
    if not app_name:
        return
    conn = get_connection()
    cursor = conn.cursor()
    now_ts = time.time()
    clean_app = app_name.lower().strip()
    clean_title = (window_title or "").strip()[:200]

    cursor.execute("""
        INSERT INTO app_daily_usage (date_str, app_name, window_title, duration_sec, last_active_ts)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(date_str, app_name) DO UPDATE SET
            duration_sec = duration_sec + excluded.duration_sec,
            window_title = CASE WHEN excluded.window_title != '' THEN excluded.window_title ELSE window_title END,
            last_active_ts = excluded.last_active_ts
    """, (date_str, clean_app, clean_title, seconds, now_ts))

    conn.commit()
    conn.close()


def get_all_apps_usage_today(date_str: str) -> List[dict]:
    """Retrieve all applications that ran today with accumulated seconds."""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT app_name, window_title, duration_sec, last_active_ts
        FROM app_daily_usage
        WHERE date_str = ?
        ORDER BY duration_sec DESC
    """, (date_str,))
    rows = cursor.fetchall()
    conn.close()

    results = []
    for r in rows:
        results.append({
            "name": r["app_name"],
            "title": r["window_title"] or "",
            "duration_seconds": r["duration_sec"],
            "duration_minutes": round(r["duration_sec"] / 60.0, 1),
            "last_active": r["last_active_ts"]
        })
    return results


def wipe_local_cache():
    """F3: Wipe all queued events and cached tracking data when parent requests full data wipe."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM events_queue")
    cursor.execute("DELETE FROM daily_usage")
    cursor.execute("DELETE FROM app_daily_usage")
    conn.commit()
    conn.close()
