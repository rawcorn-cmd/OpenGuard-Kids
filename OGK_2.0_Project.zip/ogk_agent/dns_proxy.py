"""Local DNS Proxy on 127.0.0.1:53 with Windows Network Adapter Integration.
Implements F2:
- Intercepts DNS queries locally using dnslib
- Filters by domain and all subdomains (wildcard suffix matching)
- Enforces permanent educational & emergency whitelist (NT6)
- Evaluates 6-category classification (>= 200 items in dataset)
- SafeSearch DNS enforcement (Google, Bing, DuckDuckGo, YouTube)
- Explains blocks transparently (NT4)
- Live query buffer for real-time dashboard monitoring
- Automatic Windows Adapter DNS redirection (netsh)
"""

import collections
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
from typing import Callable, Dict, List, Optional
from dnslib import DNSRecord, RR, QTYPE, A, CNAME, RCODE

from ogk_shared.constants import (
    Category, EventType, PERMANENT_WHITELIST_DOMAINS,
    PERMANENT_WHITELIST_SUFFIXES, SAFESEARCH_TARGETS
)
from ogk_agent.local_cache import queue_event

# Canary domain (RFC standard) & known DoH bootstrap endpoints
# Returning NXDOMAIN causes browsers to disable DoH and fall back to local system DNS automatically!
DOH_CANARY_AND_BOOTSTRAP_DOMAINS = [
    # 1. Official RFC Canary domains (Mozilla Firefox & Chromium: Chrome, Edge, Brave, Opera, Vivaldi, Cốc Cốc)
    "use-application-dns.net",      # Mozilla / Chromium Canary domain (disables DoH automatically)

    # 2. Cloudflare DoH endpoints
    "cloudflare-dns.com",
    "chrome.cloudflare-dns.com",
    "1dot1dot1dot1.cloudflare-dns.com",
    "one.one.one.one",
    "security.cloudflare-dns.com",
    "family.cloudflare-dns.com",

    # 3. Google Public DNS DoH
    "dns.google",
    "dns.google.com",
    "dns64.dns.google",

    # 4. Quad9 DoH
    "dns.quad9.net",
    "dns9.quad9.net",
    "dns10.quad9.net",
    "dns11.quad9.net",

    # 5. OpenDNS / Cisco Umbrella
    "doh.opendns.com",
    "doh.familyshield.opendns.com",

    # 6. CleanBrowsing
    "doh.cleanbrowsing.org",

    # 7. AdGuard DNS
    "dns.adguard-dns.com",
    "dns-unfiltered.adguard.com",

    # 8. NextDNS & Control D & Mullvad
    "dns.nextdns.io",
    "dns.controld.com",
    "doh.mullvad.net",
    "dns.mullvad.net",

    # 9. Apple & Asian public DoH
    "doh.dns.apple.com",
    "dns.alidns.com",
    "doh.pub"
]


def match_domain_or_subdomain(query_domain: str, target_domain: str) -> bool:
    q = query_domain.strip().rstrip(".").lower()
    t = target_domain.strip().rstrip(".").lower()
    return q == t or q.endswith("." + t)


def get_active_windows_network_interfaces() -> List[str]:
    """Find active Windows network adapter names (Wi-Fi, Ethernet)."""
    if sys.platform != "win32":
        return []
    adapters = []
    try:
        output = subprocess.check_output(
            ["netsh", "interface", "ipv4", "show", "interfaces"],
            text=True, stderr=subprocess.DEVNULL
        )
        for line in output.splitlines():
            line = line.strip()
            if "connected" in line.lower():
                parts = re.split(r"\s{2,}", line)
                if len(parts) >= 4:
                    adapters.append(parts[3])
    except Exception:
        pass
    if not adapters:
        adapters = ["Wi-Fi", "Ethernet"]
    return adapters


def sync_windows_hosts_file(blocked_domains: List[str]) -> bool:
    """Sync blocked domains with Windows hosts file for zero-bypass browser blocking.
    Requires Administrator privileges on Windows. Fails gracefully if non-admin.
    """
    if sys.platform != "win32":
        return False
    hosts_path = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32", "drivers", "etc", "hosts")
    if not os.path.exists(hosts_path):
        return False

    header = "# === BEGIN OGK 2.0 BLOCKED DOMAINS (AUTO-MANAGED) ===\n"
    footer = "# === END OGK 2.0 BLOCKED DOMAINS ===\n"

    try:
        with open(hosts_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        # Remove existing OGK block if present
        pattern = re.compile(rf"{re.escape(header)}.*?{re.escape(footer)}", re.DOTALL)
        clean_content = re.sub(pattern, "", content).rstrip() + "\n"

        if blocked_domains:
            ogk_lines = [header]
            ogk_lines.append("# Anti-DoH Endpoints (Force Chrome/Edge/Firefox to use system DNS)\n")
            for doh in DOH_CANARY_AND_BOOTSTRAP_DOMAINS:
                ogk_lines.append(f"0.0.0.0 {doh}\n")
            ogk_lines.append("# Blocked Domain Targets\n")
            for d in sorted(set(blocked_domains)):
                d_clean = d.strip().lower().rstrip(".")
                if d_clean:
                    ogk_lines.append(f"127.0.0.1 {d_clean}\n")
                    if not d_clean.startswith("www."):
                        ogk_lines.append(f"127.0.0.1 www.{d_clean}\n")
            ogk_lines.append(footer)
            new_content = clean_content + "\n" + "".join(ogk_lines)
        else:
            new_content = clean_content

        with open(hosts_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        # Flush Windows DNS Cache
        try:
            subprocess.run("ipconfig /flushdns", shell=True, capture_output=True)
        except Exception:
            pass
        return True
    except (PermissionError, OSError):
        # Non-admin or sandbox - safely ignore, DNS proxy handles UDP port 53
        return False


def set_windows_dns_to_localhost(enable: bool = True) -> bool:
    """Redirect Windows DNS to 127.0.0.1 so real browser queries route through the proxy."""
    if sys.platform != "win32":
        return False
    adapters = get_active_windows_network_interfaces()
    success = False
    for iface in adapters:
        try:
            if enable:
                # Set static 127.0.0.1 (No external secondary DNS to prevent parallel bypass!)
                cmd = f'netsh interface ipv4 set dns name="{iface}" static 127.0.0.1'
                res1 = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                if res1.returncode == 0:
                    success = True
                    print(f"[DNS Adapter] Đã cấu hình DNS 127.0.0.1 cho adapter '{iface}'")
            else:
                cmd = f'netsh interface ipv4 set dns name="{iface}" dhcp'
                res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                if res.returncode == 0:
                    success = True
                    print(f"[DNS Adapter] Đã khôi phục DNS DHCP cho adapter '{iface}'")
        except Exception as e:
            pass
    # Flush Windows DNS Cache
    try:
        subprocess.run("ipconfig /flushdns", shell=True, capture_output=True)
    except Exception:
        pass
    return success


def configure_browser_policies(disable_doh: bool = True) -> bool:
    """Enforce Chrome & Edge enterprise policy to disable DoH so they automatically use local DNS.
    Works for HKCU (no admin required) and HKLM (if admin).
    """
    if sys.platform != "win32":
        return False
    try:
        import winreg
        targets = [
            (winreg.HKEY_CURRENT_USER, r"Software\Policies\Google\Chrome"),
            (winreg.HKEY_CURRENT_USER, r"Software\Policies\Microsoft\Edge"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Policies\Google\Chrome"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Policies\Microsoft\Edge"),
        ]
        for root_key, subkey_path in targets:
            try:
                if disable_doh:
                    key = winreg.CreateKeyEx(root_key, subkey_path, 0, winreg.KEY_SET_VALUE)
                    winreg.SetValueEx(key, "DnsOverHttpsMode", 0, winreg.REG_SZ, "off")
                    winreg.CloseKey(key)
                else:
                    try:
                        key = winreg.OpenKey(root_key, subkey_path, 0, winreg.KEY_SET_VALUE)
                        winreg.DeleteValue(key, "DnsOverHttpsMode")
                        winreg.CloseKey(key)
                    except FileNotFoundError:
                        pass
            except (PermissionError, OSError):
                pass
        return True
    except Exception:
        return False


class DNSFilterProxy:
    def __init__(
        self,
        device_id: str,
        child_id: str,
        host: str = "127.0.0.1",
        port: int = 53,
        upstream_dns: str = "1.1.1.1",
        upstream_port: int = 53,
        dataset_path: Optional[str] = None,
        on_domain_blocked: Optional[Callable[[str, str, str], None]] = None,
        auto_redirect_adapter: bool = False
    ):
        self.device_id = device_id
        self.child_id = child_id
        self.host = host
        self.port = port
        self.upstream_dns = upstream_dns
        self.upstream_port = upstream_port
        self.on_domain_blocked = on_domain_blocked
        self.auto_redirect_adapter = auto_redirect_adapter

        self.policy: Optional[dict] = None
        self.server_socket: Optional[socket.socket] = None
        self.running = False
        self.thread: Optional[threading.Thread] = None

        # Domain classification index: domain -> category
        self.domain_categories: Dict[str, str] = {}
        self.load_dataset(dataset_path)

        # In-memory DNS cache: (qname, qtype) -> (timestamp, response_bytes)
        self.dns_cache: Dict[tuple, tuple] = {}

        # Recent query buffer for live dashboard monitoring (stores last 50 queries)
        self.recent_queries = collections.deque(maxlen=50)

    def load_dataset(self, dataset_path: Optional[str]):
        if not dataset_path:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            dataset_path = os.path.join(base_dir, "test_dataset.json")

        if os.path.exists(dataset_path):
            try:
                with open(dataset_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data.get("domains", []):
                        d = item.get("domain", "").strip().lower()
                        c = item.get("category", Category.UNCATEGORIZED.value)
                        if d:
                            self.domain_categories[d] = c
            except Exception as e:
                print(f"[DNS] Error loading dataset: {e}")

    def sync_hosts(self):
        """Sync current policy blocked domains to Windows hosts file."""
        try:
            blocked_domains = set()
            allowed_domains = set()

            if self.policy:
                for r in self.policy.get("domain_rules", []):
                    d = r.get("domain", "").strip().lower()
                    if d:
                        if r.get("action") == "block":
                            blocked_domains.add(d)
                        elif r.get("action") == "allow":
                            allowed_domains.add(d)

                blocked_cats = self.policy.get("blocked_categories", [])
                for dom, cat in self.domain_categories.items():
                    if cat in blocked_cats and not self.is_permanently_whitelisted(dom):
                        blocked_domains.add(dom.strip().lower())
            else:
                default_blocked = [Category.INAPPROPRIATE.value, Category.SOCIAL_MEDIA.value]
                for dom, cat in self.domain_categories.items():
                    if cat in default_blocked and not self.is_permanently_whitelisted(dom):
                        blocked_domains.add(dom.strip().lower())

            # Whitelisted domains must NEVER be blocked in hosts
            for allow in allowed_domains:
                blocked_domains.discard(allow)
            for white in PERMANENT_WHITELIST_DOMAINS:
                blocked_domains.discard(white.strip().lower())

            sync_windows_hosts_file(list(blocked_domains))
        except Exception:
            pass

    def update_policy(self, policy_dict: dict):
        self.policy = policy_dict
        self.sync_hosts()

    def is_permanently_whitelisted(self, domain: str) -> bool:
        d = domain.lower().rstrip(".")
        for white in PERMANENT_WHITELIST_DOMAINS:
            if match_domain_or_subdomain(d, white):
                return True
        for suffix in PERMANENT_WHITELIST_SUFFIXES:
            if d.endswith(suffix):
                return True
        return False

    def evaluate_domain(self, domain: str) -> Dict:
        d = domain.lower().rstrip(".")

        # 1. NT6: Permanent Emergency & School Whitelist (NEVER BLOCKED)
        if self.is_permanently_whitelisted(d):
            return {
                "action": "allow",
                "reason": "Cổng thông tin giáo dục hoặc đường dây khẩn cấp được miễn chặn vĩnh viễn (NT6)",
                "category": Category.EDUCATION.value
            }

        # 1.5 DoH Canary & Bootstrap Endpoints -> return NXDOMAIN to force browser fallback to OS DNS
        for doh_d in DOH_CANARY_AND_BOOTSTRAP_DOMAINS:
            if match_domain_or_subdomain(d, doh_d):
                return {
                    "action": "nxdomain",
                    "reason": "Điều hướng DoH trình duyệt về DNS hệ thống để thực thi quy tắc gia đình",
                    "category": Category.UNCATEGORIZED.value
                }

        # 2. Check SafeSearch redirection
        safesearch_enabled = self.policy.get("safesearch_enforced", True) if self.policy else True
        if safesearch_enabled:
            for engine, config in SAFESEARCH_TARGETS.items():
                for target_d in config["domains"]:
                    if match_domain_or_subdomain(d, target_d):
                        return {
                            "action": "safesearch",
                            "engine": engine,
                            "cname": config["cname"],
                            "ip": config["ip"],
                            "reason": f"Cưỡng chế SafeSearch an toàn cho {engine}"
                        }

        # 3. Check explicit domain rules from policy
        if self.policy:
            domain_rules = self.policy.get("domain_rules", [])
            for r in domain_rules:
                target = r.get("domain", "").lower().rstrip(".")
                if match_domain_or_subdomain(d, target):
                    action = r.get("action", "block")
                    reason = r.get("reason") or ("Được cha mẹ cho phép" if action == "allow" else "Bị chặn theo quy định cha mẹ")
                    return {
                        "action": action,
                        "reason": reason,
                        "category": r.get("category", Category.UNCATEGORIZED.value)
                    }

        # 4. Check category from classification database
        category = Category.UNCATEGORIZED.value
        for db_domain, db_cat in self.domain_categories.items():
            if match_domain_or_subdomain(d, db_domain):
                category = db_cat
                break

        # Check if category is in blocked_categories
        blocked_cats = (
            self.policy.get("blocked_categories", [Category.INAPPROPRIATE.value, Category.SOCIAL_MEDIA.value])
            if self.policy else [Category.INAPPROPRIATE.value, Category.SOCIAL_MEDIA.value]
        )

        if category in blocked_cats:
            cat_label = {
                Category.INAPPROPRIATE.value: "Không phù hợp lứa tuổi",
                Category.SOCIAL_MEDIA.value: "Mạng xã hội",
                Category.GAMING.value: "Trò chơi trực tuyến"
            }.get(category, category)
            return {
                "action": "block",
                "reason": f"Danh mục '{cat_label}' bị hạn chế đối với lứa tuổi của con",
                "category": category
            }

        return {
            "action": "allow",
            "reason": "Trang web được phép truy cập",
            "category": category
        }

    def process_dns_query(self, data: bytes, client_addr: tuple) -> bytes:
        try:
            req = DNSRecord.parse(data)
            qname = str(req.q.qname).rstrip(".")
            qtype = req.q.qtype

            eval_res = self.evaluate_domain(qname)
            action = eval_res.get("action", "allow")
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            reason = eval_res.get("reason", "")
            category = eval_res.get("category", "")

            # Log to live query buffer for real-time dashboard
            self.recent_queries.appendleft({
                "domain": qname,
                "action": action,
                "reason": reason,
                "category": category,
                "ts": time.time(),
                "time_str": time.strftime("%H:%M:%S")
            })

            # NXDOMAIN for DoH Canary & Bootstrap Endpoints (Auto-fallback to OS DNS)
            if action == "nxdomain":
                resp = req.reply()
                resp.header.rcode = RCODE.NXDOMAIN
                return resp.pack()

            # SafeSearch Rewrite
            if action == "safesearch":
                resp = req.reply()
                target_ip = eval_res.get("ip", "216.239.38.120")
                if qtype == QTYPE.A:
                    resp.add_answer(RR(req.q.qname, QTYPE.A, rdata=A(target_ip), ttl=300))
                else:
                    target_cname = eval_res.get("cname", "forcesafesearch.google.com.")
                    resp.add_answer(RR(req.q.qname, QTYPE.CNAME, rdata=CNAME(target_cname), ttl=300))
                return resp.pack()

            # Blocked Domain
            if action == "block":
                # Record event
                queue_event(
                    self.device_id, self.child_id, EventType.BLOCKED_DOMAIN.value,
                    qname, 0, policy_id
                )

                # Pop up explanation dialog (NT4)
                if self.on_domain_blocked:
                    self.on_domain_blocked(qname, reason, "Cha mẹ của em")

                # Return Loopback IP (127.0.0.1) or NXDOMAIN so browser stops immediately
                resp = req.reply()
                if qtype == QTYPE.A:
                    resp.add_answer(RR(req.q.qname, QTYPE.A, rdata=A("127.0.0.1"), ttl=60))
                else:
                    resp.header.rcode = RCODE.NXDOMAIN
                return resp.pack()

            # Allowed Domain
            queue_event(
                self.device_id, self.child_id, EventType.DOMAIN_QUERY.value,
                qname, 0, policy_id
            )

            # Check local DNS cache
            cache_key = (qname, qtype)
            if cache_key in self.dns_cache:
                c_ts, c_resp = self.dns_cache[cache_key]
                if time.time() - c_ts < 300:
                    return c_resp

            # Forward to upstream DNS resolver
            try:
                forward_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                forward_sock.settimeout(2.0)
                forward_sock.sendto(data, (self.upstream_dns, self.upstream_port))
                upstream_data, _ = forward_sock.recvfrom(4096)
                forward_sock.close()
                self.dns_cache[cache_key] = (time.time(), upstream_data)
                return upstream_data
            except Exception:
                resp = req.reply()
                resp.header.rcode = RCODE.SERVFAIL
                return resp.pack()

        except Exception:
            return data

    def get_recent_queries_list(self) -> List[dict]:
        return list(self.recent_queries)

    def start(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.server_socket.bind((self.host, self.port))
            print(f"[+] DNS Proxy listening on {self.host}:{self.port}")
        except OSError as e:
            print(f"[DNS Proxy] Warning: Could not bind to {self.host}:{self.port} ({e}).")
            return

        self.running = True
        self.thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.thread.start()

        # Sync hosts and configure browser policies
        self.sync_hosts()
        configure_browser_policies(disable_doh=True)

        if self.auto_redirect_adapter:
            set_windows_dns_to_localhost(enable=True)

    def _listen_loop(self):
        while self.running and self.server_socket:
            try:
                data, addr = self.server_socket.recvfrom(4096)
                if not data:
                    continue
                resp_data = self.process_dns_query(data, addr)
                self.server_socket.sendto(resp_data, addr)
            except Exception:
                if not self.running:
                    break

    def stop(self):
        self.running = False
        try:
            sync_windows_hosts_file([])
        except Exception:
            pass
        configure_browser_policies(disable_doh=False)
        if self.auto_redirect_adapter:
            set_windows_dns_to_localhost(enable=False)
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
            self.server_socket = None
