"""OGK-Agent Service Runner.
Coordinates:
- Policy Enforcer
- Screen-time Counter
- App Controller (SHA-256 + process name)
- DNS Proxy (127.0.0.1:53)
- Local SQLite Cache (Offline resilience)
- IPC Server (127.0.0.1:51111)
- WebSocket & Heartbeat Client
"""

import json
import os
import sys
import threading
import time
from typing import Optional

from ogk_agent.config import (
    load_credentials, save_credentials, apply_directory_acl
)
from ogk_agent.local_cache import (
    init_local_db, load_cached_policy, save_cached_policy,
    get_daily_usage, wipe_local_cache, record_app_tick, get_all_apps_usage_today
)
from ogk_agent.screen_time import ScreenTimeManager
from ogk_agent.app_controller import AppController
from ogk_agent.dns_proxy import DNSFilterProxy
from ogk_agent.ipc_server import IPCServer
from ogk_agent.client import OGKClient


class OGKAgentService:
    def __init__(
        self,
        server_url: str = "http://127.0.0.1:8000",
        simulate_lock: bool = False,
        dns_port: int = 53
    ):
        self.server_url = server_url
        self.simulate_lock = simulate_lock
        self.dns_port = dns_port
        self.running = False

        # Load local storage & credentials
        init_local_db()
        apply_directory_acl()
        self.creds = load_credentials()

        self.device_id = self.creds.get("device_id", "unregistered_device")
        self.child_id = self.creds.get("child_id", "unregistered_child")

        # Initialize sub-components
        self.screen_time = ScreenTimeManager(
            device_id=self.device_id,
            child_id=self.child_id,
            on_warning=self._on_quota_warning,
            on_lock=self._on_workstation_locked,
            simulate_lock=self.simulate_lock
        )

        self.app_controller = AppController(
            device_id=self.device_id,
            child_id=self.child_id,
            on_app_blocked=self._on_app_blocked
        )

        self.dns_proxy = DNSFilterProxy(
            device_id=self.device_id,
            child_id=self.child_id,
            port=self.dns_port,
            on_domain_blocked=self._on_domain_blocked,
            auto_redirect_adapter=True
        )

        self.client = OGKClient(
            server_url=self.server_url,
            credentials=self.creds,
            on_command_received=self._on_urgent_command,
            on_policy_updated=self._on_policy_updated
        )

        self.ipc_server = IPCServer(
            status_provider=self._get_ipc_status,
            request_handler=self._handle_child_request
        )

        # Load cached policy from SQLite if exists
        cached = load_cached_policy()
        if cached:
            self._apply_policy(cached)

    def _apply_policy(self, policy_dict: dict):
        """Propagate updated policy to all enforcer components."""
        self.screen_time.update_policy(policy_dict)
        self.app_controller.update_policy(policy_dict)
        self.dns_proxy.update_policy(policy_dict)

    def _on_policy_updated(self, policy_dict: dict):
        print(f"[Policy Enforcer] Received and verified Policy v{policy_dict.get('version')}")
        self._apply_policy(policy_dict)

    def _on_quota_warning(self, remaining_minutes: int, message: str):
        print(f"[Warning] {message}")
        if self.ipc_server:
            self.ipc_server.trigger_blocked_popup({
                "type": "warning",
                "subject": f"Thời gian còn lại: {remaining_minutes} phút",
                "reason": message,
                "by": "Hệ thống bảo vệ OGK"
            })

    def _on_workstation_locked(self, reason: str):
        mode = "MÔ PHỎNG" if self.simulate_lock else "THẬT"
        print(f"[Locked - {mode}] Máy tính bị khóa: {reason}")
        if self.ipc_server:
            self.ipc_server.trigger_blocked_popup({
                "type": "lock",
                "subject": f"Máy tính bị khóa ({mode})",
                "reason": reason,
                "by": "Hệ thống bảo vệ OGK"
            })

    def _on_app_blocked(self, display_name: str, reason: str, rule_by: str):

        print(f"[Blocked App] Chặn ứng dụng: {display_name} — {reason}")
        if self.ipc_server:
            self.ipc_server.trigger_blocked_popup({
                "type": "app",
                "subject": display_name,
                "reason": reason,
                "by": rule_by
            })

    def _on_domain_blocked(self, domain: str, reason: str, rule_by: str):
        print(f"[Blocked Domain] Chặn trang web: {domain} — {reason}")
        if self.ipc_server:
            self.ipc_server.trigger_blocked_popup({
                "type": "domain",
                "subject": domain,
                "reason": reason,
                "by": rule_by
            })

    def _on_urgent_command(self, action: str, payload: dict):
        """Urgent command dispatcher (WebSocket push < 5 seconds)."""
        print(f"[Urgent Command Live] Action: {action}, Payload: {payload}")
        if action == "lock_now":
            if not self.simulate_lock:
                from ogk_agent.screen_time import lock_windows_workstation
                lock_windows_workstation()
            if self.ipc_server:
                self.ipc_server.trigger_blocked_popup({
                    "type": "command",
                    "subject": "Lệnh khóa máy từ cha mẹ",
                    "reason": "Cha mẹ đã gửi lệnh khóa máy ngay lập tức từ bảng điều khiển.",
                    "by": "Cha mẹ của em"
                })


        elif action == "unlock":
            # Clear lock and add override minutes
            self.screen_time.add_override_time(15)
            if self.ipc_server:
                self.ipc_server.trigger_blocked_popup({
                    "type": "command",
                    "subject": "Lệnh mở khóa máy",
                    "reason": "Cha mẹ đã gửi lệnh mở khóa máy tính cho em (+15 phút).",
                    "by": "Cha mẹ của em"
                })

        elif action == "add_time":
            mins = payload.get("minutes", 15)
            self.screen_time.add_override_time(mins)
            print(f"[+] Added {mins} override minutes to screen time.")
            if self.ipc_server:
                self.ipc_server.trigger_blocked_popup({
                    "type": "command",
                    "subject": f"Được cộng thêm {mins} phút!",
                    "reason": f"Cha mẹ đã cộng thêm {mins} phút sử dụng máy tính cho em.",
                    "by": "Cha mẹ của em"
                })

        elif action == "refresh_policy":
            unblocked_item = payload.get("unblocked", "")
            print(f"[Urgent Command Live] Nhận lệnh cập nhật chính sách tức thì. Đối tượng mở: {unblocked_item}")
            new_policy = self.client.fetch_policy()
            if new_policy:
                self._apply_policy(new_policy)
            if unblocked_item and self.ipc_server:
                self.ipc_server.trigger_blocked_popup({
                    "type": "reward",
                    "subject": f"Đã mở khóa: {unblocked_item}",
                    "reason": f"Cha mẹ đã phê duyệt mở khóa cho '{unblocked_item}'. Em có thể sử dụng bình thường!",
                    "by": "Cha mẹ của em"
                })

        elif action == "wipe_cache":
            wipe_local_cache()
            print("[+] Local cache wiped per parent request.")


    def _get_ipc_status(self) -> dict:
        today_str = time.strftime("%Y-%m-%d")
        usage = get_daily_usage(today_str)
        quota_sec = self.screen_time.get_effective_daily_quota_seconds()
        remaining_sec = max(0, quota_sec - usage["used_seconds"])
        fg_info = self.app_controller.get_current_foreground_info()
        apps_today = get_all_apps_usage_today(today_str)

        from ogk_agent.screen_time import get_idle_duration_seconds
        idle_s = round(get_idle_duration_seconds(), 1)

        return {
            "device_id": self.device_id,
            "child_id": self.child_id,
            "used_seconds": usage["used_seconds"],
            "quota_seconds": quota_sec,
            "remaining_seconds": remaining_sec,
            "gaming_seconds": usage["gaming_seconds"],
            "current_app": fg_info.get("name", ""),
            "window_title": fg_info.get("title", ""),
            "idle_seconds": idle_s,
            "is_idle": idle_s >= self.screen_time.idle_timeout_seconds,
            "all_apps_today": apps_today,
            "server_connected": bool(self.client.access_token)
        }

    def _handle_child_request(self, req_type: str, subject: str, reason: str) -> dict:
        return self.client.submit_child_request(req_type, subject, reason)

    def start(self):
        """Start all background subsystems and main monitoring loop."""
        self.running = True
        print("==================================================")
        print("  OGK 2.0 - Agent Service Running")
        print(f"  Device ID: {self.device_id}")
        print(f"  Server URL: {self.server_url}")
        print("==================================================")

        # 1. Start DNS Proxy
        self.dns_proxy.start()

        # 2. Start IPC Server
        self.ipc_server.start()

        # 3. Start WebSocket listener for instant commands (< 5s)
        self.client.start_websocket_listener()

        # 4. Fetch initial policy if online
        self.client.fetch_policy()

        # 5. Main enforcement loop (1-second tick)
        last_heartbeat_time = 0.0
        last_sync_time = 0.0

        try:
            while self.running:
                loop_start = time.monotonic()

                # If unregistered, check if credentials have been saved
                if self.device_id == "unregistered_device":
                    fresh_creds = load_credentials()
                    if fresh_creds and fresh_creds.get("device_id"):
                        self.creds = fresh_creds
                        self.device_id = fresh_creds["device_id"]
                        self.child_id = fresh_creds.get("child_id", "")
                        self.client.creds = fresh_creds
                        self.client.start_websocket_listener()
                        print(f"[+] Đã nạp thông tin ghép đôi thiết bị: {self.device_id} ({self.child_id})")

                # Screen time tick
                today_str = time.strftime("%Y-%m-%d")
                tick_res = self.screen_time.tick(delta_seconds=1.0)

                # App controller scan
                self.app_controller.scan_and_enforce(gaming_exceeded=tick_res["gaming_exceeded"])

                # If user is active, accumulate usage for active app today
                fg_info = self.app_controller.get_current_foreground_info()
                if tick_res["is_active"] and fg_info.get("name"):
                    record_app_tick(1, fg_info["name"], fg_info.get("title", ""), today_str)

                now = time.time()

                # Fast 3-second Heartbeat & Telemetry Streaming
                if now - last_heartbeat_time >= 3.0:
                    status_str = "locked" if (tick_res["is_locked"] or tick_res["schedule_locked"]) else ("idle" if tick_res["is_idle"] else "active")
                    pol_ver = self.screen_time.policy.get("version", 0) if self.screen_time.policy else 0
                    recent_dns = self.dns_proxy.get_recent_queries_list()[:10]
                    apps_today = get_all_apps_usage_today(today_str)

                    self.client.send_heartbeat(
                        status=status_str,
                        used_seconds=tick_res["used_seconds"],
                        policy_version=pol_ver,
                        current_app=fg_info.get("name"),
                        window_title=fg_info.get("title"),
                        idle_seconds=tick_res.get("idle_seconds", 0.0),
                        is_idle=tick_res.get("is_idle", False),
                        recent_domains=recent_dns,
                        remaining_seconds=tick_res.get("remaining_seconds"),
                        quota_seconds=tick_res.get("quota_seconds"),
                        all_apps_today=apps_today
                    )
                    last_heartbeat_time = now

                # Batch sync queued events every 5 seconds
                if now - last_sync_time >= 5.0:
                    self.client.sync_events()
                    last_sync_time = now

                # Maintain 1-second cadence
                elapsed = time.monotonic() - loop_start
                sleep_time = max(0.05, 1.0 - elapsed)
                time.sleep(sleep_time)

        except KeyboardInterrupt:
            print("\n[*] Stopping OGK Agent Service...")
        finally:
            self.stop()

    def stop(self):
        self.running = False
        self.dns_proxy.stop()
        self.ipc_server.stop()
        self.client.running = False


# Optional Windows Service Integration with pywin32
try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager

    class OGKWindowsService(win32serviceutil.ServiceFramework):
        _svc_name_ = "OGKAgentService"
        _svc_display_name_ = "OGK 2.0 Child Protection Agent Service"
        _svc_description_ = "Open Guardian for Kids - Windows Service Enforcer (LocalSystem)"

        def __init__(self, args):
            super().__init__(args)
            self.stop_event = win32event.CreateEvent(None, 0, 0, None)
            self.agent = None

        def SvcStop(self):
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self.stop_event)
            if self.agent:
                self.agent.stop()

        def SvcDoRun(self):
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, "")
            )
            self.agent = OGKAgentService()
            self.agent.start()

except ImportError:
    OGKWindowsService = None


if __name__ == "__main__":
    agent = OGKAgentService()
    agent.start()
