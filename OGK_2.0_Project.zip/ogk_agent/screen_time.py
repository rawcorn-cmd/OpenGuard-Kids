"""Screen-time counter and policy enforcement engine.
Implements F1:
- Daily quota (weekday vs weekend, e.g. 90m vs 120m or 3 min test)
- 7x48 weekly schedule matrix (30-min resolution, lock within 5s)
- Actual usage tracking (pause if idle > 5 min or session locked)
- 10, 5, 1 minute warnings and 60-second grace period
- Anti-clock-tampering with monotonic clock
- App group budgets (e.g., Gaming 45m, Education unlimited)
"""

import ctypes
import datetime
import os
import sys
import time
from typing import Callable, Dict, List, Optional
from ogk_shared.constants import Category, EventType
from ogk_agent.local_cache import record_time_tick, get_daily_usage, queue_event


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_uint),
        ("dwTime", ctypes.c_ulong)
    ]


def get_idle_duration_seconds() -> float:
    """Get system idle time in seconds using Windows GetLastInputInfo."""
    if sys.platform != "win32":
        return 0.0
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        lii = LASTINPUTINFO()
        lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
        if user32.GetLastInputInfo(ctypes.byref(lii)):
            millis = kernel32.GetTickCount() - lii.dwTime
            return max(0.0, millis / 1000.0)
    except Exception:
        pass
    return 0.0


def is_workstation_locked() -> bool:
    """Check if Windows desktop / session is currently locked."""
    if sys.platform != "win32":
        return False
    try:
        user32 = ctypes.windll.user32
        # OpenInputDesktop fails with ERROR_ACCESS_DENIED if workstation is locked
        h_desktop = user32.OpenInputDesktop(0, False, 0x0001)  # DESKTOP_READOBJECTS
        if h_desktop == 0:
            return True
        user32.CloseDesktop(h_desktop)
        return False
    except Exception:
        return False


def lock_windows_workstation() -> bool:
    """Execute Windows LockWorkStation API (Win + L equivalent)."""
    if sys.platform == "win32":
        try:
            return bool(ctypes.windll.user32.LockWorkStation())
        except Exception:
            return False
    return True


class ScreenTimeManager:
    def __init__(
        self,
        device_id: str,
        child_id: str,
        on_warning: Optional[Callable[[int, str], None]] = None,
        on_lock: Optional[Callable[[str], None]] = None,
        simulate_lock: bool = False,
        idle_timeout_seconds: Optional[float] = None
    ):
        self.device_id = device_id
        self.child_id = child_id
        self.on_warning = on_warning
        self.on_lock = on_lock
        self.simulate_lock = simulate_lock

        # Configurable idle timeout (default 300s, or OGK_IDLE_TIMEOUT_SECONDS for testing)
        if idle_timeout_seconds is not None:
            self.idle_timeout_seconds = float(idle_timeout_seconds)
        else:
            self.idle_timeout_seconds = float(os.getenv("OGK_IDLE_TIMEOUT_SECONDS", "300.0"))

        # Internal state
        self.policy: Optional[dict] = None
        self.last_tick_monotonic = time.monotonic()
        self.last_tick_wall = time.time()
        self.current_app: Optional[str] = None
        self.is_gaming_active = False

        # Warnings sent tracking
        self.warning_sent_10 = False
        self.warning_sent_5 = False
        self.warning_sent_1 = False
        self.in_grace_period = False
        self.grace_period_start = 0.0

        # Clock tampering detection
        self.clock_tampered = False

        # Extra temporary minutes granted by parent
        self.override_seconds = 0

    def update_policy(self, policy_dict: dict):
        self.policy = policy_dict

    def add_override_time(self, minutes: int):
        self.override_seconds += minutes * 60
        # Reset warnings when time is granted
        self.warning_sent_1 = False
        self.warning_sent_5 = False
        self.warning_sent_10 = False
        self.in_grace_period = False

    def is_outside_schedule(self) -> bool:
        """Check if current time is outside allowed schedule (7x48 matrix)."""
        if not self.policy or "schedule" not in self.policy:
            return False
        matrix = self.policy["schedule"].get("matrix", [])
        if len(matrix) != 7:
            return False

        now = datetime.datetime.now()
        day_idx = now.weekday()  # 0 = Monday, ..., 6 = Sunday
        slot_idx = now.hour * 2 + (1 if now.minute >= 30 else 0)

        if 0 <= day_idx < 7 and 0 <= slot_idx < 48:
            slot_val = matrix[day_idx][slot_idx]
            return slot_val == 0
        return False

    def get_effective_daily_quota_seconds(self) -> int:
        if not self.policy:
            return 90 * 60
        now = datetime.datetime.now()
        is_weekend = now.weekday() in (5, 6)
        base_mins = (
            self.policy.get("daily_quota_minutes_weekend", 120)
            if is_weekend else
            self.policy.get("daily_quota_minutes_weekday", 90)
        )
        return (base_mins * 60) + self.override_seconds

    def get_remaining_seconds(self) -> int:
        today_str = datetime.date.today().isoformat()
        usage = get_daily_usage(today_str)
        used_sec = usage["used_seconds"]
        quota_sec = self.get_effective_daily_quota_seconds()
        return max(0, quota_sec - used_sec)

    def tick(self, delta_seconds: float = 1.0) -> Dict:
        """Called once per second (or interval) by the daemon loop.
        Accurately accumulates usage, detects idle/lock, enforces quotas & schedule.
        """
        now_mono = time.monotonic()
        now_wall = time.time()
        today_str = datetime.date.today().isoformat()

        # F1: Anti-clock-tampering verification
        # If wall clock moved backward significantly (> 10s), detect tampering
        if (now_wall - self.last_tick_wall) < -10.0:
            self.clock_tampered = True
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            queue_event(
                self.device_id, self.child_id, EventType.QUOTA_WARNING.value,
                "Phát hiện chỉnh lùi đồng hồ hệ thống", 0, policy_id
            )

        self.last_tick_wall = now_wall
        self.last_tick_monotonic = now_mono

        # Check idle and locked status
        idle_sec = get_idle_duration_seconds()
        is_locked = is_workstation_locked()

        # Condition: do not count if idle >= threshold (default 300s) or workstation locked
        is_idle = (idle_sec >= self.idle_timeout_seconds)
        is_active = (not is_idle) and not is_locked

        if is_active:
            record_time_tick(int(delta_seconds), today_str, is_gaming=self.is_gaming_active)

        # Get updated usage
        usage = get_daily_usage(today_str)
        used_seconds = usage["used_seconds"]
        gaming_seconds = usage["gaming_seconds"]
        quota_seconds = self.get_effective_daily_quota_seconds()
        remaining_seconds = max(0, quota_seconds - used_seconds)
        remaining_minutes = remaining_seconds // 60

        # Check schedule restriction (within 5 seconds lock)
        schedule_locked = self.is_outside_schedule()

        # Check gaming budget
        gaming_budget_mins = (
            self.policy.get("app_group_budgets", {}).get(Category.GAMING.value, 45)
            if self.policy else 45
        )
        gaming_exceeded = (gaming_budget_mins >= 0) and (gaming_seconds >= gaming_budget_mins * 60)

        # Check quota warnings: 10, 5, 1 minute
        if remaining_seconds <= 600 and not self.warning_sent_10 and remaining_seconds > 300:
            self.warning_sent_10 = True
            if self.on_warning:
                self.on_warning(10, "Con còn 10 phút sử dụng máy tính hôm nay.")
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            queue_event(self.device_id, self.child_id, EventType.QUOTA_WARNING.value, "10_min_warning", 0, policy_id)

        if remaining_seconds <= 300 and not self.warning_sent_5 and remaining_seconds > 60:
            self.warning_sent_5 = True
            if self.on_warning:
                self.on_warning(5, "Con còn 5 phút sử dụng. Hãy chuẩn bị lưu bài nhé!")
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            queue_event(self.device_id, self.child_id, EventType.QUOTA_WARNING.value, "5_min_warning", 0, policy_id)

        if remaining_seconds <= 60 and not self.warning_sent_1 and remaining_seconds > 0:
            self.warning_sent_1 = True
            if self.on_warning:
                self.on_warning(1, "Con còn 1 phút! Máy sẽ khóa sau khoảng ân hạn 60 giây để lưu bài.")
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            queue_event(self.device_id, self.child_id, EventType.QUOTA_WARNING.value, "1_min_warning", 0, policy_id)

        # 60-second Grace Period before locking
        should_lock = False
        lock_reason = ""

        if schedule_locked:
            should_lock = True
            lock_reason = "Đã đến giờ nghỉ ngơi theo lịch tuần cha mẹ đã cài đặt"
        elif remaining_seconds <= 0:
            if not self.in_grace_period:
                self.in_grace_period = True
                self.grace_period_start = now_mono
                if self.on_warning:
                    self.on_warning(0, "Hết giờ sử dụng! Con có 60 giây ân hạn để lưu bài tập.")
            elif (now_mono - self.grace_period_start) >= 60.0:
                should_lock = True
                lock_reason = "Đã hết hạn mức sử dụng máy tính trong ngày"

        if should_lock and not is_locked:
            policy_id = self.policy.get("policy_id", "default") if self.policy else "default"
            queue_event(self.device_id, self.child_id, EventType.LOCKED.value, lock_reason, 0, policy_id)
            if self.on_lock:
                self.on_lock(lock_reason)
            if not self.simulate_lock:
                lock_windows_workstation()

        return {
            "used_seconds": used_seconds,
            "quota_seconds": quota_seconds,
            "remaining_seconds": remaining_seconds,
            "idle_seconds": round(idle_sec, 1),
            "is_idle": is_idle,
            "is_active": is_active,
            "is_locked": is_locked,
            "schedule_locked": schedule_locked,
            "gaming_seconds": gaming_seconds,
            "gaming_exceeded": gaming_exceeded,
            "in_grace_period": self.in_grace_period
        }
