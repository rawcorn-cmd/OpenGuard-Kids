"""OGK (Open Guardian for Kids) - Shared Module
Shared schemas, constants, cryptography and protocols.
"""

__version__ = "2.0.0"
