"""Cryptographic utilities for OGK.
F5 Requirements:
- Argon2id password hashing for parents
- HMAC-SHA256 policy integrity signing and verification
- SHA-256 file hashing for process integrity check
- AES-256-GCM encryption for sensitive data at rest
"""

import hmac
import hashlib
import json
import os
import secrets
from typing import Any, Dict, Optional, Tuple
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError

# Password hasher configuration (Argon2id default per F5)
_ph = PasswordHasher(
    time_cost=3,
    memory_cost=65536,  # 64 MB
    parallelism=4,
    hash_len=32,
    salt_len=16
)


def hash_password(password: str) -> str:
    """Hash password using Argon2id."""
    if len(password) < 10:
        raise ValueError("Mật khẩu phải có tối thiểu 10 ký tự theo tiêu chuẩn bảo mật F5.")
    return _ph.hash(password)


def verify_password(hash_str: str, password: str) -> bool:
    """Verify password against Argon2id hash."""
    try:
        return _ph.verify(hash_str, password)
    except (VerifyMismatchError, InvalidHashError, Exception):
        return False


def needs_rehash(hash_str: str) -> bool:
    """Check if password hash needs updating."""
    try:
        return _ph.check_needs_rehash(hash_str)
    except Exception:
        return False


def compute_file_sha256(file_path: str, chunk_size: int = 65536) -> Optional[str]:
    """Compute SHA-256 hex digest of a binary file.
    Returns None if file cannot be read.
    """
    if not os.path.isfile(file_path):
        return None
    hasher = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            while chunk := f.read(chunk_size):
                hasher.update(chunk)
        return hasher.hexdigest().lower()
    except (OSError, PermissionError):
        return None


def sign_policy(policy_dict: Dict[str, Any], secret_key: str) -> str:
    """Compute HMAC-SHA256 signature for a policy dictionary.
    Excludes any existing 'signature' key and sorts keys for canonical JSON.
    """
    clean_dict = {k: v for k, v in policy_dict.items() if k != "signature"}
    canonical_json = json.dumps(clean_dict, sort_keys=True, separators=(",", ":"))
    h = hmac.new(secret_key.encode("utf-8"), canonical_json.encode("utf-8"), hashlib.sha256)
    return h.hexdigest()


def verify_policy_signature(policy_dict: Dict[str, Any], signature: str, secret_key: str) -> bool:
    """Verify policy integrity using HMAC-SHA256."""
    expected = sign_policy(policy_dict, secret_key)
    return hmac.compare_digest(expected, signature)


def generate_device_secret() -> str:
    """Generate 256-bit cryptographically secure device secret."""
    return secrets.token_hex(32)


def generate_enrollment_code() -> str:
    """Generate 8-character alphanumeric enrollment code."""
    # Exclude ambiguous characters like 0, O, 1, I
    alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    return "".join(secrets.choice(alphabet) for _ in range(8))


def generate_token() -> str:
    """Generate secure URL-safe token."""
    return secrets.token_urlsafe(32)


# AES-256-GCM Storage Encryption
def encrypt_aes_gcm(plaintext: str, key_bytes: bytes) -> Tuple[bytes, bytes]:
    """Encrypt plaintext using AES-256-GCM.
    Returns (nonce, ciphertext_with_tag).
    """
    if len(key_bytes) != 32:
        raise ValueError("AES-256 key must be exactly 32 bytes.")
    aesgcm = AESGCM(key_bytes)
    nonce = os.urandom(12)  # Standard 96-bit nonce for GCM
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce, ciphertext


def decrypt_aes_gcm(nonce: bytes, ciphertext: bytes, key_bytes: bytes) -> str:
    """Decrypt ciphertext using AES-256-GCM.
    Raises exception if authentication tag verification fails.
    """
    if len(key_bytes) != 32:
        raise ValueError("AES-256 key must be exactly 32 bytes.")
    aesgcm = AESGCM(key_bytes)
    plaintext_bytes = aesgcm.decrypt(nonce, ciphertext, None)
    return plaintext_bytes.decode("utf-8")


def derive_key(secret: str, salt: bytes = b"ogk_fixed_salt_v2") -> bytes:
    """Derive 32-byte AES key using HKDF-SHA256 from a string secret."""
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives import hashes
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=b"ogk_storage_key",
    )
    return hkdf.derive(secret.encode("utf-8"))
