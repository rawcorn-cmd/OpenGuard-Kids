"""Constants for OGK (Open Guardian for Kids).
Strict compliance with specifications and NT1-NT6 principles.
"""

from enum import Enum


class Category(str, Enum):
    """6 standard classification categories required by specification F2."""
    EDUCATION = "education"                  # Giáo dục
    ENTERTAINMENT = "entertainment"          # Giải trí
    SOCIAL_MEDIA = "social_media"            # Mạng xã hội
    GAMING = "gaming"                        # Trò chơi
    INAPPROPRIATE = "inappropriate"          # Không phù hợp lứa tuổi
    UNCATEGORIZED = "uncategorized"          # Chưa phân loại


CATEGORY_LABELS = {
    Category.EDUCATION: "Giáo dục & Học tập",
    Category.ENTERTAINMENT: "Giải trí phù hợp",
    Category.SOCIAL_MEDIA: "Mạng xã hội",
    Category.GAMING: "Trò chơi trực tuyến",
    Category.INAPPROPRIATE: "Không phù hợp lứa tuổi",
    Category.UNCATEGORIZED: "Chưa phân loại",
}


class EventType(str, Enum):
    """Event types strictly defined in F3 specification."""
    APP_START = "app_start"
    APP_STOP = "app_stop"
    DOMAIN_QUERY = "domain_query"
    BLOCKED_APP = "blocked_app"
    BLOCKED_DOMAIN = "blocked_domain"
    QUOTA_WARNING = "quota_warning"
    LOCKED = "locked"
    UNLOCK_REQUEST = "unlock_request"
    OVERRIDE_GRANTED = "override_granted"


class RequestStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class RequestType(str, Enum):
    EXTRA_TIME = "extra_time"                # Xin thêm giờ
    FALSE_POSITIVE = "false_positive"        # Con nghĩ trang này bị chặn nhầm


# SafeSearch DNS redirection targets
SAFESEARCH_TARGETS = {
    "google": {
        "domains": [
            "www.google.com", "google.com", "google.com.vn", "www.google.com.vn",
            "google.co.uk", "google.fr", "google.de", "google.jp"
        ],
        "cname": "forcesafesearch.google.com.",
        "ip": "216.239.38.120",
    },
    "youtube": {
        "domains": [
            "www.youtube.com", "youtube.com", "m.youtube.com",
            "youtubei.googleapis.com", "youtube.googleapis.com"
        ],
        "cname": "restrict.youtube.com.",
        "ip": "216.239.38.120",
    },
    "bing": {
        "domains": ["www.bing.com", "bing.com"],
        "cname": "strict.bing.com.",
        "ip": "204.79.197.220",
    },
    "duckduckgo": {
        "domains": ["duckduckgo.com", "www.duckduckgo.com"],
        "cname": "safe.duckduckgo.com.",
        "ip": "52.149.246.39",
    },
}

# NT6: Permanent Emergency and Educational Whitelist - NEVER BLOCKED
PERMANENT_WHITELIST_DOMAINS = [
    # Cổng thông tin Tổng đài quốc gia bảo vệ trẻ em 111 & Cục Trẻ Em
    "tongdai111.vn",
    "www.tongdai111.vn",
    "tongdai111.gov.vn",
    "cucbaovetreem.gov.vn",
    "bvte.org.vn",
    # Dịch vụ chính phủ & Giáo dục Việt Nam
    "chinhphu.vn",
    "moet.gov.vn",
    "dichvucong.gov.vn",
    "baochinhphu.vn",
    "truonghoc.vn",
    # Dịch vụ cứu nạn cứu hộ & y tế khẩn cấp
    "114.gov.vn",
    "115.gov.vn",
    "moh.gov.vn",
    "capcuu.vn",
]

# Domain patterns always allowed (.edu.vn, .gov.vn)
PERMANENT_WHITELIST_SUFFIXES = [
    ".edu.vn",
    ".gov.vn",
]

# Default DoH (DNS-over-HTTPS) domains to detect or redirect to proxy
DOH_ENDPOINTS = [
    "cloudflare-dns.com",
    "dns.google",
    "dns.quad9.net",
    "doh.opendns.com",
    "doh.cleanbrowsing.org",
]

# Default Age 6-11 Policy settings
DEFAULT_AGE_6_11_BLOCKED_CATEGORIES = [
    Category.INAPPROPRIATE.value,
    Category.SOCIAL_MEDIA.value,
    Category.GAMING.value,
]

# Offline policy expiry default (in days)
DEFAULT_OFFLINE_EXPIRY_DAYS = 7
