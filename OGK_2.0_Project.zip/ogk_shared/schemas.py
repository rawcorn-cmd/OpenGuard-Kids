"""Data schemas for OGK.
Enforces Pydantic validation across server and agent.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from ogk_shared.constants import Category, EventType, RequestStatus, RequestType


class AppRule(BaseModel):
    """Application rule with process name and optional SHA-256 hash."""
    name: str = Field(..., description="Tên tiến trình thực thi, vd: roblox.exe")
    sha256: Optional[str] = Field(None, description="Mã băm SHA-256 đối chiếu tính toàn vẹn")
    action: str = Field("block", description="'block' hoặc 'allow'")
    category: str = Field(Category.GAMING.value, description="Nhóm ứng dụng")
    display_name: Optional[str] = Field(None, description="Tên hiển thị thân thiện với trẻ")
    reason: Optional[str] = Field("Ứng dụng bị giới hạn theo quy định của cha mẹ", description="Lý do hiển thị khi chặn")


class DomainRule(BaseModel):
    """Domain filtering rule."""
    domain: str = Field(..., description="Tên miền (SLD hoặc FQDN), vd: game.example.com")
    action: str = Field("block", description="'block' hoặc 'allow'")
    category: str = Field(Category.UNCATEGORIZED.value, description="Phân loại tên miền")
    reason: Optional[str] = Field("Trang web bị chặn theo chính sách gia đình", description="Lý do hiển thị")


class ScheduleMatrix(BaseModel):
    """7x48 matrix for weekly schedule with 30-min resolution.
    Days: 0 = Thứ Hai (Monday), ..., 6 = Chủ Nhật (Sunday).
    Each day has 48 integers: 1 = allowed, 0 = locked.
    """
    matrix: List[List[int]] = Field(
        default_factory=lambda: [[1] * 48 for _ in range(7)],
        description="Ma trận 7 ngày x 48 khung giờ (30 phút)"
    )


class PolicySchema(BaseModel):
    """Complete policy definition with versioning and HMAC signature."""
    policy_id: str = "default_policy"
    version: int = 1
    child_id: str
    daily_quota_minutes_weekday: int = 90
    daily_quota_minutes_weekend: int = 120
    schedule: ScheduleMatrix = Field(default_factory=ScheduleMatrix)
    blocked_categories: List[str] = Field(
        default_factory=lambda: [Category.INAPPROPRIATE.value, Category.SOCIAL_MEDIA.value]
    )
    allowed_categories: List[str] = Field(
        default_factory=lambda: [Category.EDUCATION.value, Category.ENTERTAINMENT.value]
    )
    app_rules: List[AppRule] = Field(default_factory=list)
    domain_rules: List[DomainRule] = Field(default_factory=list)
    app_group_budgets: Dict[str, int] = Field(
        default_factory=lambda: {Category.GAMING.value: 45, Category.EDUCATION.value: -1}
    )
    safesearch_enforced: bool = True
    offline_expiry_days: int = 7
    fail_open_after_expiry: bool = False
    signature: Optional[str] = None


class EventRecord(BaseModel):
    """Event schema strictly adhering to F3 specification:
    ts, device_id, child_id, type, subject, duration_sec, policy_id.
    """
    ts: float = Field(..., description="Dấu thời gian UNIX")
    device_id: str = Field(..., description="ID thiết bị duy nhất")
    child_id: str = Field(..., description="ID trẻ")
    type: EventType = Field(..., description="Loại sự kiện")
    subject: str = Field(..., description="Tên ứng dụng hoặc tên miền cấp hai (KHÔNG phải URL đầy đủ)")
    duration_sec: int = Field(0, description="Thời lượng tính bằng giây")
    policy_id: str = Field(..., description="ID chính sách đang áp dụng")
    idempotency_key: Optional[str] = Field(None, description="Khóa chống trùng sự kiện khi đồng bộ ngoại tuyến")


class BatchEventsPayload(BaseModel):
    """Batch payload sent by agent during sync."""
    events: List[EventRecord]


class UrgentCommand(BaseModel):
    """Urgent command dispatched via WebSocket or heartbeat."""
    command_id: str
    device_id: str
    action: str  # lock_now, unlock, add_time, refresh_policy, wipe_cache
    payload: Dict[str, Any] = Field(default_factory=dict)
    created_at: float


class HeartbeatRequest(BaseModel):
    """Heartbeat sent by agent every 3s-60s for telemetry & pending commands."""
    device_id: str
    child_id: str
    status: str = "active"  # active, locked, idle
    quota_used_seconds: int = 0
    policy_version: int = 0
    screen_locked: bool = False
    idle_seconds: float = 0.0
    is_idle: bool = False
    current_app: Optional[str] = None
    window_title: Optional[str] = None
    recent_domains: Optional[List[Dict[str, Any]]] = None
    remaining_seconds: Optional[int] = None
    quota_seconds: Optional[int] = None
    all_apps_today: Optional[List[Dict[str, Any]]] = None


class HeartbeatResponse(BaseModel):
    """Server response to heartbeat."""
    latest_policy_version: int
    pending_commands: List[UrgentCommand] = Field(default_factory=list)
    override_seconds: int = 0


class ChildRequestCreate(BaseModel):
    """Payload when child clicks 'Xin thêm giờ' or 'Báo chặn nhầm'."""
    request_type: RequestType
    subject: str
    reason: str


class ChildRequestResponse(BaseModel):
    id: str
    child_id: str
    device_id: str
    request_type: RequestType
    subject: str
    reason: str
    status: RequestStatus
    parent_response: Optional[str] = None
    created_at: float
    updated_at: Optional[float] = None


class AuditLogResponse(BaseModel):
    id: int
    timestamp: float
    operator: str
    client_ip: str
    action: str
    target: str
    old_value: Optional[str] = None
    new_value: Optional[str] = None


class EnrollmentCreate(BaseModel):
    child_id: str
    device_name: str = "Máy tính của trẻ"


class EnrollmentCodeInfo(BaseModel):
    code: str
    child_id: str
    expires_at: float


class EnrollmentAgentRequest(BaseModel):
    code: str
    device_fingerprint: str
    hostname: str
    os_version: str


class EnrollmentAgentResponse(BaseModel):
    device_id: str
    child_id: str
    access_token: str
    refresh_token: str
    secret_key: str
    policy: PolicySchema
