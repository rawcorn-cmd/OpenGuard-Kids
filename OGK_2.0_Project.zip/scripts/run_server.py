"""Start OGK-Server FastAPI backend.
"""

import sys
import os
import socket
import subprocess

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import uvicorn
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

sys.path.insert(0, project_root)

import uvicorn


def get_lan_ip() -> str:
    """Detect primary LAN IPv4 address for mobile/other devices access."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        # Using a non-routable address to determine outgoing interface
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


if __name__ == "__main__":
    if sys.stdout.encoding != 'utf-8':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    lan_ip = get_lan_ip()
    port = int(os.environ.get("OGK_SERVER_PORT", "8000"))
    host = os.environ.get("OGK_SERVER_HOST", "0.0.0.0")

    print("================================================================")
    print("  OGK 2.0 - Open Guardian for Kids (Parent Server)")
    print("  Đồng hành minh bạch - Tuân thủ Nghị định 13/2023/NĐ-CP")
    print("----------------------------------------------------------------")
    print(f"  [1] Truy cập tại máy tính này:     http://127.0.0.1:{port}")
    if lan_ip != "127.0.0.1":
        print(f"  [2] Truy cập qua Điện thoại/LAN:   http://{lan_ip}:{port}")
    print("================================================================")
    uvicorn.run("ogk_server.main:app", host=host, port=port, reload=False, log_level="info")

