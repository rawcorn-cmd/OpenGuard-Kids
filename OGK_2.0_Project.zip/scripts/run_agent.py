"""Run OGK Agent Service daemon in console mode.
"""

import sys
import os
import subprocess

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import psutil
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

sys.path.insert(0, project_root)


if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from ogk_agent.service import OGKAgentService

if __name__ == "__main__":
    args = sys.argv[1:]
    real_lock = "--real-lock" in args
    server_url = "http://127.0.0.1:8000"

    for a in args:
        if a.startswith("http://") or a.startswith("https://"):
            server_url = a

    print(f"[*] Chế độ khóa máy: {'KHÓA THẬT (Windows Lock)' if real_lock else 'AN TOÀN MÔ PHỎNG (Không khóa văng màn hình)'}")
    print(f"    (Thêm cờ --real-lock nếu muốn kích hoạt khóa thật Win+L khi hết giờ)")

    agent = OGKAgentService(server_url=server_url, simulate_lock=(not real_lock))
    agent.start()

