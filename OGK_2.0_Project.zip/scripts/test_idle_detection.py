"""OGK 2.0 - Idle Detection Diagnostic & Verification Script.
Demonstrates F1 Acceptance Criteria:
- Screen-time tracking MUST pause if machine is idle (no mouse/keyboard input) or workstation locked.
- Configurable threshold (e.g., 10 seconds for quick demonstration).
- Resumes immediately upon user interaction.
"""

import os
import sys
import time

# Auto-reexec with local .venv python
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    import subprocess
    sys.exit(subprocess.call([venv_python] + sys.argv))

sys.path.insert(0, project_root)

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from ogk_agent.screen_time import ScreenTimeManager, get_idle_duration_seconds, is_workstation_locked
from ogk_agent.local_cache import init_local_db


def main():
    init_local_db()
    timeout = 10.0
    if len(sys.argv) > 1:
        try:
            timeout = float(sys.argv[1])
        except ValueError:
            pass

    print("=" * 65)
    print("  OGK 2.0 - CÔNG CỤ KIỂM THỬ KHẢ NĂNG DỪNG ĐẾM GIỜ KHI KHÔNG SỬ DỤNG")
    print("=" * 65)
    print(f"Ngưỡng phát hiện không hoạt động (Idle Timeout): {timeout:.0f} giây.")
    print("Phương thức: Windows API GetLastInputInfo (chuột + bàn phím).")
    print("Hướng dẫn thử nghiệm:")
    print("  1. Hãy KHÔNG chạm vào chuột hoặc bàn phím trong 10 giây.")
    print("     -> Bạn sẽ thấy hệ thống tự động chuyển sang [TẠM DỪNG ⏸️] và ngừng đếm giờ.")
    print("  2. Sau đó, hãy di chuột hoặc bấm một phím bất kỳ.")
    print("     -> Bạn sẽ thấy hệ thống lập tức [TIẾP TỤC 🟢] và bắt đầu đếm tiếp.")
    print("Nhấn Ctrl + C để kết thúc thử nghiệm bất kỳ lúc nào.\n")

    manager = ScreenTimeManager(
        device_id="diagnostic_device",
        child_id="diagnostic_child",
        simulate_lock=True,
        idle_timeout_seconds=timeout
    )
    # 24h allowed matrix
    manager.update_policy({
        "version": 1,
        "daily_quota_minutes_weekday": 120,
        "daily_quota_minutes_weekend": 120,
        "schedule": {"matrix": [[1] * 48 for _ in range(7)]}
    })

    print("-" * 65)
    print(f"{'Giây':<6} | {'Idle Time':<12} | {'Đã dùng':<10} | {'Trạng thái đếm giờ'}")
    print("-" * 65)

    initial_used = manager.get_remaining_seconds()
    last_used_sec = 0

    tick = 0
    try:
        while tick < 45:
            tick += 1
            res = manager.tick(delta_seconds=1.0)
            idle_s = res["idle_seconds"]
            used_s = res["used_seconds"]
            is_active = res["is_active"]
            is_idle = res["is_idle"]
            is_locked = res["is_locked"]

            status_str = ""
            if is_locked:
                status_str = "🔒 ĐÃ KHÓA MÁY"
            elif is_idle:
                status_str = f"⏸️ TẠM DỪNG (Không chạm chuột/phím > {timeout:.0f}s - Không hao quota!)"
            else:
                status_str = "🟢 ĐANG ĐẾM GIỜ (Đang có tương tác người dùng)"

            diff = used_s - last_used_sec
            last_used_sec = used_s

            print(f"#{tick:<5} | {idle_s:>6.1f} giây  | {used_s:>5} giây   | {status_str}")
            time.sleep(1.0)

    except KeyboardInterrupt:
        print("\n[*] Dừng kiểm thử.")

    print("\n" + "=" * 65)
    print("  KẾT QUẢ KIỂM THỬ:")
    print("  - Khi người dùng không chạm vào chuột/bàn phím vượt ngưỡng,")
    print("    biến `is_active` chuyển thành False và hàm `record_time_tick`")
    print("    không được gọi, đảm bảo quyền lợi thời gian của trẻ!")
    print("=" * 65)


if __name__ == "__main__":
    main()
