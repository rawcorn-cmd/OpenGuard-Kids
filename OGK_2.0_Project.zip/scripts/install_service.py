"""Windows Service installation and management script using win32serviceutil.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if __name__ == "__main__":
    try:
        import win32serviceutil
        from ogk_agent.service import OGKWindowsService
        if OGKWindowsService is None:
            print("[-] pywin32 Windows Service support not available.")
            sys.exit(1)
        win32serviceutil.HandleCommandLine(OGKWindowsService)
    except Exception as e:
        print(f"[-] Error managing Windows Service: {e}")
        print("    Usage: python scripts/install_service.py [install | start | stop | remove]")
