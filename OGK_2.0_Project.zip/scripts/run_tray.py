"""Run OGK Agent System Tray UI in the child user session.
"""

import sys
import os
import subprocess

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import pystray
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

sys.path.insert(0, project_root)


if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from ogk_agent.tray_ui import ChildTrayApp

if __name__ == "__main__":
    server_url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000"
    app = ChildTrayApp(server_url=server_url)
    app.run()
