"""Database seeding script for OGK 2.0.
Pre-populates sample parent account, children profiles, devices, and realistic event logs.
"""

import json
import os
import sys
import time
import uuid
import subprocess

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import sqlalchemy
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

# Add parent path to sys.path
sys.path.insert(0, project_root)

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass


from ogk_shared.crypto import hash_password, generate_device_secret, generate_token
from ogk_shared.constants import Category, EventType
from ogk_server.database import (
    init_db, SessionLocal, UserModel, ChildModel, DeviceModel, PolicyModel, EventModel, AuditLogModel
)
from ogk_server.routes.policy_routes import get_default_matrix


def seed():
    print("[*] Initializing database...")
    init_db()
    db = SessionLocal()

    # 1. Create Parent User
    parent_email = "parent@ogk.local"
    parent = db.query(UserModel).filter(UserModel.email == parent_email).first()
    if not parent:
        print(f"[*] Creating sample parent account: {parent_email}")
        parent = UserModel(
            id=str(uuid.uuid4()),
            email=parent_email,
            password_hash=hash_password("ParentPass1234!"),  # >= 10 chars
            full_name="Nguyễn Văn Phụ Huynh",
            role="parent"
        )
        db.add(parent)
        db.commit()
        db.refresh(parent)
    else:
        print("[*] Parent account already exists.")

    # 2. Create Child Profiles
    child_name = "Bé Nam"
    child = db.query(ChildModel).filter(
        ChildModel.parent_id == parent.id,
        ChildModel.name == child_name
    ).first()

    if not child:
        print(f"[*] Creating sample child profile: {child_name} (9 tuổi)")
        child = ChildModel(
            id=str(uuid.uuid4()),
            parent_id=parent.id,
            name=child_name,
            age=9,
            avatar="boy_avatar.png"
        )
        db.add(child)
        db.commit()
        db.refresh(child)

    # 3. Create Device
    device = db.query(DeviceModel).filter(DeviceModel.child_id == child.id).first()
    if not device:
        print("[*] Creating sample device: DESKTOP-NAM")
        device = DeviceModel(
            id=str(uuid.uuid4()),
            child_id=child.id,
            name="Máy tính học tập của Nam",
            hostname="DESKTOP-NAM",
            os_version="Windows 11 Home x64",
            device_fingerprint="fp_sample_child_desktop_001",
            secret_key=generate_device_secret(),
            access_token=generate_token(),
            access_token_expires_at=time.time() + 86400,
            refresh_token=generate_token(),
            status="active",
            last_heartbeat=time.time()
        )
        db.add(device)
        db.commit()
        db.refresh(device)

    # Always ensure credentials.json is written to all locations
    from ogk_agent.config import save_credentials
    save_credentials({
        "server_url": "http://127.0.0.1:8000",
        "device_id": device.id,
        "child_id": child.id,
        "access_token": device.access_token,
        "refresh_token": device.refresh_token,
        "secret_key": device.secret_key
    })
    print(f"[*] Local Agent credentials synchronized: {device.id} ({device.name})")




    # 4. Create Policy
    policy = db.query(PolicyModel).filter(PolicyModel.child_id == child.id).first()
    if not policy:
        print("[*] Creating default policy for child...")
        app_rules = [
            {"name": "roblox.exe", "sha256": None, "action": "block", "category": Category.GAMING.value, "display_name": "Roblox", "reason": "Trò chơi trực tuyến bị giới hạn theo giờ"},
            {"name": "game.exe", "sha256": None, "action": "block", "category": Category.GAMING.value, "display_name": "Game Test", "reason": "Trò chơi bị hạn chế theo quy định gia đình"},
        ]
        domain_rules = [
            {"domain": "tiktok.com", "action": "block", "category": Category.SOCIAL_MEDIA.value, "reason": "Mạng xã hội không phù hợp với lứa tuổi 6-11"},
            {"domain": "roblox.com", "action": "block", "category": Category.GAMING.value, "reason": "Giới hạn truy cập trò chơi trực tuyến"},
        ]
        budgets = {
            Category.GAMING.value: 45,
            Category.EDUCATION.value: -1,
            Category.ENTERTAINMENT.value: 30,
        }

        policy = PolicyModel(
            child_id=child.id,
            version=1,
            daily_quota_minutes_weekday=180,
            daily_quota_minutes_weekend=240,
            schedule_matrix_json=json.dumps([[1] * 48 for _ in range(7)]),
            blocked_categories_json=json.dumps([
                Category.INAPPROPRIATE.value,
                Category.SOCIAL_MEDIA.value,
                Category.GAMING.value
            ]),
            allowed_categories_json=json.dumps([
                Category.EDUCATION.value,
                Category.ENTERTAINMENT.value
            ]),
            app_rules_json=json.dumps(app_rules),
            domain_rules_json=json.dumps(domain_rules),
            app_group_budgets_json=json.dumps(budgets),
            safesearch_enforced=True,
            offline_expiry_days=7,
            fail_open_after_expiry=False,
            updated_at=time.time()
        )

        db.add(policy)
        db.commit()

    # 5. Populate Sample Activity Events for Charts and Reports
    existing_events = db.query(EventModel).filter(EventModel.child_id == child.id).count()
    if existing_events == 0:
        print("[*] Generating realistic 7-day usage events...")
        now = time.time()
        sample_apps = [
            ("msedge.exe", 1800),
            ("code.exe", 2400),
            ("scratch.exe", 1500),
            ("word.exe", 1200),
            ("powerpnt.exe", 900),
            ("calculator.exe", 300)
        ]
        sample_domains = [
            "scratch.mit.edu", "khanacademy.org", "vi.wikipedia.org",
            "duolingo.com", "hocmai.vn", "vio.edu.vn", "google.com"
        ]

        for day_offset in range(6, -1, -1):
            day_ts = now - (day_offset * 86400) - 3600
            for app_name, dur in sample_apps:
                ev = EventModel(
                    ts=day_ts,
                    device_id=device.id,
                    child_id=child.id,
                    type=EventType.APP_START.value,
                    subject=app_name,
                    duration_sec=dur,
                    policy_id=policy.id,
                    idempotency_key=str(uuid.uuid4())
                )
                db.add(ev)

            for d in sample_domains:
                ev_d = EventModel(
                    ts=day_ts + 60,
                    device_id=device.id,
                    child_id=child.id,
                    type=EventType.DOMAIN_QUERY.value,
                    subject=d,
                    duration_sec=0,
                    policy_id=policy.id,
                    idempotency_key=str(uuid.uuid4())
                )
                db.add(ev_d)

        # Add a couple of blocked events
        ev_block1 = EventModel(
            ts=now - 1200,
            device_id=device.id,
            child_id=child.id,
            type=EventType.BLOCKED_APP.value,
            subject="game.exe",
            duration_sec=0,
            policy_id=policy.id,
            idempotency_key=str(uuid.uuid4())
        )
        ev_block2 = EventModel(
            ts=now - 600,
            device_id=device.id,
            child_id=child.id,
            type=EventType.BLOCKED_DOMAIN.value,
            subject="tiktok.com",
            duration_sec=0,
            policy_id=policy.id,
            idempotency_key=str(uuid.uuid4())
        )
        db.add(ev_block1)
        db.add(ev_block2)
        db.commit()

    # 6. Sample Audit Log
    audit_count = db.query(AuditLogModel).filter(AuditLogModel.child_id == child.id).count()
    if audit_count == 0:
        audit = AuditLogModel(
            child_id=child.id,
            operator=parent.email,
            client_ip="127.0.0.1",
            action="CREATE_CHILD",
            target=f"Hồ sơ {child.name}",
            old_value=None,
            new_value="Khởi tạo tài khoản và chính sách chuẩn trẻ em 6-11 tuổi",
            timestamp=time.time() - 86400 * 2
        )
        db.add(audit)
        db.commit()

    db.close()
    print("[+] Database seeding completed successfully!")
    print(f"    Parent Login: {parent_email} / ParentPass1234!")


if __name__ == "__main__":
    seed()
