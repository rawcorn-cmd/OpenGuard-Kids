"""OGK 2.0 - Enrollment Tool for Child PC.
Supports both Native Windows Tkinter GUI and CLI mode.
Pairs device with parent server using an 8-character code (Nghị định 13/2023/NĐ-CP).
"""

import sys
import os
import socket
import subprocess
import threading

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import httpx
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

# Add project root to sys.path
if project_root not in sys.path:
    sys.path.insert(0, project_root)

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from ogk_agent.client import OGKClient
from ogk_agent.config import save_credentials, load_credentials


def run_cli_enrollment(code: str, server_url: str):
    """Run enrollment via Command Line."""
    print(f"[*] Đang thực hiện ghép đôi thiết bị với mã: {code} tại {server_url}...")
    client = OGKClient(server_url=server_url)
    try:
        creds = client.enroll(code)
        save_credentials(creds)
        print("[+] ========================================================")
        print("[+] Ghép đôi thiết bị thành công!")
        print(f"[+] Device ID:   {creds['device_id']}")
        print(f"[+] Child ID:    {creds['child_id']}")
        print(f"[+] Server URL:  {creds.get('server_url', server_url)}")
        print(f"[+] Access Token:{creds['access_token'][:12]}...")
        print("[+] Đã lưu thông tin xác thực an toàn vào hệ thống.")
        print("[+] Bạn có thể khởi chạy Agent bằng: python scripts/run_agent.py")
        print("[+] ========================================================")
    except Exception as e:
        print(f"[-] Lỗi ghép đôi: {e}")
        sys.exit(1)


def launch_gui_enrollment():
    """Launch Native Windows Tkinter GUI for device enrollment."""
    import tkinter as tk
    from tkinter import ttk, messagebox

    root = tk.Tk()
    root.title("OGK 2.0 - Ghép Đôi Thiết Bị Trẻ Em")
    root.geometry("520x540")
    root.resizable(False, False)
    root.configure(bg="#f8fafc")

    # Center window on screen
    root.update_idletasks()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = max(0, (screen_width - 520) // 2)
    y = max(0, (screen_height - 540) // 2)
    root.geometry(f"520x540+{x}+{y}")

    # Set icon if available
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    # Header Frame
    header_frame = tk.Frame(root, bg="#1e293b", padx=24, pady=20)
    header_frame.pack(fill="x")

    lbl_logo = tk.Label(header_frame, text="🛡️", font=("Segoe UI Emoji", 28), bg="#1e293b", fg="#38bdf8")
    lbl_logo.pack(anchor="w")

    lbl_title = tk.Label(header_frame, text="OGK 2.0 - Open Guardian for Kids", font=("Segoe UI", 15, "bold"), bg="#1e293b", fg="#ffffff")
    lbl_title.pack(anchor="w")

    lbl_sub = tk.Label(header_frame, text="Liên kết thiết bị của con với máy chủ phụ huynh qua mã 8 ký tự", font=("Segoe UI", 9), bg="#1e293b", fg="#94a3b8")
    lbl_sub.pack(anchor="w", pady=(2, 0))

    # Body Frame
    body_frame = tk.Frame(root, bg="#f8fafc", padx=28, pady=20)
    body_frame.pack(fill="both", expand=True)

    # Check existing credentials
    existing_creds = load_credentials()
    has_paired = bool(existing_creds and existing_creds.get("device_id"))

    if has_paired:
        status_box = tk.LabelFrame(body_frame, text="Trạng thái hiện tại", font=("Segoe UI", 9, "bold"), bg="#f8fafc", fg="#0f172a", padx=12, pady=8)
        status_box.pack(fill="x", pady=(0, 14))
        dev_id = existing_creds.get("device_id", "N/A")
        srv = existing_creds.get("server_url", "http://127.0.0.1:8000")
        lbl_cur = tk.Label(status_box, text=f"✅ Máy đã ghép đôi: {dev_id[:16]}...\nMáy chủ: {srv}", font=("Segoe UI", 8), bg="#f8fafc", fg="#15803d", justify="left")
        lbl_cur.pack(anchor="w")

    # Server URL Field
    lbl_srv = tk.Label(body_frame, text="Địa chỉ Máy chủ Quản lý (Server URL):", font=("Segoe UI", 9, "bold"), bg="#f8fafc", fg="#334155")
    lbl_srv.pack(anchor="w")

    srv_var = tk.StringVar(value=existing_creds.get("server_url") or "http://127.0.0.1:8000")
    entry_srv = tk.Entry(body_frame, textvariable=srv_var, font=("Segoe UI", 10), bd=1, relief="solid")
    entry_srv.pack(fill="x", pady=(4, 12), ipady=5)

    # Pairing Code Field
    lbl_code = tk.Label(body_frame, text="Mã Ghép Đôi 8 Ký Tự (Lấy từ Dashboard Phụ Huynh):", font=("Segoe UI", 9, "bold"), bg="#f8fafc", fg="#334155")
    lbl_code.pack(anchor="w")

    code_var = tk.StringVar()

    def format_code(*args):
        val = code_var.get().upper().replace(" ", "").replace("-", "")
        if len(val) > 8:
            val = val[:8]
        code_var.set(val)

    code_var.trace_add("write", format_code)

    entry_code = tk.Entry(
        body_frame,
        textvariable=code_var,
        font=("Consolas", 18, "bold"),
        justify="center",
        bd=1,
        relief="solid",
        fg="#1e40af",
        bg="#eff6ff"
    )
    entry_code.pack(fill="x", pady=(4, 6), ipady=6)
    entry_code.focus_set()

    lbl_hint = tk.Label(body_frame, text="Mã gồm 8 chữ cái/chữ số, có hiệu lực trong 10 phút sau khi tạo.", font=("Segoe UI", 8), bg="#f8fafc", fg="#64748b")
    lbl_hint.pack(anchor="w", pady=(0, 16))

    # Status Label
    status_msg = tk.StringVar(value="Sẵn sàng thực hiện ghép đôi.")
    lbl_status = tk.Label(body_frame, textvariable=status_msg, font=("Segoe UI", 9), bg="#f8fafc", fg="#475569", wraplength=460, justify="center")
    lbl_status.pack(fill="x", pady=(0, 14))

    # Action Button
    btn_submit = tk.Button(
        body_frame,
        text="🚀 KÍCH HOẠT & LIÊN KẾT THIẾT BỊ",
        font=("Segoe UI", 11, "bold"),
        bg="#2563eb",
        fg="#ffffff",
        activebackground="#1d4ed8",
        activeforeground="#ffffff",
        bd=0,
        cursor="hand2",
        padx=16,
        pady=10
    )
    btn_submit.pack(fill="x")

    def perform_enrollment():
        code = code_var.get().strip().upper()
        server_url = srv_var.get().strip().rstrip("/")

        if len(code) != 8:
            messagebox.showwarning("Mã không hợp lệ", "Mã ghép đôi phải bao gồm đúng 8 ký tự.")
            return

        btn_submit.config(state="disabled", text="⏳ Đang xử lý ghép đôi...")
        status_msg.set(f"Đang kết nối tới máy chủ {server_url}...")
        lbl_status.config(fg="#0284c7")

        def worker():
            try:
                client = OGKClient(server_url=server_url)
                creds = client.enroll(code)
                save_credentials(creds)

                def on_success():
                    btn_submit.config(state="normal", text="✅ ĐÃ LIÊN KẾT THÀNH CÔNG!", bg="#16a34a")
                    status_msg.set(f"Thiết bị đã ghép đôi thành công!\nDevice ID: {creds['device_id']}")
                    lbl_status.config(fg="#16a34a")
                    messagebox.showinfo(
                        "Ghép đôi thành công",
                        f"Thiết bị đã được liên kết thành công với tài khoản cha mẹ!\n\n"
                        f"Mã thiết bị: {creds['device_id']}\n"
                        f"Máy chủ: {server_url}\n\n"
                        f"Chính sách bảo vệ và mã bí mật đã được lưu an toàn.\n"
                        f"Bây giờ bạn có thể khởi chạy OGK-Agent."
                    )

                root.after(0, on_success)
            except Exception as ex:
                def on_error(err_text):
                    btn_submit.config(state="normal", text="🚀 THỬ LẠI", bg="#2563eb")
                    status_msg.set(f"Lỗi: {err_text}")
                    lbl_status.config(fg="#dc2626")
                    messagebox.showerror("Ghép đôi thất bại", f"Không thể ghép đôi với máy chủ:\n\n{err_text}\n\nVui lòng kiểm tra địa chỉ máy chủ và mã ghép đôi.")

                root.after(0, lambda: on_error(str(ex)))

        t = threading.Thread(target=worker, daemon=True)
        t.start()

    btn_submit.config(command=perform_enrollment)

    # Allow Enter key to trigger enrollment
    root.bind("<Return>", lambda evt: perform_enrollment())

    root.mainloop()


if __name__ == "__main__":
    # If arguments provided, run in CLI mode
    if len(sys.argv) >= 2 and not sys.argv[1].startswith("--gui"):
        code_arg = sys.argv[1].strip()
        server_arg = sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:8000"
        run_cli_enrollment(code_arg, server_arg)
    else:
        # Otherwise launch Native Windows Tkinter GUI
        launch_gui_enrollment()
