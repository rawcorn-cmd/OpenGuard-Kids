"""CLI tool to manage and test Windows DNS Adapter settings for OGK 2.0.
"""

import sys
import os
import subprocess

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import dnslib
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

sys.path.insert(0, project_root)

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from dnslib import DNSRecord


from ogk_agent.dns_proxy import (
    set_windows_dns_to_localhost, get_active_windows_network_interfaces,
    configure_browser_policies, sync_windows_hosts_file
)


def print_status():
    adapters = get_active_windows_network_interfaces()
    print("==================================================")
    print("  TRẠNG THÁI CẤU HÌNH DNS WINDOWS")
    print("==================================================")
    print(f"Các Card Mạng phát hiện: {adapters}")
    for iface in adapters:
        try:
            out = subprocess.check_output(f'netsh interface ipv4 show dns name="{iface}"', shell=True, text=True)
            print(f"\n[Card mạng '{iface}']: \n{out.strip()}")
        except Exception as e:
            print(f"Lỗi đọc '{iface}': {e}")


def test_query(domain: str):
    print(f"[*] Đang kiểm tra truy vấn tên miền '{domain}' qua DNS Proxy 127.0.0.1:53...")
    import socket
    q = DNSRecord.question(domain, "A")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(2.0)
    try:
        sock.sendto(q.pack(), ("127.0.0.1", 53))
        data, _ = sock.recvfrom(4096)
        resp = DNSRecord.parse(data)
        rcode_name = resp.header.rcode
        answers = [str(r.rdata) for r in resp.rr]
        print(f"[+] Kết quả trả về:")
        print(f"    RCODE: {rcode_name}")
        print(f"    Địa chỉ IP / CNAME trả về: {answers}")
        if "127.0.0.1" in answers or rcode_name != 0:
            print(f"    => TRẠNG THÁI: [🚫 ĐÃ BỊ CHẶN BỞI OGK PROXY]")
        elif any("forcesafesearch" in str(a) or "216.239.38.120" in str(a) for a in answers):
            print(f"    => TRẠNG THÁI: [🔍 ĐÃ CƯỠNG CHẾ SAFESEARCH AN TOÀN]")
        else:
            print(f"    => TRẠNG THÁI: [✅ ĐƯỢC PHÉP TRUY CẬP]")
    except Exception as e:
        print(f"[-] Không nhận được phản hồi từ 127.0.0.1:53. DNS Proxy đã bật chưa? Lỗi: {e}")
    finally:
        sock.close()


def print_doh_browser_instructions():
    print("\n" + "=" * 65)
    print("  BẢO VỆ TỰ ĐỘNG KHÔNG CẦN CÀI ĐẶT THỦ CÔNG TRÌNH DUYỆT:")
    print("=" * 65)
    print("  1. Hệ thống đã tự động vô hiệu hóa DoH trình duyệt qua Windows Policy (HKCU/HKLM).")
    print("  2. Hệ thống đã chặn DoH Canary (use-application-dns.net -> NXDOMAIN).")
    print("  3. Toàn bộ tên miền bị hạn chế được đồng bộ trực tiếp vào Windows Hosts.")
    print("  => Chrome và Edge sẽ BỊ CHẶN THỰC TẾ NGAY LẬP TỨC mà không cần mở cài đặt trình duyệt!")
    print("\n  Thử nghiệm ngay trong Command Prompt:")
    print("     nslookup tiktok.com 127.0.0.1      -> Trả về 127.0.0.1 (Đã chặn!)")
    print("     nslookup google.com 127.0.0.1      -> Trả về forcesafesearch.google.com (SafeSearch)")
    print("     nslookup tongdai111.vn 127.0.0.1   -> Luôn cho phép (Bảo vệ trẻ em NT6)")
    print("=" * 65 + "\n")


if __name__ == "__main__":
    action = sys.argv[1].lower() if len(sys.argv) > 1 else "status"

    if action == "enable":
        print("[*] Đang chuyển đổi DNS Windows sang 127.0.0.1 (Yêu cầu quyền Administrator nếu có)...")
        set_windows_dns_to_localhost(enable=True)
        print("[*] Đang áp dụng chính sách Enterprise tự động vô hiệu hóa DoH cho Chrome & Edge...")
        configure_browser_policies(disable_doh=True)
        print_status()
        print_doh_browser_instructions()

    elif action == "disable":
        print("[*] Đang khôi phục DNS Windows về mặc định DHCP...")
        set_windows_dns_to_localhost(enable=False)
        print("[*] Đang gỡ bỏ chính sách DoH cho trình duyệt...")
        configure_browser_policies(disable_doh=False)
        sync_windows_hosts_file([])
        print_status()

    elif action == "test":
        target = sys.argv[2] if len(sys.argv) > 2 else "tiktok.com"
        test_query(target)

    else:
        print_status()
        print_doh_browser_instructions()
        print("Cách dùng:")
        print("  python scripts/configure_dns.py enable         (Bật chuyển hướng DNS Windows sang 127.0.0.1)")
        print("  python scripts/configure_dns.py disable        (Khôi phục DNS về bình thường DHCP)")
        print("  python scripts/configure_dns.py test <domain>  (Thử nghiệm kiểm tra 1 tên miền có bị chặn không)")
