"""Stop all OGK 2.0 running processes cleanly.
"""

import os
import sys
import subprocess

if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

# Auto-reexec with local .venv python if needed
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    try:
        import psutil
    except ImportError:
        sys.exit(subprocess.call([venv_python] + sys.argv))

import psutil

print("==================================================")
print("  OGK 2.0 - Dừng toàn bộ hệ thống")
print("==================================================")

current_pid = os.getpid()
stopped_count = 0

for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
    try:
        pid = proc.info['pid']
        if pid == current_pid:
            continue
        cmdline = " ".join(proc.info.get('cmdline') or []).lower()
        if any(keyword in cmdline for keyword in ["run_server", "run_agent", "run_tray", "ogk_server.main", "uvicorn"]):
            print(f"[*] Đang dừng tiến trình PID {pid}: {cmdline[:60]}...")
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except psutil.TimeoutExpired:
                proc.kill()
            stopped_count += 1
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue

print(f"[+] Đã dừng thành công {stopped_count} tiến trình OGK đang chạy.")
print("    Hệ thống đã tắt hoàn toàn.")
