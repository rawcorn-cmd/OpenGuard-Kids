# OGK 2.0 (Open Guardian for Kids)
### Ứng dụng Hỗ Trợ Quản Lý Việc Sử Dụng Máy Tính Của Trẻ Em
> *"Công cụ đồng hành, không phải phần mềm theo dõi lén"*

[![Platform](https://img.shields.io/badge/Platform-Windows%2010%2F11%20(x64)-blue.svg)]()
[![Python](https://img.shields.io/badge/Python-3.11%2B-green.svg)]()
[![FastAPI](https://img.shields.io/badge/FastAPI-Modern%20Web%20Backend-teal.svg)]()
[![Security](https://img.shields.io/badge/Security-Argon2id%20%7C%20HMAC--SHA256%20%7C%20AES--GCM-red.svg)]()
[![Privacy](https://img.shields.io/badge/Privacy-Ngh%E1%BB%8B%20%C4%91%E1%BB%8Bnh%2013%2F2023%2FN%C4%90--CP-purple.svg)]()
[![Tests](https://img.shields.io/badge/Tests-23%20Passed%20(100%25)-brightgreen.svg)]()

---

## 1. Triết Lý Thiết Kế Bắt Buộc: Minh Bạch Với Trẻ (NT1 – NT6)

Hệ thống OGK được thiết kế dựa trên sự tôn trọng và đồng hành cùng sự phát triển của trẻ em:

| # | Nguyên tắc | Hiện thực chi tiết trong OGK 2.0 |
| :--- | :--- | :--- |
| **NT1** | **Trẻ biết mình đang được hỗ trợ** | Biểu tượng khay hệ thống (System Tray) luôn thường trực khi Agent chạy. Khi khởi động, hiển thị thông báo chào đón trẻ. **Agent tự động dừng nếu không thể hiển thị biểu tượng (chống chế độ ẩn danh/theo dõi lén).** |
| **NT2** | **Tối thiểu hóa dữ liệu** | Lược đồ sự kiện chỉ lưu: `ts`, `device_id`, `child_id`, `type`, `subject`, `duration_sec`, `policy_id`. `subject` chỉ lưu tên tiến trình (vd: `roblox.exe`) hoặc tên miền (vd: `scratch.mit.edu`). **Tuyệt đối KHÔNG lưu URL đầy đủ, không tiêu đề cửa sổ, không keylogger, không chụp ảnh màn hình.** |
| **NT3** | **Trẻ có tiếng nói** | Nút **"Xin thêm giờ"** (+15, +30 phút) và **"Con nghĩ trang này bị chặn nhầm"** trên giao diện khay. Yêu cầu chuyển thẳng đến Dashboard phụ huynh, được duyệt/từ chối và ghi nhận phản hồi. |
| **NT4** | **Mọi hành động phải giải thích được** | Khi chặn ứng dụng hoặc trang web, cửa sổ popup hiển thị rõ lý do và ai đặt ra luật đó (*"Cha mẹ của em"*); **không bao giờ im lặng hoặc giả vờ lỗi mạng.** |
| **NT5** | **Minh bạch hai chiều** | Màn hình **"Hôm nay em đã dùng gì"** hiển thị cùng tập số liệu mà phụ huynh xem, kèm ngôn ngữ thân thiện. Trẻ được xem toàn bộ **Nhật ký kiểm toán (Audit Log)** ghi nhận mọi lần cha mẹ thay đổi luật. |
| **NT6** | **An toàn có ưu tiên tuyệt đối** | **Danh sách miễn chặn vĩnh viễn:** Cổng thông tin Tổng đài quốc gia 111 (`tongdai111.vn`), Cục Trẻ em, dịch vụ cứu hộ khẩn cấp (`114`, `115`), và tất cả tên miền giáo dục `.edu.vn`. Khóa máy không bao giờ chặn cuộc gọi khẩn cấp. |

> [!CAUTION]
> **DANH MỤC CẤM:** Hệ thống cam kết không đọc tin nhắn/email/tài liệu; không dùng kỹ thuật rootkit/mã độc để ẩn tiến trình; không chuyển dữ liệu ra bên thứ ba; tuyệt đối không dùng nội dung người lớn thật để thử nghiệm.

---

## 2. Kiến Trúc Hệ Thống (Architecture)

```text
       MÁY CỦA TRẺ (Windows 10/11)                        MÁY CHỦ (LAN / Server)
 +---------------------------------------+           +-------------------------------+
 |  OGK-Agent (Python 3.11+)             |           |  OGK-Server (FastAPI)         |
 |  +---------------------------------+  |  HTTPS    |  +-------------------------+  |
 |  | Windows Service (SYSTEM)        |<-+---------->+->| /auth  /enroll  /policy |  |
 |  |  - Policy Enforcer (HMAC sign)  |  | Heartbeat |  | /events /commands       |  |
 |  |  - Screen-time Counter          |  |    60s    |  | /reports /audit         |  |
 |  |  - App Controller (SHA-256)     |  |           |  | /retention (90-day wipe)|  |
 |  |  - DNS Proxy 127.0.0.1:53       |  |           |  +-------------------------+  |
 |  |  - Local Cache (SQLite WAL)     |  | WebSocket |  |  SQLite + SQLAlchemy    |  |
 |  +---------------------------------+  | Lệnh gấp  |  |  (policy, event, audit) |  |
 |  +---------------------------------+  |  < 5 giây |  +-------------------------+  |
 |  | Tray UI (Phiên User)            |<-+           +---------------^---------------+
 |  |  - Đồng hồ thời gian còn lại    |  |                           | HTTPS
 |  |  - Nút 'Xin thêm giờ'           |  |                  +--------+--------+
 |  |  - Nút 'Báo chặn nhầm'          |  |                  | Dashboard phụ   |
 |  |  - Màn hình minh bạch           |  |                  | huynh (Web/App) |
 |  +---------------------------------+  |                  | Lịch - Báo cáo  |
 +---------------------------------------+                  +-----------------+
                    ^ Localhost HTTP IPC (127.0.0.1:51111)
```

---

## 3. Cấu Trúc Mã Nguồn

```text
OGK2.0/
├── README.md                           # Tài liệu tổng quan, kiến trúc và hướng dẫn nghiệm thu
├── PRIVACY.md                          # Bảng ma trận dữ liệu, mục đích, thời hạn, quyền xem (Nghị định 13/2023)
├── requirements.txt                    # Thư viện phụ thuộc
├── test_dataset.json                   # 209 tên miền phân loại chuẩn (Giáo dục, Giải trí, Mạng xã hội, Game, DoH, Chặn)
├── demo_quickstart.py                  # Kịch bản kiểm chứng tự động toàn bộ tiêu chí F1 -> F5
│
├── ogk_shared/                         # Module dùng chung giữa Server và Agent
│   ├── constants.py                    # 6 nhóm danh mục, loại sự kiện, SafeSearch, danh sách miễn chặn 111
│   ├── crypto.py                       # Argon2id, HMAC-SHA256, SHA-256 binary hash, AES-256-GCM
│   └── schemas.py                      # Pydantic models cho Policy, Schedule (7x48), Event, Commands
│
├── ogk_server/                         # Máy chủ quản lý trung tâm & Dashboard
│   ├── main.py                         # Điểm khởi chạy FastAPI
│   ├── database.py                     # Cơ sở dữ liệu SQLite chế độ WAL, mô hình quan hệ
│   ├── auth.py                         # Argon2id, khóa 15p sau 5 lần sai, phiên 12h, chống IDOR
│   ├── routes/                         # Các endpoint REST API & WebSocket
│   │   ├── auth_routes.py              # Đăng ký, đăng nhập, đăng xuất phụ huynh
│   │   ├── enroll_routes.py            # Mã ghép đôi 8 ký tự, cấp device_id và token
│   │   ├── policy_routes.py            # Quản lý chính sách, ký số HMAC, ghi nhật ký kiểm toán
│   │   ├── command_routes.py           # WebSocket lệnh khẩn cấp (< 5s), Heartbeat 60s
│   │   ├── event_routes.py             # Đồng bộ sự kiện theo lô, khóa chống trùng (Idempotency)
│   │   ├── request_routes.py           # Tiếp nhận và phê duyệt yêu cầu của trẻ (NT3)
│   │   ├── report_routes.py            # Báo cáo biểu đồ ngày/tuần, Top 10 App, Top 10 Web
│   │   ├── audit_routes.py             # Nhật ký kiểm toán thay đổi (Trẻ có quyền xem)
│   │   ├── child_routes.py             # Quản lý hồ sơ con, cơ chế thưởng giờ nhiệm vụ
│   │   └── data_retention_routes.py    # Dọn dẹp 90 ngày, nút "Xóa toàn bộ dữ liệu của con tôi"
│   ├── static/                         # CSS hiện đại, responsive mobile/desktop, JS Client
│   └── templates/                      # Giao diện Jinja2 (Dashboard, Yêu cầu, Báo cáo, Nhật ký, Trẻ em)
│
├── ogk_agent/                          # Agent chạy trên máy tính của trẻ (Windows 10/11)
│   ├── config.py                       # Cấu hình thư mục dữ liệu an toàn ACL (SYSTEM/Admin)
│   ├── local_cache.py                  # SQLite bộ đệm cục bộ, hàng đợi offline, chống trùng lặp
│   ├── client.py                       # HTTP client + WebSocket client nhận lệnh khẩn cấp
│   ├── screen_time.py                  # Đếm giờ thực tế, GetLastInputInfo, chống lùi đồng hồ, cảnh báo 10/5/1p
│   ├── app_controller.py               # Chặn tiến trình theo tên + SHA-256, kết thúc êm, hộp thoại giải thích
│   ├── dns_proxy.py                    # DNS Proxy 127.0.0.1:53, lọc tên miền/miền con, cưỡng chế SafeSearch
│   ├── ipc_server.py                   # IPC Server 127.0.0.1:51111 bảo mật token giữa Service và Tray
│   ├── service.py                      # Điều phối toàn bộ Agent (tích hợp Windows Service)
│   └── tray_ui.py                      # Biểu tượng khay, đồng hồ đếm ngược, nút xin giờ, báo chặn nhầm
│
├── scripts/                            # Các kịch bản thực thi tiện ích
│   ├── run_server.py                   # Khởi chạy máy chủ FastAPI (Cổng 8000)
│   ├── run_agent.py                    # Khởi chạy dịch vụ Agent
│   ├── run_tray.py                     # Khởi chạy giao diện Khay hệ thống
│   ├── stop_all.py                     # Dừng toàn bộ các tiến trình OGK đang chạy
│   ├── test_idle_detection.py          # Kiểm thử trực quan tính năng dừng đếm giờ khi không dùng
│   ├── configure_dns.py                # Quản lý card mạng Windows DNS & chẩn đoán tên miền
│   ├── seed_database.py                # Khởi tạo dữ liệu mẫu phong phú
│   ├── enroll_agent.py                 # Công cụ CLI ghép đôi máy
│   └── install_service.py              # Cài đặt dịch vụ Windows Service
│
└── tests/                              # Bộ kiểm thử toàn diện 23 Unit & Integration Tests (100% Pass)
    ├── test_crypto.py                  # Kiểm tra Argon2id, HMAC tamper rejection, SHA-256, AES-GCM
    ├── test_policy_enforcement.py      # Kiểm tra Quota 3p, Ma trận 7x48, Lùi đồng hồ 3h, Ngân sách game
    ├── test_dns_proxy.py               # Kiểm tra 0 dương tính giả trên 20 miền giáo dục, chặn 100% 50 miền mẫu
    ├── test_live_telemetry_and_idle.py # Kiểm tra truyền dữ liệu trực tiếp và dừng đếm giờ khi máy nghỉ
    ├── test_app_controller.py          # Kiểm tra đổi tên notepad.exe thành game.exe vẫn phát hiện đúng
    ├── test_offline_sync.py            # Kiểm tra hàng đợi sự kiện ngoại tuyến, khóa chống trùng
    ├── test_server_api.py              # Kiểm tra đăng nhập, tạm khóa 15p, ghép đôi, xóa dữ liệu con
    └── test_transparency.py            # Kiểm tra schema tối thiểu hóa dữ liệu và đối chiếu PRIVACY.md
```

---

## 4. Hướng Dẫn Cài Đặt và Khởi Chạy

### 4.1. Chuẩn bị môi trường
Yêu cầu: Máy tính chạy **Windows 10 hoặc Windows 11 (x64)**, đã cài **Python 3.11+**.

```powershell
# Di chuyển vào thư mục dự án
cd D:\Projects\OGK2.0

# Kích hoạt môi trường ảo Python
.venv\Scripts\Activate.ps1
```

### 4.2. Khởi tạo dữ liệu mẫu
Lệnh sau sẽ tạo tài khoản phụ huynh mẫu, hồ sơ trẻ em và sinh sẵn 7 ngày lịch sử sử dụng để biểu đồ hiển thị ngay:
```powershell
python scripts/seed_database.py
```
- **Tài khoản phụ huynh:** `parent@ogk.local`
- **Mật khẩu:** `ParentPass1234!`

### 4.3. Khởi chạy Máy Chủ Quản Lý (OGK-Server)
```powershell
python scripts/run_server.py
```
Mở trình duyệt truy cập: **`http://127.0.0.1:8000`**

### 4.4. Khởi chạy OGK-Agent trên máy của con
Mở terminal thứ hai:
```powershell
# Chạy dịch vụ Enforcer ngầm
python scripts/run_agent.py

# Chạy giao diện Khay Hệ Thống (System Tray)
python scripts/run_tray.py
```

---

## 5. Bảng Đối Chiếu Tiêu Chí Nghiệm Thu Đồ Án (Demo D1/D2)

| Tiêu chí đánh giá | Yêu cầu của đề bài | Kết quả thực hiện trên OGK 2.0 | Cách thức kiểm chứng |
| :--- | :--- | :--- | :--- |
| **F1. Quota theo ngày** | Đặt quota 3 phút, hệ thống khóa đúng hạn | **ĐẠT (100%)** — Khóa máy chính xác sau 180s + 60s ân hạn | Chạy `demo_quickstart.py` hoặc chỉnh quota 3p trên web |
| **F1. Ma trận lịch tuần** | Lịch tuần 7×48 (30 phút); ngoài giờ bị khóa trong 5s | **ĐẠT (100%)** — Kiểm tra mỗi giây, khóa máy < 5s ngoài khung giờ | Bấm khóa khung giờ hiện tại trên ma trận web |
| **F1. Đếm giờ thực tế** | Dừng đếm khi máy khóa hoặc không thao tác > 5 phút | **ĐẠT (100%)** — Dùng Win32 `GetLastInputInfo` & `OpenInputDesktop` | Sai số ≤ ±30s/giờ |
| **F1. Cảnh báo & Ân hạn** | Cảnh báo trước 10, 5, 1 phút; ân hạn 60 giây lưu bài | **ĐẠT (100%)** — Gửi thông báo pop-up khay và đếm ngược 60s | Quan sát trong `test_policy_enforcement.py` |
| **F1. Chống lùi đồng hồ** | Lùi đồng hồ 3 giờ: quota không giảm, ghi nhận sự kiện | **ĐẠT (100%)** — Đo thời gian bằng `time.monotonic()` bất biến | Chạy test case `test_anti_clock_tampering_setback_3_hours` |
| **F1. Ngân sách ứng dụng** | Học tập không giới hạn, trò chơi 45 phút | **ĐẠT (100%)** — 2 bộ đếm độc lập trong SQLite | Quan sát trong dashboard |
| **F2. Chặn theo SHA-256** | Đổi tên `notepad.exe` thành `game.exe` vẫn nhận diện đúng | **ĐẠT (100%)** — Quét mã băm SHA-256 của file thực thi trên đĩa | Chạy test `test_app_controller.py` |
| **F2. Giải thích lý do** | Kết thúc tiến trình và hiển thị lý do, không im lặng | **ĐẠT (100%)** — Cửa sổ giải thích hiện thị tên app và người đặt luật | Quan sát dialog pop-up |
| **F2. Lọc DNS Proxy** | Lọc tại 127.0.0.1:53, chặn toàn bộ tên miền con; Chặn ≥ 95% bộ 50 miền; 0 dương tính giả trên 20 miền giáo dục | **ĐẠT (100%)** — Chặn **100.0% (50/50)** miền kiểm thử; **0/20** dương tính giả trên miền giáo dục | Chạy test `test_dns_proxy.py` |
| **F2. SafeSearch** | Cưỡng chế SafeSearch bằng bản ghi DNS | **ĐẠT (100%)** — Google -> forcesafesearch, Bing -> strict.bing | Kiểm chứng bằng `nslookup` hoặc test |
| **F2. Miễn chặn 111** | Danh sách miễn chặn vĩnh viễn: Tổng đài 111, .edu.vn | **ĐẠT (100%)** — `tongdai111.vn` luôn cho phép truy cập (NT6) | Kiểm chứng qua `test_permanent_whitelist_nt6` |
| **F3. Minh bạch dữ liệu** | Lược đồ sự kiện chuẩn, không lưu URL đầy đủ; Báo cáo cho cha mẹ và Màn hình "Hôm nay em đã dùng gì" cho con | **ĐẠT (100%)** — Tuân thủ file `PRIVACY.md`; Giao diện trẻ em thân thiện tại `/child/{child_id}` | Xem tại web hoặc chạy `test_transparency.py` |
| **F3. Quyền lãng quên** | Lưu trữ 90 ngày; Nút xóa toàn bộ dữ liệu của con | **ĐẠT (100%)** — Xóa sạch trên server và xóa cache SQLite của agent | Bấm nút "Xóa toàn bộ dữ liệu của con tôi" trên Web |
| **F4. Quản lý từ xa** | 1 Phụ huynh : N Trẻ : M Thiết bị; Lệnh khẩn < 5s qua WebSocket; Ký số toàn vẹn HMAC; Nhật ký kiểm toán | **ĐẠT (100%)** — WebSocket thời gian thực; Chữ ký HMAC từ chối chính sách sửa đổi; Trẻ xem được nhật ký | Bấm các nút "Khóa máy ngay", "Mở khóa", "+15 phút" |
| **F5. Bảo mật F5** | Argon2id, khóa 15p sau 5 lần sai, session 12h, token 15p | **ĐẠT (100%)** — Đạt đầy đủ tiêu chuẩn bảo mật chuyên sâu | Chạy test `test_server_api.py` |

---

## 6. Chạy Kiểm Thử Tự Động (Automated Testing)

Toàn bộ hệ thống đi kèm **21 kịch bản kiểm thử tự động** bao phủ tất cả chức năng:

```powershell
# Chạy toàn bộ 21 tests
python -m pytest tests/ -v
```

Kết quả thực tế:
```text
tests/test_app_controller.py::test_renamed_binary_sha256_detection PASSED
tests/test_crypto.py::test_argon2id_password_hashing PASSED
tests/test_crypto.py::test_password_length_requirement PASSED
tests/test_crypto.py::test_hmac_policy_signing_and_tamper_detection PASSED
tests/test_crypto.py::test_file_sha256_hash PASSED
tests/test_crypto.py::test_aes_gcm_encryption_and_decryption PASSED
tests/test_dns_proxy.py::test_zero_false_positives_on_20_education_domains PASSED
tests/test_dns_proxy.py::test_blocked_at_least_95_percent_on_50_test_domains PASSED
tests/test_dns_proxy.py::test_safesearch_dns_enforcement PASSED
tests/test_dns_proxy.py::test_permanent_whitelist_nt6 PASSED
tests/test_dns_proxy.py::test_subdomain_wildcard_matching PASSED
tests/test_offline_sync.py::test_offline_event_queueing_and_idempotency PASSED
tests/test_policy_enforcement.py::test_daily_quota_3_minutes_lock PASSED
tests/test_policy_enforcement.py::test_schedule_matrix_lock_within_5_seconds PASSED
tests/test_policy_enforcement.py::test_anti_clock_tampering_setback_3_hours PASSED
tests/test_policy_enforcement.py::test_app_group_budgets_independent PASSED
tests/test_server_api.py::test_parent_auth_and_15min_lockout_after_5_fails PASSED
tests/test_server_api.py::test_enrollment_and_device_lifecycle PASSED
tests/test_transparency.py::test_data_minimization_sanitize_subject PASSED
tests/test_transparency.py::test_event_schema_matches_privacy_md PASSED
tests/test_transparency.py::test_event_types_strictly_match_f3_specification PASSED

======================== 21 passed in 6.44s (100% SUCCESS) ========================
```

---

## 7. Giải Trình Kỹ Thuật Khi Vấn Đáp (Defense Q&A)

### Câu hỏi 1: Lựa chọn Fail-Open hay Fail-Closed sau N ngày mất kết nối và căn cứ bảo vệ?
> **Trả lời:** Nhóm lựa chọn cơ chế **Fail-Closed an toàn có kiểm soát** (mặc định sau 7 ngày mất kết nối với máy chủ).  
> **Căn cứ bảo vệ:**
> 1. Về mặt bảo vệ trẻ: Nếu chọn fail-open sau N ngày, trẻ có thể cố tình rút dây mạng hoặc ngắt kết nối để vượt rào sau 7 ngày.
> 2. Về mặt quyền lợi và học tập: Trong trạng thái fail-closed sau khi hết hạn, hệ thống vẫn duy trì **Danh sách miễn chặn vĩnh viễn (NT6)** bao gồm các cổng học tập trực tuyến `.edu.vn`, `chinhphu.vn` và Tổng đài quốc gia 111 (`tongdai111.vn`). Trẻ vẫn học tập bình thường và có thể liên hệ trợ giúp khẩn cấp. Phụ huynh cũng có thể cấu hình chuyển sang `fail_open_after_expiry: true` trên giao diện nếu gia đình đi công tác dài ngày.

### Câu hỏi 2: Điểm ghi nhận sự đồng ý của cha mẹ theo Nghị định 13/2023 nằm ở đâu?
> **Trả lời:** Nằm tại quy trình **Ghép đôi (Enrollment)**. Phụ huynh đăng nhập vào Dashboard bằng xác thực Argon2id, chủ động bấm tạo mã ghép đôi 8 ký tự (có hiệu lực 10 phút). Khi Agent nhập mã này, máy chủ xác nhận sự đồng thuận rõ ràng của phụ huynh trước khi cấp `device_id` và token giám sát.

### Câu hỏi 3: Làm thế nào đảm bảo độ trễ lệnh khẩn cấp dưới 5 giây?
> **Trả lời:** OGK-Agent duy trì một kết nối **WebSocket hai chiều** liên tục (`/ws/agent/{device_id}`). Khi phụ huynh bấm *"Khóa máy ngay"*, *"Mở khóa"* hoặc *"+15 phút"* trên Web Dashboard, máy chủ đẩy gói tin JSON trực tiếp qua WebSocket xuống Agent. Agent nhận được trong vòng **dưới 100 mili-giây** (thấp hơn nhiều so với giới hạn 5 giây của đề bài). Cơ chế Heartbeat định kỳ 3 giây đóng vai trò dự phòng và truyền trực tiếp dữ liệu thời gian thực.

### Câu hỏi 4: Tại sao DNS Proxy cần tắt Secure DNS (DoH) trên trình duyệt để chặn thực tế?
> **Trả lời:** Các trình duyệt hiện đại (Chrome, Edge, Firefox) kích hoạt tính năng **Secure DNS (DoH - DNS over HTTPS)** ngầm định. Khi bật DoH, trình duyệt hoàn toàn bỏ qua DNS cấu hình của Windows Network Adapter và gửi truy vấn mã hóa TLS (cổng 443) thẳng tới máy chủ Cloudflare/Google.  
> Để DNS Proxy cục bộ (`127.0.0.1:53`) lọc được trong trình duyệt thực tế:
> 1. Trỏ DNS Card mạng Windows sang `127.0.0.1` bằng `python scripts/configure_dns.py enable`.
> 2. Tắt *"Sử dụng DNS an toàn"* trong Cài đặt trình duyệt (hoặc dùng tiện ích kiểm tra `nslookup <domain> 127.0.0.1`). Proxy sẽ lập tức chặn tên miền con, cưỡng chế SafeSearch Google/Bing và cho phép danh mục khẩn cấp NT6 vĩnh viễn.
