"""Unit tests for Offline Event Queue and Idempotency Key Deduplication (F3 & 2.3).
Verifies:
- Events buffered locally in SQLite when offline
- Unique idempotency keys prevent duplicate counting
- Batch removal upon successful sync
- Local cache wipe (Right to be forgotten)
"""

import time
import pytest
from ogk_shared.constants import EventType
from ogk_agent.local_cache import (
    init_local_db, queue_event, fetch_queued_events, remove_synced_events, wipe_local_cache
)


@pytest.fixture(autouse=True)
def setup_db():
    init_local_db()
    wipe_local_cache()


def test_offline_event_queueing_and_idempotency():
    # 1. Queue events offline
    key1 = queue_event(
        device_id="dev_sync_01",
        child_id="child_sync_01",
        event_type=EventType.APP_START.value,
        subject="scratch.exe",
        duration_sec=0,
        policy_id="pol_sync"
    )
    key2 = queue_event(
        device_id="dev_sync_01",
        child_id="child_sync_01",
        event_type=EventType.DOMAIN_QUERY.value,
        subject="khanacademy.org",
        duration_sec=0,
        policy_id="pol_sync"
    )

    assert isinstance(key1, str) and len(key1) > 10
    assert isinstance(key2, str) and len(key2) > 10
    assert key1 != key2

    # 2. Fetch queued batch
    batch = fetch_queued_events(limit=50)
    assert len(batch) == 2
    assert batch[0]["idempotency_key"] == key1
    assert batch[1]["idempotency_key"] == key2
    assert batch[0]["subject"] == "scratch.exe"

    # 3. Simulate successful server sync -> remove synced keys
    remove_synced_events([key1])
    remaining = fetch_queued_events(limit=50)
    assert len(remaining) == 1
    assert remaining[0]["idempotency_key"] == key2

    # 4. Wipe local cache test (Right to be Forgotten)
    wipe_local_cache()
    assert len(fetch_queued_events(limit=50)) == 0
