"""Unit tests for cryptographic utilities.
F5 Requirements:
- Argon2id password hashing
- HMAC-SHA256 policy integrity signing and tamper rejection
- SHA-256 binary file hashing
- AES-256-GCM encryption/decryption
"""

import os
import tempfile
import pytest
from ogk_shared.crypto import (
    hash_password, verify_password, sign_policy, verify_policy_signature,
    compute_file_sha256, encrypt_aes_gcm, decrypt_aes_gcm, derive_key
)


def test_argon2id_password_hashing():
    pwd = "ValidPassword123!"
    h = hash_password(pwd)
    assert h.startswith("$argon2id$")
    assert verify_password(h, pwd) is True
    assert verify_password(h, "WrongPassword!") is False


def test_password_length_requirement():
    # Minimum 10 characters required by F5
    with pytest.raises(ValueError, match="tối thiểu 10 ký tự"):
        hash_password("short9")


def test_hmac_policy_signing_and_tamper_detection():
    secret = "test_device_secret_key_32_bytes_hex"
    policy = {
        "policy_id": "pol_123",
        "version": 1,
        "child_id": "child_001",
        "daily_quota_minutes_weekday": 90,
        "blocked_categories": ["inappropriate", "gaming"]
    }

    sig = sign_policy(policy, secret)
    assert isinstance(sig, str) and len(sig) == 64  # SHA-256 hex string

    # Verification succeeds
    assert verify_policy_signature(policy, sig, secret) is True

    # Tampered policy must be rejected!
    tampered_policy = policy.copy()
    tampered_policy["daily_quota_minutes_weekday"] = 999  # Attacker changed quota
    assert verify_policy_signature(tampered_policy, sig, secret) is False

    # Wrong secret key must fail
    assert verify_policy_signature(policy, sig, "wrong_secret_key") is False


def test_file_sha256_hash():
    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tf.write(b"Open Guardian for Kids 2.0 Test Binary")
        tf_path = tf.name

    try:
        h = compute_file_sha256(tf_path)
        assert isinstance(h, str) and len(h) == 64
        # Hash must match known hashlib output
        import hashlib
        expected = hashlib.sha256(b"Open Guardian for Kids 2.0 Test Binary").hexdigest()
        assert h == expected
    finally:
        os.remove(tf_path)


def test_aes_gcm_encryption_and_decryption():
    key = derive_key("master_agent_secret_key")
    plaintext = "Sensitive child device token data 2026"

    nonce, ciphertext = encrypt_aes_gcm(plaintext, key)
    assert len(nonce) == 12  # 96-bit nonce
    assert ciphertext != plaintext.encode("utf-8")

    decrypted = decrypt_aes_gcm(nonce, ciphertext, key)
    assert decrypted == plaintext

    # Tampered ciphertext must fail authentication
    tampered = bytearray(ciphertext)
    tampered[0] ^= 0xFF
    with pytest.raises(Exception):
        decrypt_aes_gcm(nonce, bytes(tampered), key)
