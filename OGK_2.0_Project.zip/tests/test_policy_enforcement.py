"""Unit tests for Screen Time Counter and Policy Enforcement Engine (F1).
Verifies:
- Daily quota (3 minutes lock criterion)
- 7x48 schedule matrix restriction
- Anti-clock-tampering with monotonic clock (3 hours setback)
- 10, 5, 1 minute warnings and 60s grace period
- App group budgets (gaming vs education)
"""

import time
import datetime
import pytest
from ogk_shared.constants import Category
from ogk_agent.screen_time import ScreenTimeManager
from ogk_agent.local_cache import init_local_db, get_daily_usage, record_time_tick


@pytest.fixture(autouse=True)
def setup_test_cache():
    init_local_db()


def test_daily_quota_3_minutes_lock():
    """Acceptance criterion: 'Đặt quota 3 phút, hệ thống khóa đúng hạn'."""
    locked_reasons = []

    def mock_lock(reason):
        locked_reasons.append(reason)

    manager = ScreenTimeManager(
        device_id="test_dev_01",
        child_id="test_child_01",
        on_lock=mock_lock,
        simulate_lock=True
    )

    # Policy with 3 minutes quota (180 seconds)
    policy = {
        "policy_id": "test_pol",
        "daily_quota_minutes_weekday": 3,
        "daily_quota_minutes_weekend": 3,
        "schedule": {"matrix": [[1]*48 for _ in range(7)]},
        "app_group_budgets": {"gaming": 45}
    }
    manager.update_policy(policy)

    # Initial state: remaining should be 180s
    assert manager.get_remaining_seconds() == 180

    # Simulate ticking 170 seconds
    for _ in range(170):
        manager.tick(delta_seconds=1.0)

    # Remaining should be 10 seconds
    assert manager.get_remaining_seconds() == 10
    assert len(locked_reasons) == 0

    # Tick 10 more seconds to reach 180s (quota finished)
    for _ in range(10):
        manager.tick(delta_seconds=1.0)

    assert manager.get_remaining_seconds() == 0
    # Enters 60-second grace period to save work
    assert manager.in_grace_period is True

    # Advance grace period by setting grace_period_start back 61 seconds
    manager.grace_period_start = time.monotonic() - 61.0
    manager.tick(delta_seconds=1.0)

    # Lock must be triggered!
    assert len(locked_reasons) == 1
    assert "hết hạn mức" in locked_reasons[0].lower()


def test_schedule_matrix_lock_within_5_seconds():
    """Acceptance criterion: 'Ngoài khung giờ cho phép, máy bị khóa trong 5 giây'."""
    locked_reasons = []

    manager = ScreenTimeManager(
        device_id="test_dev_02",
        child_id="test_child_02",
        on_lock=lambda r: locked_reasons.append(r),
        simulate_lock=True
    )

    # All slots locked (matrix of zeros)
    policy = {
        "policy_id": "locked_pol",
        "daily_quota_minutes_weekday": 90,
        "daily_quota_minutes_weekend": 120,
        "schedule": {"matrix": [[0]*48 for _ in range(7)]}
    }
    manager.update_policy(policy)

    # Should detect outside schedule immediately
    assert manager.is_outside_schedule() is True

    # Tick 1 second -> lock triggered immediately!
    manager.tick(delta_seconds=1.0)
    assert len(locked_reasons) >= 1
    assert "lịch tuần" in locked_reasons[0].lower()


def test_anti_clock_tampering_setback_3_hours():
    """Acceptance criterion: 'Lùi đồng hồ 3 giờ: quota không được tăng, sự kiện bị ghi nhận'."""
    manager = ScreenTimeManager(
        device_id="test_dev_03",
        child_id="test_child_03",
        simulate_lock=True
    )
    policy = {
        "policy_id": "anti_tamper_pol",
        "daily_quota_minutes_weekday": 60,
        "schedule": {"matrix": [[1]*48 for _ in range(7)]}
    }
    manager.update_policy(policy)

    today_str = datetime.date.today().isoformat()
    # Spend 20 minutes (1200 seconds)
    record_time_tick(1200, today_str)

    used_before = get_daily_usage(today_str)["used_seconds"]
    assert used_before >= 1200

    # Simulate child rolling back system clock by 3 hours (10,800 seconds)
    manager.last_tick_wall = time.time() + 10800  # Wall clock appears 3 hours earlier now

    # Run tick
    manager.tick(delta_seconds=1.0)

    # Clock tampering must be detected!
    assert manager.clock_tampered is True

    # Quota used must NOT decrease or reset!
    used_after = get_daily_usage(today_str)["used_seconds"]
    assert used_after >= used_before


def test_app_group_budgets_independent():
    """NÊN CÓ: Ngân sách theo nhóm ứng dụng (học tập không giới hạn, trò chơi 45 phút)."""
    manager = ScreenTimeManager(
        device_id="test_dev_04",
        child_id="test_child_04",
        simulate_lock=True
    )
    policy = {
        "policy_id": "budget_pol",
        "daily_quota_minutes_weekday": 180,
        "schedule": {"matrix": [[1]*48 for _ in range(7)]},
        "app_group_budgets": {
            Category.GAMING.value: 45,       # 45 minutes limit
            Category.EDUCATION.value: -1     # Unlimited
        }
    }
    manager.update_policy(policy)

    today_str = datetime.date.today().isoformat()

    # 1. Active in education -> only adds to general quota, not gaming
    manager.is_gaming_active = False
    manager.tick(delta_seconds=60.0)

    res = manager.tick(delta_seconds=1.0)
    assert res["gaming_seconds"] == 0
    assert res["gaming_exceeded"] is False

    # 2. Active in gaming -> adds to gaming quota
    manager.is_gaming_active = True
    record_time_tick(46 * 60, today_str, is_gaming=True)  # 46 minutes of gaming

    res2 = manager.tick(delta_seconds=1.0)
    assert res2["gaming_seconds"] >= 45 * 60
    assert res2["gaming_exceeded"] is True
