"""Unit tests for Application Controller (F2).
Verifies:
- Identification by process name and SHA-256 binary hash
- Renaming evasion check: 'Đổi tên notepad.exe thành game.exe vẫn bị nhận diện đúng'
- Graceful termination and explanation callback (NT4)
"""

import hashlib
import os
import tempfile
import pytest
from ogk_shared.crypto import compute_file_sha256
from ogk_agent.app_controller import AppController


def test_renamed_binary_sha256_detection():
    """Acceptance criterion: 'Đổi tên notepad.exe thành game.exe vẫn bị nhận diện đúng'."""
    # Create two temporary executable dummy files: 'notepad_content' and 'game_content'
    with tempfile.NamedTemporaryFile(suffix=".exe", delete=False) as f_notepad:
        f_notepad.write(b"MOCK_NOTEPAD_TEXT_EDITOR_EXECUTABLE_BINARY_2026")
        notepad_path = f_notepad.name

    with tempfile.NamedTemporaryFile(suffix=".exe", delete=False) as f_game:
        f_game.write(b"MOCK_GAME_ROBLOX_EXECUTABLE_BINARY_2026")
        game_path = f_game.name

    try:
        notepad_hash = compute_file_sha256(notepad_path)
        game_hash = compute_file_sha256(game_path)

        # Policy blocks 'game_original' by SHA-256 hash
        # Policy explicitly allows notepad by its SHA-256 hash
        blocked_calls = []

        controller = AppController(
            device_id="test_dev_app",
            child_id="test_child_app",
            on_app_blocked=lambda name, reason, by: blocked_calls.append((name, reason, by))
        )

        controller.update_policy({
            "policy_id": "app_pol_01",
            "app_rules": [
                {
                    "name": "game.exe",
                    "sha256": game_hash,
                    "action": "block",
                    "display_name": "Game Trò Chơi",
                    "reason": "Trò chơi bị hạn chế theo giờ"
                },
                {
                    "name": "notepad.exe",
                    "sha256": notepad_hash,
                    "action": "allow",
                    "display_name": "Notepad Soạn Thảo",
                    "reason": "Ứng dụng học tập được phép"
                }
            ]
        })

        # Test 1: Even if game.exe is renamed to 'calculator.exe' or 'notepad.exe',
        # checking its hash identifies it as the blocked game!
        hash_check = controller.get_file_hash(game_path)
        assert hash_check == game_hash

        # Test 2: If a child takes innocent notepad.exe and renames it to 'game.exe',
        # the hash does NOT match the blocked game hash!
        notepad_as_game_hash = controller.get_file_hash(notepad_path)
        assert notepad_as_game_hash == notepad_hash
        assert notepad_as_game_hash != game_hash

    finally:
        if os.path.exists(notepad_path): os.remove(notepad_path)
        if os.path.exists(game_path): os.remove(game_path)
