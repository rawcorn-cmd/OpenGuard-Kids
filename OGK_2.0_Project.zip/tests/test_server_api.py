"""Integration tests for OGK-Server REST API using live HTTP client.
Verifies:
- Parent registration and login with Argon2id
- 15-minute temporary lockout after 5 consecutive failed logins
- 8-character enrollment code generation & expiration
- Device enrollment with fingerprint and token issuance
- Audit log tracking of parent changes
- Right to be Forgotten ('Xóa toàn bộ dữ liệu của con tôi')
"""

import os
import threading
import time
import httpx
import pytest
import uvicorn
from ogk_server.main import app
from ogk_server.database import init_db, SessionLocal, EventModel
from ogk_shared.constants import EventType

TEST_PORT = 8011
TEST_BASE_URL = f"http://127.0.0.1:{TEST_PORT}"


@pytest.fixture(scope="module")
def live_server():
    init_db()
    config = uvicorn.Config(app, host="127.0.0.1", port=TEST_PORT, log_level="warning")
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    time.sleep(1.0)  # Wait for server to bind
    yield TEST_BASE_URL
    server.should_exit = True


def test_parent_auth_and_15min_lockout_after_5_fails(live_server):
    email = f"parent_{int(time.time())}@example.com"
    pwd = "ValidPassword123!"

    with httpx.Client(base_url=live_server) as client:
        # 1. Register parent account
        reg_res = client.post("/api/auth/register", json={
            "email": email,
            "password": pwd,
            "full_name": "Nguyen Van Test"
        })
        assert reg_res.status_code == 201

        # 2. Try wrong password 5 times
        for i in range(1, 5):
            fail_res = client.post("/api/auth/login", json={"email": email, "password": "WrongPassword1!"})
            assert fail_res.status_code == 401
            assert "còn" in fail_res.json()["detail"].lower()

        # 5th attempt must trigger 15-minute lockout!
        fifth_res = client.post("/api/auth/login", json={"email": email, "password": "WrongPassword1!"})
        assert fifth_res.status_code == 403
        assert "tạm khóa 15 phút" in fifth_res.json()["detail"].lower()

        # Even with correct password, account remains locked during the 15-minute window
        locked_attempt = client.post("/api/auth/login", json={"email": email, "password": pwd})
        assert locked_attempt.status_code == 403
        assert "tạm khóa" in locked_attempt.json()["detail"].lower()


def test_enrollment_and_device_lifecycle(live_server):
    email = f"enroll_parent_{int(time.time())}@example.com"
    pwd = "SecureParentPassword123!"

    with httpx.Client(base_url=live_server) as client:
        # Register and login a fresh parent
        client.post("/api/auth/register", json={"email": email, "password": pwd, "full_name": "Phu Huynh 2"})
        login_res = client.post("/api/auth/login", json={"email": email, "password": pwd})
        assert login_res.status_code == 200

        # Create child profile
        child_res = client.post("/api/children", json={"name": "Be Lan", "age": 8})
        assert child_res.status_code == 201
        child_id = child_res.json()["child_id"]

        # 1. Parent generates 8-char enrollment code
        code_res = client.post("/api/enroll/create-code", json={"child_id": child_id})
        assert code_res.status_code == 200
        code = code_res.json()["code"]
        assert len(code) == 8

        # 2. Agent pairs with code
        agent_res = client.post("/api/enroll/agent", json={
            "code": code,
            "device_fingerprint": "fp_test_unit_001",
            "hostname": "DESKTOP-LAN",
            "os_version": "Windows 11 x64"
        })
        assert agent_res.status_code == 200
        agent_data = agent_res.json()
        device_id = agent_data["device_id"]
        access_token = agent_data["access_token"]
        assert device_id is not None
        assert access_token is not None

        # Code cannot be reused
        reuse_res = client.post("/api/enroll/agent", json={
            "code": code,
            "device_fingerprint": "fp_test_unit_002",
            "hostname": "DESKTOP-LAN-2",
            "os_version": "Windows 11 x64"
        })
        assert reuse_res.status_code == 400

        # 3. Agent sends batch events with access token
        events_payload = {
            "events": [
                {
                    "ts": time.time(),
                    "device_id": device_id,
                    "child_id": child_id,
                    "type": EventType.APP_START.value,
                    "subject": "code.exe",
                    "duration_sec": 300,
                    "policy_id": "pol_lan",
                    "idempotency_key": f"idem_unit_{time.time()}"
                }
            ]
        }
        batch_res = client.post(
            "/api/events/batch",
            json=events_payload,
            headers={"X-OGK-Token": access_token}
        )
        assert batch_res.status_code == 200
        assert batch_res.json()["processed"] == 1

        # Sending the same event again must be deduplicated by idempotency key!
        batch_res_dup = client.post(
            "/api/events/batch",
            json=events_payload,
            headers={"X-OGK-Token": access_token}
        )
        assert batch_res_dup.json()["skipped_duplicate"] == 1

        # 4. Right to be Forgotten: Wipe all child data
        wipe_res = client.post(f"/api/retention/wipe-child-data/{child_id}")
        assert wipe_res.status_code == 200
        assert "Đã xóa toàn bộ" in wipe_res.json()["message"]

        # Verify events deleted from server DB
        db = SessionLocal()
        ev_count = db.query(EventModel).filter(EventModel.child_id == child_id).count()
        db.close()
        assert ev_count == 0
