"""Tests for real-time live telemetry, idle pause detection, and DNS evaluation endpoint.
"""

import time
import pytest
from ogk_shared.constants import Category
from ogk_agent.screen_time import ScreenTimeManager
from ogk_agent.local_cache import init_local_db, get_daily_usage, record_time_tick
from ogk_agent.dns_proxy import DNSFilterProxy


def test_idle_detection_pauses_screen_time_ticks():
    init_local_db()
    today_str = time.strftime("%Y-%m-%d")
    
    # Manager with 5 second idle threshold
    manager = ScreenTimeManager(
        device_id="test_idle_dev",
        child_id="test_idle_child",
        simulate_lock=True,
        idle_timeout_seconds=5.0
    )
    manager.update_policy({
        "version": 1,
        "daily_quota_minutes_weekday": 120,
        "daily_quota_minutes_weekend": 120,
        "schedule": {"matrix": [[1] * 48 for _ in range(7)]}
    })

    # Test tick result has idle fields
    res = manager.tick(delta_seconds=1.0)
    assert "idle_seconds" in res
    assert "is_idle" in res
    assert "is_active" in res
    assert isinstance(res["idle_seconds"], (int, float))


def test_dns_proxy_live_recent_queries_ring_buffer():
    proxy = DNSFilterProxy(device_id="dev1", child_id="ch1", dataset_path="test_dataset.json")
    
    # Evaluate domain
    eval_blocked = proxy.evaluate_domain("tiktok.com")
    assert eval_blocked["action"] == "block"
    assert "Mạng xã hội" in eval_blocked["reason"]

    eval_allowed = proxy.evaluate_domain("scratch.mit.edu")
    assert eval_allowed["action"] == "allow"

    eval_safesearch = proxy.evaluate_domain("google.com")
    assert eval_safesearch["action"] == "safesearch"

    eval_whitelist = proxy.evaluate_domain("tongdai111.vn")
    assert eval_whitelist["action"] == "allow"
    assert "NT6" in eval_whitelist["reason"]
