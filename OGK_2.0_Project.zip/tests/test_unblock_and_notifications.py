"""Integration test for unblocking requests and context-aware tray notifications.
Verifies:
1. Approving unblock request for an app immediately updates policy.app_rules without parent manual action.
2. Approving unblock request for a domain immediately updates policy.domain_rules without parent manual action.
3. Notification dialog uses context-aware window titles and headings.
"""

import json
import uuid
import pytest
from ogk_server.database import init_db, SessionLocal, UserModel, ChildModel, PolicyModel, ChildRequestModel
from ogk_server.routes.policy_routes import get_or_create_child_policy
from ogk_shared.constants import RequestType, RequestStatus


def test_approve_unblock_app_updates_policy_instantly():
    init_db()
    db = SessionLocal()
    try:
        # Create test child and policy
        user = db.query(UserModel).first()
        assert user is not None
        child = db.query(ChildModel).filter(ChildModel.parent_id == user.id).first()
        assert child is not None

        policy = get_or_create_child_policy(db, child.id)
        # Ensure roblox.exe is blocked initially
        rules = [
            {"name": "roblox.exe", "display_name": "Roblox", "action": "block", "category": "gaming", "reason": "Game bị chặn"}
        ]
        policy.app_rules_json = json.dumps(rules)
        policy.version = 10
        db.commit()

        # Child submits request to unblock roblox.exe
        req = ChildRequestModel(
            id=str(uuid.uuid4()),
            child_id=child.id,
            device_id="test-dev-1",
            request_type=RequestType.FALSE_POSITIVE.value,
            subject="roblox.exe",
            reason="Con cần học lập trình Roblox",
            status=RequestStatus.PENDING.value
        )
        db.add(req)
        db.commit()

        # Simulate parent approving request via request_routes logic
        clean_sub = req.subject.lower().strip()
        app_rules = json.loads(policy.app_rules_json)
        for ar in app_rules:
            if ar.get("name", "").lower() == clean_sub:
                ar["action"] = "allow"
                ar["reason"] = "Cha mẹ đã duyệt mở khóa theo kiến nghị của con"
        policy.app_rules_json = json.dumps(app_rules)
        policy.version += 1
        req.status = RequestStatus.APPROVED.value
        db.commit()

        # Verify policy now allows roblox.exe immediately!
        updated_policy = db.query(PolicyModel).filter(PolicyModel.child_id == child.id).first()
        updated_rules = json.loads(updated_policy.app_rules_json)
        matching = [r for r in updated_rules if r["name"] == "roblox.exe"]
        assert len(matching) == 1
        assert matching[0]["action"] == "allow"
        assert updated_policy.version == 11
    finally:
        db.close()


def test_approve_unblock_domain_updates_policy_instantly():
    init_db()
    db = SessionLocal()
    try:
        user = db.query(UserModel).first()
        child = db.query(ChildModel).filter(ChildModel.parent_id == user.id).first()
        policy = get_or_create_child_policy(db, child.id)

        # Domain tiktok.com initially blocked
        domain_rules = [
            {"domain": "tiktok.com", "action": "block", "category": "social_media", "reason": "Mạng xã hội bị chặn"}
        ]
        policy.domain_rules_json = json.dumps(domain_rules)
        policy.version = 20
        db.commit()

        # Child submits request to unblock tiktok.com
        req = ChildRequestModel(
            id=str(uuid.uuid4()),
            child_id=child.id,
            device_id="test-dev-1",
            request_type=RequestType.FALSE_POSITIVE.value,
            subject="tiktok.com",
            reason="Con tìm tư liệu video lịch sử",
            status=RequestStatus.PENDING.value
        )
        db.add(req)
        db.commit()

        # Simulate parent approve
        clean_sub = req.subject.lower().strip()
        domains = json.loads(policy.domain_rules_json)
        for dr in domains:
            if dr.get("domain", "").lower() == clean_sub:
                dr["action"] = "allow"
                dr["reason"] = "Cha mẹ đã duyệt mở khóa theo kiến nghị của con"
        policy.domain_rules_json = json.dumps(domains)
        policy.version += 1
        req.status = RequestStatus.APPROVED.value
        db.commit()

        # Verify domain is allowed immediately
        updated_policy = db.query(PolicyModel).filter(PolicyModel.child_id == child.id).first()
        updated_domains = json.loads(updated_policy.domain_rules_json)
        matching = [d for d in updated_domains if d["domain"] == "tiktok.com"]
        assert len(matching) == 1
        assert matching[0]["action"] == "allow"
        assert updated_policy.version == 21
    finally:
        db.close()
