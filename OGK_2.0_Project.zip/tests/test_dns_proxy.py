"""Unit tests for DNS Proxy and Website Filtering (F2 & NT6).
Verifies:
- 0 false positives on 20 educational domains (NT6 & F2 criterion)
- >= 95% blocked on 50 test domains (F2 criterion)
- SafeSearch DNS rewriting (Google, Bing, DuckDuckGo, YouTube)
- Subdomain wildcard blocking (*.badgame.com)
"""

import json
import os
import pytest
from dnslib import DNSRecord, QTYPE
from ogk_shared.constants import Category
from ogk_agent.dns_proxy import DNSFilterProxy, match_domain_or_subdomain


@pytest.fixture
def dns_filter():
    # Load dataset from test_dataset.json
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dataset_path = os.path.join(base_dir, "test_dataset.json")

    filter_proxy = DNSFilterProxy(
        device_id="test_dev_dns",
        child_id="test_child_dns",
        dataset_path=dataset_path
    )

    # Standard age 6-11 policy: Inappropriate, Social Media, Gaming blocked
    policy = {
        "policy_id": "dns_test_pol",
        "blocked_categories": [
            Category.INAPPROPRIATE.value,
            Category.SOCIAL_MEDIA.value,
            Category.GAMING.value
        ],
        "allowed_categories": [Category.EDUCATION.value, Category.ENTERTAINMENT.value],
        "domain_rules": [
            {"domain": "badgame.com", "action": "block", "reason": "Trò chơi bị hạn chế"},
            {"domain": "allowed-game.com", "action": "allow", "reason": "Được cha mẹ mở khóa"}
        ],
        "safesearch_enforced": True
    }
    filter_proxy.update_policy(policy)
    return filter_proxy


def test_zero_false_positives_on_20_education_domains(dns_filter):
    """BẮT BUỘC Acceptance Criterion: '0 dương tính giả trên 20 tên miền giáo dục'."""
    education_domains_20 = [
        "scratch.mit.edu",
        "khanacademy.org",
        "duolingo.com",
        "wikipedia.org",
        "vi.wikipedia.org",
        "coursera.org",
        "edx.org",
        "hoidap247.com",
        "vietjack.com",
        "loigiaihay.com",
        "vndoc.com",
        "olm.vn",
        "hocmai.vn",
        "tuyensinh247.com",
        "ioe.vn",
        "vio.edu.vn",
        "w3schools.com",
        "geogebra.org",
        "quizlet.com",
        "stem.vn"
    ]
    assert len(education_domains_20) == 20

    false_positives = []
    for domain in education_domains_20:
        res = dns_filter.evaluate_domain(domain)
        if res["action"] == "block":
            false_positives.append((domain, res))

    # Must have EXACTLY 0 false positives!
    assert len(false_positives) == 0, f"Dương tính giả phát hiện: {false_positives}"


def test_blocked_at_least_95_percent_on_50_test_domains(dns_filter):
    """BẮT BUỘC Acceptance Criterion: 'Chặn >= 95% trong bộ 50 tên miền kiểm thử'."""
    # 50 target domains that SHOULD be blocked for age 6-11 (Social media, Gaming, Inappropriate)
    test_50_domains = [
        # Social Media (20)
        "tiktok.com", "m.tiktok.com", "facebook.com", "www.facebook.com", "instagram.com",
        "twitter.com", "x.com", "snapchat.com", "reddit.com", "threads.net",
        "pinterest.com", "weibo.com", "discord.com", "tumblr.com", "vk.com",
        "telegram.org", "zalo.me", "viber.com", "whatsapp.com", "line.me",
        # Gaming (15)
        "roblox.com", "api.roblox.com", "minecraft.net", "steampowered.com", "epicgames.com",
        "riotgames.com", "poki.com", "crazygames.com", "krunker.io", "slither.io",
        "agar.io", "supercell.com", "y8.com", "gamevui.vn", "badgame.com",
        # Inappropriate / Simulated neutral test blocked domains (15)
        "test-blocked-violence.local", "sub.test-blocked-violence.local",
        "test-blocked-gambling.example.org", "casino.test-blocked-gambling.example.org",
        "test-blocked-weapons.test", "test-blocked-adult-simulated.local",
        "test-blocked-drugs.example", "test-blocked-hate.test",
        "test-malware-testsite.example.com", "test-phishing-demo.local",
        "test-blocked-casino.test", "test-blocked-betting.example",
        "test-inappropriate-1.example.org", "test-inappropriate-2.example.org",
        "test-inappropriate-3.example.org"
    ]
    assert len(test_50_domains) == 50

    blocked_count = 0
    unblocked = []
    for domain in test_50_domains:
        res = dns_filter.evaluate_domain(domain)
        if res["action"] == "block":
            blocked_count += 1
        else:
            unblocked.append((domain, res))

    block_rate = (blocked_count / len(test_50_domains)) * 100
    print(f"Block rate: {block_rate}% ({blocked_count}/{len(test_50_domains)})")

    # Criterion: >= 95%
    assert block_rate >= 95.0, f"Block rate {block_rate}% is below 95%. Unblocked: {unblocked}"


def test_safesearch_dns_enforcement(dns_filter):
    """BẮT BUỘC Acceptance Criterion: 'Cưỡng chế SafeSearch của công cụ tìm kiếm bằng bản ghi DNS'."""
    # 1. Google
    google_res = dns_filter.evaluate_domain("www.google.com")
    assert google_res["action"] == "safesearch"
    assert google_res["ip"] == "216.239.38.120"
    assert "forcesafesearch" in google_res["cname"]

    # 2. Bing
    bing_res = dns_filter.evaluate_domain("www.bing.com")
    assert bing_res["action"] == "safesearch"
    assert bing_res["ip"] == "204.79.197.220"

    # 3. DuckDuckGo
    ddg_res = dns_filter.evaluate_domain("duckduckgo.com")
    assert ddg_res["action"] == "safesearch"
    assert ddg_res["ip"] == "52.149.246.39"

    # 4. YouTube
    yt_res = dns_filter.evaluate_domain("www.youtube.com")
    assert yt_res["action"] == "safesearch"
    assert "restrict.youtube.com" in yt_res["cname"]

    # Check DNS response packet construction
    query_pkt = DNSRecord.question("www.google.com", "A").pack()
    resp_bytes = dns_filter.process_dns_query(query_pkt, ("127.0.0.1", 12345))
    resp = DNSRecord.parse(resp_bytes)
    assert len(resp.rr) >= 1
    assert str(resp.rr[0].rdata) == "216.239.38.120"


def test_permanent_whitelist_nt6(dns_filter):
    """NT6: Danh sách miễn chặn vĩnh viễn (Tổng đài 111, .edu.vn, cổng chính phủ)."""
    assert dns_filter.is_permanently_whitelisted("tongdai111.vn") is True
    assert dns_filter.is_permanently_whitelisted("hotline.tongdai111.vn") is True
    assert dns_filter.is_permanently_whitelisted("cucbaovetreem.gov.vn") is True
    assert dns_filter.is_permanently_whitelisted("thpt-chuyenhanoi.edu.vn") is True
    assert dns_filter.is_permanently_whitelisted("chinhphu.vn") is True

    # Even if an admin mistakenly adds a block rule for 111, permanent whitelist takes absolute precedence!
    res = dns_filter.evaluate_domain("tongdai111.vn")
    assert res["action"] == "allow"
    assert "NT6" in res["reason"]


def test_subdomain_wildcard_matching(dns_filter):
    """Verifies that blocking a domain also blocks all its subdomains."""
    assert dns_filter.evaluate_domain("badgame.com")["action"] == "block"
    assert dns_filter.evaluate_domain("www.badgame.com")["action"] == "block"
    assert dns_filter.evaluate_domain("api.server.badgame.com")["action"] == "block"
