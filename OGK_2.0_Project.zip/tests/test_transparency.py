"""Unit and integration tests for Transparency and Data Minimization (NT1 - NT6).
Verifies:
- NT2: Strict metadata minimization (No full URLs, no window titles, no keystrokes)
- NT5: Child has equal access to reports and audit logs
- PRIVACY.md documentation schema alignment
"""

import os
import re
import pytest
from ogk_server.database import init_db, SessionLocal, EventModel
from ogk_server.routes.event_routes import sanitize_subject
from ogk_shared.constants import EventType


def test_data_minimization_sanitize_subject():
    """NT2: Ensure only process name or second-level domain is stored.
    Never full URLs or detailed paths.
    """
    # 1. Full URL with sensitive paths and tokens -> stripped to clean domain
    url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ&sensitive_token=abc123"
    assert sanitize_subject(url) == "www.youtube.com"

    url2 = "http://scratch.mit.edu/projects/123456/editor?user=kid"
    assert sanitize_subject(url2) == "scratch.mit.edu"

    # 2. Local process with directory path -> stripped to executable basename
    exe_path = "C:\\Program Files\\Roblox\\Versions\\version-1234\\RobloxPlayerBeta.exe"
    assert sanitize_subject(exe_path) == "robloxplayerbeta.exe"

    # 3. Plain domain
    assert sanitize_subject("khanacademy.org") == "khanacademy.org"


def test_event_schema_matches_privacy_md():
    """Verify that every field in EventModel is documented in PRIVACY.md."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    privacy_md_path = os.path.join(base_dir, "PRIVACY.md")
    assert os.path.exists(privacy_md_path), "PRIVACY.md file must exist!"

    with open(privacy_md_path, "r", encoding="utf-8") as f:
        privacy_content = f.read()

    # Check that required fields are documented
    required_fields = ["`ts`", "`device_id`", "`child_id`", "`type`", "`subject`", "`duration_sec`", "`policy_id`", "`idempotency_key`"]
    for field in required_fields:
        assert field in privacy_content, f"Field {field} is missing from PRIVACY.md documentation matrix!"

    # Verify forbidden items are explicitly prohibited in PRIVACY.md
    assert "tin nhắn" in privacy_content
    assert "gõ phím" in privacy_content
    assert "chụp ảnh màn hình" in privacy_content


def test_event_types_strictly_match_f3_specification():
    """Verify event types strictly match F3:
    {app_start, app_stop, domain_query, blocked_app, blocked_domain, quota_warning, locked, unlock_request, override_granted}
    """
    expected = {
        "app_start", "app_stop", "domain_query", "blocked_app",
        "blocked_domain", "quota_warning", "locked", "unlock_request", "override_granted"
    }
    actual = {e.value for e in EventType}
    assert actual == expected, f"Event types mismatch: {actual.symmetric_difference(expected)}"
