"""Run the complete test suite with automatic venv detection.
"""

import os
import sys
import subprocess

project_root = os.path.dirname(os.path.abspath(__file__))
venv_python = os.path.join(project_root, ".venv", "Scripts", "python.exe")
if os.path.exists(venv_python) and os.path.normcase(sys.executable) != os.path.normcase(venv_python):
    sys.exit(subprocess.call([venv_python, "-m", "pytest", "tests/", "-v"]))

import pytest
sys.exit(pytest.main(["tests/", "-v"]))
