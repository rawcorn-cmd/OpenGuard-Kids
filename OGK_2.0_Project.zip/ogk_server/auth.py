"""Authentication and authorization module for OGK-Server.
Compliant with F5 Security & Privacy requirements:
- Argon2id password hashing
- 15-minute lockout after 5 failed attempts
- 12-hour session cookies with HttpOnly, Secure, SameSite=Lax
- Server-side session revocation
- Rate-limiting helper
- Device access/refresh token verification with revocation check
- Strict IDOR ownership validation
"""

import time
import uuid
from typing import Optional, Tuple
from fastapi import Request, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from ogk_shared.crypto import hash_password, verify_password, generate_token
from ogk_server.database import get_db, UserModel, SessionModel, DeviceModel, ChildModel

security_bearer = HTTPBearer(auto_error=False)

# In-memory IP-based rate limiter for login attempts (15 requests per minute)
_ip_attempt_tracker = {}


def check_ip_rate_limit(client_ip: str, max_requests: int = 15, window_seconds: int = 60):
    now = time.time()
    attempts = _ip_attempt_tracker.get(client_ip, [])
    # Filter attempts in the current window
    attempts = [t for t in attempts if now - t < window_seconds]
    if len(attempts) >= max_requests:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Quá nhiều yêu cầu đăng nhập từ địa chỉ IP này. Vui lòng thử lại sau một phút."
        )
    attempts.append(now)
    _ip_attempt_tracker[client_ip] = attempts


def create_user_session(db: Session, user_id: str, duration_seconds: int = 43200) -> str:
    """Create a 12-hour server-side session."""
    session_id = generate_token()
    session = SessionModel(
        id=session_id,
        user_id=user_id,
        expires_at=time.time() + duration_seconds
    )
    db.add(session)
    db.commit()
    return session_id


def destroy_user_session(db: Session, session_id: str):
    """Revoke server-side session immediately on logout."""
    db.query(SessionModel).filter(SessionModel.id == session_id).delete()
    db.commit()


def get_current_user(request: Request, db: Session = Depends(get_db)) -> UserModel:
    """Dependency to retrieve authenticated parent from session cookie or header."""
    session_id = request.cookies.get("ogk_session")
    if not session_id:
        # Also check Authorization header for API access
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            session_id = auth_header.split(" ", 1)[1]

    if not session_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Chưa đăng nhập hoặc phiên làm việc đã kết thúc."
        )

    session = db.query(SessionModel).filter(SessionModel.id == session_id).first()
    if not session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Phiên làm việc không tồn tại hoặc đã bị hủy."
        )

    if session.expires_at < time.time():
        db.delete(session)
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Phiên làm việc đã hết hạn sau 12 giờ. Vui lòng đăng nhập lại."
        )

    user = db.query(UserModel).filter(UserModel.id == session.user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tài khoản người dùng không tồn tại."
        )

    return user


def get_current_user_optional(request: Request, db: Session = Depends(get_db)) -> Optional[UserModel]:
    """Optional user authentication for views that show child-view if not parent."""
    try:
        return get_current_user(request, db)
    except HTTPException:
        return None


def verify_child_ownership(db: Session, user: UserModel, child_id: str) -> ChildModel:
    """Anti-IDOR validation: Ensure the child belongs to the authenticated parent."""
    child = db.query(ChildModel).filter(
        ChildModel.id == child_id,
        ChildModel.parent_id == user.id
    ).first()
    if not child:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bạn không có quyền truy cập hồ sơ trẻ em này (Vi phạm IDOR)."
        )
    return child


def verify_device_ownership(db: Session, user: UserModel, device_id: str) -> Tuple[DeviceModel, ChildModel]:
    """Anti-IDOR validation: Ensure the device belongs to a child of this parent."""
    device = db.query(DeviceModel).filter(DeviceModel.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Không tìm thấy thiết bị."
        )
    child = verify_child_ownership(db, user, device.child_id)
    return device, child


# Device Authentication
def get_authenticated_device(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer),
    db: Session = Depends(get_db)
) -> DeviceModel:
    """Verify device access token (15-minute token or token in header)."""
    token = None
    if credentials:
        token = credentials.credentials
    else:
        # Check X-OGK-Token header
        token = request.headers.get("X-OGK-Token")

    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Thiếu mã xác thực thiết bị (Device Token)."
        )

    device = db.query(DeviceModel).filter(DeviceModel.access_token == token).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Mã xác thực thiết bị không hợp lệ."
        )

    if device.is_revoked:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Thiết bị này đã bị hủy liên kết và thu hồi quyền truy cập."
        )

    if device.access_token_expires_at and device.access_token_expires_at < time.time():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Mã truy cập 15 phút đã hết hạn. Vui lòng dùng Refresh Token để gia hạn."
        )

    return device
