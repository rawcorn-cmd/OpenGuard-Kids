"""FastAPI Main Server Application for OGK 2.0.
Parent Dashboard & Remote Management Server.
"""

import asyncio
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from ogk_server.database import init_db, get_db, UserModel
from ogk_server.auth import get_current_user_optional, get_current_user
from ogk_server.routes import (
    auth_routes, enroll_routes, policy_routes, event_routes,
    command_routes, request_routes, report_routes, audit_routes,
    data_retention_routes, child_routes
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database and capture running event loop for real-time WebSocket dispatch."""
    init_db()
    try:
        loop = asyncio.get_running_loop()
        app.state.main_loop = loop
        command_routes.set_server_event_loop(loop)
    except Exception:
        pass
    yield


app = FastAPI(
    title="OGK 2.0 - Open Guardian for Kids",
    description="Ứng dụng hỗ trợ quản lý việc sử dụng máy tính của trẻ em — Minh bạch, an toàn, tôn trọng quyền riêng tư",
    version="2.0.0",
    lifespan=lifespan
)

# CORS middleware for local lab / API requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# Include API Routers
app.include_router(auth_routes.router)
app.include_router(enroll_routes.router)
app.include_router(policy_routes.router)
app.include_router(event_routes.router)
app.include_router(command_routes.router)
app.include_router(request_routes.router)
app.include_router(report_routes.router)
app.include_router(audit_routes.router)
app.include_router(data_retention_routes.router)
app.include_router(child_routes.router)


# HTML Page Routes
@app.get("/", response_class=HTMLResponse)
def index(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="login.html", context={"user": None})


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="register.html", context={"user": None})


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="dashboard.html", context={"user": user})


@app.get("/requests", response_class=HTMLResponse)
def requests_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="requests.html", context={"user": user})


@app.get("/reports", response_class=HTMLResponse)
def reports_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="reports.html", context={"user": user})


@app.get("/audit", response_class=HTMLResponse)
def audit_page(request: Request, user: UserModel = Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="audit.html", context={"user": user})


@app.get("/child/{child_id}", response_class=HTMLResponse)
def child_transparency_page(child_id: str, request: Request):
    """Child transparency view 'Hôm nay em đã dùng gì' (NT5)."""
    return templates.TemplateResponse(request=request, name="child_view.html", context={"child_id": child_id})

