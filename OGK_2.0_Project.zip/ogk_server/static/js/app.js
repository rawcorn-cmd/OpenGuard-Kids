/* OGK 2.0 Dashboard JavaScript Client
 * Real-time Reactive Dashboard with Live Telemetry Polling, Instant Commands,
 * Child Requests Inbox, DNS Live Monitoring, and HMAC Policy Sync.
 */

let currentChildId = null;
let currentPolicy = null;
let scheduleMatrix = Array(7).fill(null).map(() => Array(48).fill(1));
let currentAppRules = [];
let currentDomainRules = [];
let livePollInterval = null;
let enrollCountdownInterval = null;
let currentEnrollCode = "";
let isMatrixDragging = false;
let matrixDragTargetValue = 1;

document.addEventListener('DOMContentLoaded', () => {
  loadChildren();
  // Start background live polling every 2 seconds
  if (livePollInterval) clearInterval(livePollInterval);
  livePollInterval = setInterval(pollLiveStatus, 2000);

  // Stop matrix drag on mouseup anywhere
  document.addEventListener('mouseup', () => {
    isMatrixDragging = false;
  });
});

/* =========================================================================
 * MODERN TOAST NOTIFICATION SYSTEM
 * ========================================================================= */
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const icons = {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    info: 'ℹ️'
  };

  const toast = document.createElement('div');
  toast.className = `toast-item toast-${type}`;
  toast.innerHTML = `
    <span style="font-size: 1.15rem;">${icons[type] || 'ℹ️'}</span>
    <span style="flex: 1; line-height: 1.4;">${message}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px) scale(0.95)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/* =========================================================================
 * CHILDREN & DEVICE MANAGEMENT
 * ========================================================================= */
async function loadChildren() {
  try {
    const res = await fetch('/api/children');
    if (res.status === 401) {
      window.location.href = '/login';
      return;
    }
    const children = await res.json();
    const pillsArea = document.getElementById('childrenPills');
    pillsArea.innerHTML = '';

    if (children.length === 0) {
      pillsArea.innerHTML = '<span style="color: #64748b; font-size: 0.9rem;">Chưa có hồ sơ trẻ nào. Nhấn "+ Thêm hồ sơ trẻ" để bắt đầu.</span>';
      document.getElementById('childActiveArea').style.display = 'none';
      return;
    }

    children.forEach((c, idx) => {
      const btn = document.createElement('button');
      btn.className = `btn ${currentChildId === c.id || (!currentChildId && idx === 0) ? 'btn-primary' : 'btn-secondary'} btn-sm`;
      btn.innerHTML = `👦 ${c.name} (${c.age} tuổi) <span class="badge ${c.device_count > 0 ? 'badge-success' : 'badge-warning'}">${c.device_count} máy</span>`;
      btn.onclick = () => selectChild(c.id);
      pillsArea.appendChild(btn);
    });

    if (!currentChildId && children.length > 0) {
      selectChild(children[0].id);
    } else if (currentChildId) {
      selectChild(currentChildId);
    }
  } catch (err) {
    console.error('Lỗi tải danh sách con:', err);
  }
}

async function selectChild(childId) {
  currentChildId = childId;
  document.getElementById('childActiveArea').style.display = 'block';
  document.getElementById('childFriendlyViewBtn').href = `/child/${childId}`;

  // Refresh children pill highlights
  loadChildrenPillActiveState();

  // Load Child Details & Devices
  const childRes = await fetch(`/api/children/${childId}`);
  const childData = await childRes.json();
  renderDevices(childData.devices || []);

  // Load Policy
  await loadChildPolicy(childId);

  // Poll live status immediately
  await pollLiveStatus();
  await loadChildRequests();
}

function loadChildrenPillActiveState() {
  fetch('/api/children').then(r => r.json()).then(children => {
    const pillsArea = document.getElementById('childrenPills');
    pillsArea.innerHTML = '';
    children.forEach(c => {
      const btn = document.createElement('button');
      btn.className = `btn ${currentChildId === c.id ? 'btn-primary' : 'btn-secondary'} btn-sm`;
      btn.innerHTML = `👦 ${c.name} (${c.age} tuổi) <span class="badge ${c.device_count > 0 ? 'badge-success' : 'badge-warning'}">${c.device_count} máy</span>`;
      btn.onclick = () => selectChild(c.id);
      pillsArea.appendChild(btn);
    });
  });
}

function renderDevices(devices) {
  const listArea = document.getElementById('deviceListArea');
  listArea.innerHTML = '';

  if (devices.length === 0) {
    listArea.innerHTML = '<p style="color: #64748b; font-size: 0.85rem; padding: 0.5rem 0;">Chưa có máy tính nào được ghép đôi với con. Nhấn "🔑 Ghép đôi máy mới" ở trên để lấy mã.</p>';
    return;
  }

  devices.forEach(d => {
    const div = document.createElement('div');
    div.style = 'display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid #f1f5f9;';
    const isOnline = d.status === 'active' || d.status === 'online';
    div.innerHTML = `
      <div>
        <div style="font-weight: 700; font-size: 0.95rem; color: #0f172a;">💻 ${d.name}</div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.15rem;">${d.hostname} • ${d.os_version}</div>
      </div>
      <div style="display: flex; align-items: center; gap: 0.6rem;">
        <span class="badge ${isOnline ? 'badge-success' : 'badge-warning'}">${isOnline ? '🟢 Trực tuyến' : '⚪ Ngoại tuyến'}</span>
        <button onclick="revokeDevice('${d.id}')" class="btn btn-secondary btn-sm" style="color: #ef4444; font-size: 0.8rem;" title="Thu hồi">✕ Thu hồi</button>
      </div>
    `;
    listArea.appendChild(div);
  });
}

/* =========================================================================
 * REAL-TIME LIVE STATUS & TELEMETRY POLLING (Every 2s)
 * ========================================================================= */
async function pollLiveStatus() {
  if (!currentChildId) return;

  try {
    const res = await fetch(`/api/reports/live-status/${currentChildId}`);
    if (!res.ok) return;
    const data = await res.json();
    const telem = data.telemetry;

    // 1. Connection indicator
    const globalDot = document.getElementById('globalPulseDot');
    const globalText = document.getElementById('globalPulseText');
    const agentDot = document.getElementById('agentPulseDot');
    const agentText = document.getElementById('agentStatusText');
    const deviceSub = document.getElementById('deviceSubText');

    if (data.has_active_agent && telem) {
      globalDot.className = 'pulse-dot';
      globalText.innerText = 'Agent Trực Tuyến';
      agentDot.className = telem.is_idle ? 'pulse-dot idle' : 'pulse-dot';
      agentText.innerText = telem.is_idle ? 'Trực tuyến (Đang nghỉ)' : 'Trực tuyến (Live)';
      agentText.style.color = '#15803d';
      deviceSub.innerText = `${telem.device_name || 'Máy tính của con'} • WS Instant Push`;
    } else {
      globalDot.className = 'pulse-dot offline';
      globalText.innerText = 'Agent Ngoại Tuyến';
      agentDot.className = 'pulse-dot offline';
      agentText.innerText = 'Chờ kết nối Agent';
      agentText.style.color = '#64748b';
      deviceSub.innerText = 'Khởi động: python scripts/run_agent.py';
    }

    // 2. Screen Time Countdown & Progress
    if (telem && telem.remaining_seconds !== null && telem.remaining_seconds !== undefined) {
      const remSec = Math.max(0, telem.remaining_seconds);
      const hours = Math.floor(remSec / 3600);
      const mins = Math.floor((remSec % 3600) / 60);
      const secs = remSec % 60;

      let displayStr = `${mins}m ${secs}s`;
      if (hours > 0) displayStr = `${hours}h ${mins}m`;
      document.getElementById('timeRemainingDisplay').innerText = displayStr;

      const quotaSec = telem.quota_seconds || (90 * 60);
      const usedSec = telem.quota_used_seconds || 0;
      const pct = Math.min(100, Math.round((usedSec / Math.max(1, quotaSec)) * 100));

      const bar = document.getElementById('timeProgressBar');
      bar.style.width = `${pct}%`;
      if (pct >= 85) bar.className = 'progress-bar-fill warning';
      else bar.className = 'progress-bar-fill';

      document.getElementById('timeUsageSubText').innerHTML = `
        <span>Đã dùng: ${Math.round(usedSec / 60)} phút</span>
        <span>Hạn mức: ${Math.round(quotaSec / 60)} phút</span>
      `;
    }

    // 3. Active Foreground Application
    const appDisplay = document.getElementById('activeAppDisplay');
    const titleDisplay = document.getElementById('activeAppTitle');
    if (telem && telem.current_app) {
      appDisplay.innerText = telem.current_app;
      titleDisplay.innerText = telem.window_title ? `Cửa sổ: ${telem.window_title}` : 'Đang hoạt động';
      titleDisplay.title = telem.window_title || '';
    } else {
      appDisplay.innerText = 'Desktop / Chờ';
      titleDisplay.innerText = 'Chưa phát hiện ứng dụng';
    }

    // 4. Idle / Active Status
    const idleBadge = document.getElementById('idleStateBadge');
    const idleDetail = document.getElementById('idleDetailText');
    if (telem) {
      const idleSec = Math.round(telem.idle_seconds || 0);
      if (telem.is_idle) {
        idleBadge.innerHTML = `<span class="badge badge-warning" style="font-size: 0.9rem; padding: 0.35rem 0.65rem;">⏸️ ĐÃ TẠM DỪNG (${idleSec}s)</span>`;
        idleDetail.innerText = `Không chạm chuột/phím > 10s: Đồng hồ đếm giờ đã tạm dừng!`;
      } else {
        idleBadge.innerHTML = `<span class="badge badge-success" style="font-size: 0.9rem; padding: 0.35rem 0.65rem;">🟢 Đang hoạt động (${idleSec}s trước)</span>`;
        idleDetail.innerText = `Bàn phím & chuột đang được dùng. Đếm giờ bình thường.`;
      }
    }

    // 5. Live DNS Queries Feed
    if (telem && telem.recent_domains && telem.recent_domains.length > 0) {
      renderLiveDnsStream(telem.recent_domains);
    }

    // 6. Top Apps from Agent / DB
    if (data.top_apps_today && data.top_apps_today.length > 0) {
      renderTopApps(data.top_apps_today);
    }

    // 7. Pending Requests Count
    const reqBadge = document.getElementById('pendingRequestsBadge');
    if (data.pending_requests_count > 0) {
      reqBadge.innerText = `${data.pending_requests_count} chờ duyệt!`;
      reqBadge.className = 'badge badge-danger';
    } else {
      reqBadge.innerText = '0 chờ duyệt';
      reqBadge.className = 'badge badge-warning';
    }

  } catch (e) {
    // Silent catch on network blip
  }
}

function renderLiveDnsStream(queries) {
  const streamBox = document.getElementById('liveDnsStream');
  streamBox.innerHTML = '';

  queries.forEach(q => {
    const item = document.createElement('div');
    item.className = 'live-stream-item';

    let actionBadge = '';
    if (q.action === 'block') {
      actionBadge = `<span class="badge badge-danger">🚫 ĐÃ CHẶN</span>`;
    } else if (q.action === 'safesearch') {
      actionBadge = `<span class="badge badge-warning">🔍 SAFESEARCH</span>`;
    } else {
      actionBadge = `<span class="badge badge-success">✅ CHO PHÉP</span>`;
    }

    item.innerHTML = `
      <div style="min-width: 0; flex: 1; word-break: break-all;">
        <div style="font-weight: 700; color: #1e293b; line-height: 1.3;">${q.domain}</div>
        <div style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">${q.reason || q.category || 'DNS Query'}</div>
      </div>
      <div style="display: flex; align-items: center; gap: 0.4rem; flex-shrink: 0;">
        <span style="font-size: 0.72rem; color: #94a3b8; white-space: nowrap;">${q.time_str || ''}</span>
        ${actionBadge}
      </div>
    `;
    streamBox.appendChild(item);
  });
}

function renderTopApps(apps) {
  const container = document.getElementById('topAppsArea');
  container.innerHTML = '';
  const table = document.createElement('table');
  table.className = 'data-table';
  table.innerHTML = `
    <thead>
      <tr>
        <th>Ứng dụng & Cửa sổ</th>
        <th style="text-align: right;">Thời gian dùng</th>
        <th style="text-align: right;">Thao tác</th>
      </tr>
    </thead>
    <tbody>
      ${apps.map(a => {
        const mins = a.duration_minutes || (a.duration_seconds ? Math.round(a.duration_seconds / 60) : 0);
        let timeStr = `${mins} phút`;
        if (mins >= 60) {
          const h = Math.floor(mins / 60);
          const m = mins % 60;
          timeStr = `${h}h ${m}m`;
        }
        const appEsc = (a.name || '').replace(/'/g, "\\'");
        return `
          <tr>
            <td style="word-break: break-word;">
              <strong style="color: #0f172a;">${a.name}</strong>
              ${a.title ? `<div style="font-size: 0.75rem; color: #64748b; word-break: break-word; line-height: 1.3; margin-top: 2px;" title="${(a.title || '').replace(/"/g, '&quot;')}">${a.title}</div>` : ''}
            </td>
            <td style="text-align: right; white-space: nowrap;"><span class="badge badge-info">${timeStr}</span></td>
            <td style="text-align: right; white-space: nowrap;">
              <button onclick="openAddAppModal('${appEsc}')" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; color: #ef4444;" title="Chặn ứng dụng này">
                🚫 Chặn
              </button>
            </td>
          </tr>
        `;
      }).join('')}
    </tbody>
  `;
  container.appendChild(table);
}

/* =========================================================================
 * CHILD REQUESTS INBOX (NT3: Trẻ có tiếng nói)
 * ========================================================================= */
async function loadChildRequests() {
  if (!currentChildId) return;
  try {
    const res = await fetch(`/api/requests?child_id=${currentChildId}`);
    if (!res.ok) return;
    const requests = await res.json();
    const area = document.getElementById('childRequestsArea');

    const pending = requests.filter(r => r.status === 'pending');
    if (pending.length === 0) {
      area.innerHTML = '<p style="font-size: 0.85rem; color: #64748b; padding: 0.5rem 0;">Hiện không có yêu cầu nào đang chờ duyệt từ con.</p>';
      return;
    }

    area.innerHTML = '';
    pending.forEach(r => {
      const card = document.createElement('div');
      card.style = 'background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 0.85rem; margin-bottom: 0.6rem;';
      const isExtraTime = r.request_type === 'extra_time';

      card.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.4rem;">
          <div>
            <strong style="font-size: 0.9rem; color: #92400e;">${isExtraTime ? '⏱️ Xin thêm giờ' : '🌐 Báo chặn nhầm'}: ${r.subject}</strong>
            <p style="font-size: 0.82rem; color: #78350f; margin-top: 0.2rem;">Lý do của con: "<em>${r.reason}</em>"</p>
          </div>
          <span style="font-size: 0.72rem; color: #b45309;">${new Date(r.created_at * 1000).toLocaleTimeString()}</span>
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 0.5rem;">
          <button onclick="respondChildRequest('${r.id}', 'reject')" class="btn btn-secondary btn-sm" style="color: #ef4444;">Từ chối</button>
          <button onclick="respondChildRequest('${r.id}', 'approve')" class="btn btn-success btn-sm">
            ${isExtraTime ? '✓ Duyệt (+15 phút)' : '✓ Duyệt mở khóa'}
          </button>
        </div>
      `;
      area.appendChild(card);
    });
  } catch (e) {
    console.error('Lỗi tải yêu cầu của con:', e);
  }
}

async function respondChildRequest(requestId, action) {
  try {
    const res = await fetch(`/api/requests/${requestId}/respond`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: action,
        response_note: action === 'approve' ? 'Cha mẹ đã đồng ý với yêu cầu của con.' : 'Cha mẹ chưa đồng ý yêu cầu này.',
        extra_minutes: 15
      })
    });
    if (res.ok) {
      showToast(`Đã ${action === 'approve' ? 'DUYỆT MỞ KHÓA' : 'TỪ CHỐI'} yêu cầu của con thành công! Quy tắc đã được cập nhật và đồng bộ tức thì.`, 'success');
      await loadChildRequests();
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    } else {
      showToast('Lỗi xử lý yêu cầu.', 'error');
    }
  } catch (e) {
    showToast('Lỗi kết nối máy chủ.', 'error');
  }
}

/* =========================================================================
 * DOMAIN FILTER DIAGNOSTIC TESTER
 * ========================================================================= */
async function runDomainFilterTest() {
  const input = document.getElementById('testDomainInput');
  const domain = (input.value || '').trim();
  if (!domain) {
    showToast('Vui lòng nhập tên miền cần kiểm tra (vd: tiktok.com, google.com)', 'warning');
    return;
  }

  const resultBox = document.getElementById('testDomainResult');
  resultBox.style.display = 'block';
  resultBox.innerHTML = '<span style="color: #64748b;">Đang kiểm tra qua bộ quy tắc...</span>';

  try {
    const res = await fetch('/api/reports/test-dns-filter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: domain, child_id: currentChildId })
    });
    const data = await res.json();

    if (data.action === 'block') {
      resultBox.style.background = '#fee2e2';
      resultBox.style.border = '1px solid #fca5a5';
      resultBox.innerHTML = `
        <div style="font-weight: 700; color: #991b1b;">🚫 KẾT QUẢ: ĐÃ BỊ CHẶN</div>
        <div style="color: #7f1d1d; margin-top: 0.25rem;">Lý do: ${data.reason}</div>
        <div style="font-size: 0.75rem; color: #991b1b; margin-top: 0.25rem;">Phân loại: ${data.category || 'Mạng xã hội / Không phù hợp'} • Phản hồi IP: 127.0.0.1</div>
      `;
    } else if (data.action === 'safesearch') {
      resultBox.style.background = '#fef3c7';
      resultBox.style.border = '1px solid #fcd34d';
      resultBox.innerHTML = `
        <div style="font-weight: 700; color: #92400e;">🔍 KẾT QUẢ: CƯỠNG CHẾ SAFESEARCH</div>
        <div style="color: #78350f; margin-top: 0.25rem;">Lý do: ${data.reason}</div>
        <div style="font-size: 0.75rem; color: #92400e; margin-top: 0.25rem;">Định tuyến an toàn qua: ${data.cname || data.ip}</div>
      `;
    } else {
      resultBox.style.background = '#dcfce7';
      resultBox.style.border = '1px solid #86efac';
      resultBox.innerHTML = `
        <div style="font-weight: 700; color: #166534;">✅ KẾT QUẢ: ĐƯỢC PHÉP TRUY CẬP</div>
        <div style="color: #14532d; margin-top: 0.25rem;">Lý do: ${data.reason}</div>
        <div style="font-size: 0.75rem; color: #166534; margin-top: 0.25rem;">Phân loại: ${data.category || 'Học tập / Cho phép'}</div>
      `;
    }
  } catch (e) {
    resultBox.innerHTML = '<span style="color: #ef4444;">Lỗi khi kiểm tra tên miền.</span>';
  }
}

/* =========================================================================
 * POLICY MANAGEMENT (HMAC Signing & 7x48 Matrix)
 * ========================================================================= */
async function loadChildPolicy(childId) {
  try {
    const res = await fetch(`/api/policy/${childId}`);
    if (!res.ok) return;
    const policy = await res.json();
    currentPolicy = policy;

    document.getElementById('policyVersionBadge').innerText = `Phiên bản: v${policy.version}`;
    document.getElementById('weekdayQuota').value = policy.daily_quota_minutes_weekday;
    document.getElementById('weekendQuota').value = policy.daily_quota_minutes_weekend;
    document.getElementById('gamingBudget').value = policy.app_group_budgets?.gaming || 45;

    document.getElementById('catSocial').checked = policy.blocked_categories.includes('social_media');
    document.getElementById('catGaming').checked = policy.blocked_categories.includes('gaming');
    document.getElementById('safeSearchCheck').checked = policy.safesearch_enforced;

    scheduleMatrix = policy.schedule.matrix;
    renderMatrixTable();

    currentAppRules = policy.app_rules || [];
    renderAppRulesTable();

    currentDomainRules = policy.domain_rules || [];
    renderDomainRulesTable();
  } catch (err) {
    console.error('Lỗi tải chính sách:', err);
  }
}

const DAY_LABELS = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ Nhật'];

function renderMatrixTable() {
  const table = document.getElementById('matrixTable');
  table.innerHTML = '';

  const header = document.createElement('tr');
  header.innerHTML = '<th style="width: 70px;">Ngày</th>' +
    Array.from({ length: 24 }).map((_, h) => `<th colspan="2" style="font-size: 0.7rem;">${h}h</th>`).join('');
  table.appendChild(header);

  DAY_LABELS.forEach((dayName, dayIdx) => {
    const row = document.createElement('tr');
    let cells = `<td style="font-weight: 600; font-size: 0.75rem; text-align: left; padding-left: 4px;">${dayName}</td>`;
    for (let slot = 0; slot < 48; slot++) {
      const allowed = scheduleMatrix[dayIdx][slot] === 1;
      const hour = Math.floor(slot / 2);
      const min = slot % 2 === 0 ? '00' : '30';
      cells += `<td class="schedule-slot ${allowed ? 'slot-allowed' : 'slot-locked'}"
                    id="slot-${dayIdx}-${slot}"
                    title="${dayName} ${hour}:${min} (${allowed ? 'Cho phép' : 'Khóa'})"
                    onmousedown="onSlotMouseDown(${dayIdx}, ${slot})"
                    onmouseenter="onSlotMouseEnter(${dayIdx}, ${slot})"></td>`;
    }
    row.innerHTML = cells;
    table.appendChild(row);
  });
}

function onSlotMouseDown(dayIdx, slotIdx) {
  isMatrixDragging = true;
  matrixDragTargetValue = scheduleMatrix[dayIdx][slotIdx] === 1 ? 0 : 1;
  scheduleMatrix[dayIdx][slotIdx] = matrixDragTargetValue;
  updateSlotVisual(dayIdx, slotIdx, matrixDragTargetValue);
}

function onSlotMouseEnter(dayIdx, slotIdx) {
  if (isMatrixDragging) {
    scheduleMatrix[dayIdx][slotIdx] = matrixDragTargetValue;
    updateSlotVisual(dayIdx, slotIdx, matrixDragTargetValue);
  }
}

function updateSlotVisual(dayIdx, slotIdx, value) {
  const el = document.getElementById(`slot-${dayIdx}-${slotIdx}`);
  if (el) {
    el.className = `schedule-slot ${value === 1 ? 'slot-allowed' : 'slot-locked'}`;
    const dayName = DAY_LABELS[dayIdx];
    const hour = Math.floor(slotIdx / 2);
    const min = slotIdx % 2 === 0 ? '00' : '30';
    el.title = `${dayName} ${hour}:${min} (${value === 1 ? 'Cho phép' : 'Khóa'})`;
  }
}

function presetAllAllowed() {
  scheduleMatrix = Array(7).fill(null).map(() => Array(48).fill(1));
  renderMatrixTable();
  showToast('Đã áp dụng lịch: Mở toàn bộ 24h', 'info');
}

function presetStandardSchool() {
  scheduleMatrix = Array(7).fill(null).map(() => {
    const day = Array(48).fill(0);
    for (let s = 14; s < 42; s++) day[s] = 1; // 7h00 - 21h00
    return day;
  });
  renderMatrixTable();
  showToast('Đã áp dụng lịch: Khung giờ học sinh (07h - 21h)', 'info');
}

/* =========================================================================
 * APP RULES MANAGEMENT
 * ========================================================================= */
function renderAppRulesTable() {
  const tbody = document.querySelector('#appRulesTable tbody');
  tbody.innerHTML = '';
  if (currentAppRules.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="color: #94a3b8; font-size: 0.8rem; text-align: center; padding: 0.75rem;">Chưa có quy tắc ứng dụng riêng. Nhấn "+ Thêm ứng dụng" để tạo.</td></tr>';
    return;
  }
  currentAppRules.forEach((r, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="word-break: break-all;">
        <strong>${r.name}</strong> ${r.display_name ? `(${r.display_name})` : ''}
        ${r.reason ? `<div style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">${r.reason}</div>` : ''}
      </td>
      <td><span class="badge ${r.action === 'block' ? 'badge-danger' : 'badge-success'}">${r.action === 'block' ? 'Chặn' : 'Cho phép'}</span></td>
      <td style="text-align: right;"><button type="button" onclick="removeAppRule(${idx})" class="btn btn-secondary btn-sm" style="color: #ef4444; font-size: 0.8rem;">✕ Xóa</button></td>
    `;
    tbody.appendChild(tr);
  });
}

function openAddAppModal(prefilledProcess = '') {
  document.getElementById('newAppProcess').value = prefilledProcess;
  document.getElementById('newAppDisplayName').value = prefilledProcess ? prefilledProcess.replace('.exe', '') : '';
  const modal = document.getElementById('addAppModal');
  modal.classList.add('active');
  setTimeout(() => document.getElementById('newAppProcess').focus(), 100);
}

function closeAddAppModal() {
  document.getElementById('addAppModal').classList.remove('active');
}

async function submitAddAppRule(e) {
  e.preventDefault();
  if (!currentChildId) return;

  const processName = document.getElementById('newAppProcess').value.trim().toLowerCase();
  const displayName = document.getElementById('newAppDisplayName').value.trim() || processName;
  const action = document.getElementById('newAppAction').value;
  const category = document.getElementById('newAppCategory').value;
  const reason = document.getElementById('newAppReason').value.trim();

  try {
    const res = await fetch(`/api/policy/${currentChildId}/add-app-rule`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: processName,
        display_name: displayName,
        action: action,
        category: category,
        reason: reason
      })
    });
    if (res.ok) {
      closeAddAppModal();
      showToast(`Đã thêm quy tắc cho "${processName}" và đồng bộ tức thì tới máy con!`, 'success');
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    } else {
      const err = await res.json();
      showToast(err.detail || 'Lỗi thêm quy tắc ứng dụng', 'error');
    }
  } catch (err) {
    showToast('Lỗi kết nối máy chủ', 'error');
  }
}

async function removeAppRule(idx) {
  const rule = currentAppRules[idx];
  if (!rule || !currentChildId) return;

  try {
    const res = await fetch(`/api/policy/${currentChildId}/delete-app-rule`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ index: idx, name: rule.name })
    });
    if (res.ok) {
      showToast(`Đã gỡ bỏ quy tắc cho "${rule.name}"`, 'info');
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    }
  } catch (err) {
    showToast('Lỗi khi xóa quy tắc', 'error');
  }
}

/* =========================================================================
 * DOMAIN RULES MANAGEMENT
 * ========================================================================= */
function renderDomainRulesTable() {
  const tbody = document.querySelector('#domainRulesTable tbody');
  tbody.innerHTML = '';
  if (currentDomainRules.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="color: #94a3b8; font-size: 0.8rem; text-align: center; padding: 0.75rem;">Chưa có quy tắc tên miền riêng. Nhấn "+ Thêm tên miền" để tạo.</td></tr>';
    return;
  }
  currentDomainRules.forEach((d, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="word-break: break-all;">
        <strong>${d.domain}</strong>
        ${d.reason ? `<div style="font-size: 0.72rem; color: #64748b; margin-top: 2px;">${d.reason}</div>` : ''}
      </td>
      <td><span class="badge ${d.action === 'block' ? 'badge-danger' : (d.action === 'safesearch' ? 'badge-warning' : 'badge-success')}">${d.action === 'block' ? 'Chặn' : (d.action === 'safesearch' ? 'SafeSearch' : 'Cho phép')}</span></td>
      <td style="text-align: right;"><button type="button" onclick="removeDomainRule(${idx})" class="btn btn-secondary btn-sm" style="color: #ef4444; font-size: 0.8rem;">✕ Xóa</button></td>
    `;
    tbody.appendChild(tr);
  });
}

function openAddDomainModal() {
  document.getElementById('newDomainName').value = '';
  const modal = document.getElementById('addDomainModal');
  modal.classList.add('active');
  setTimeout(() => document.getElementById('newDomainName').focus(), 100);
}

function closeAddDomainModal() {
  document.getElementById('addDomainModal').classList.remove('active');
}

async function submitAddDomainRule(e) {
  e.preventDefault();
  if (!currentChildId) return;

  const domain = document.getElementById('newDomainName').value.trim().toLowerCase();
  const action = document.getElementById('newDomainAction').value;
  const category = document.getElementById('newDomainCategory').value;
  const reason = document.getElementById('newDomainReason').value.trim();

  try {
    const res = await fetch(`/api/policy/${currentChildId}/add-domain-rule`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        domain: domain,
        action: action,
        category: category,
        reason: reason
      })
    });
    if (res.ok) {
      closeAddDomainModal();
      showToast(`Đã thêm tên miền "${domain}" vào bộ lọc và cập nhật máy con!`, 'success');
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    } else {
      const err = await res.json();
      showToast(err.detail || 'Lỗi thêm tên miền', 'error');
    }
  } catch (err) {
    showToast('Lỗi kết nối máy chủ', 'error');
  }
}

async function removeDomainRule(idx) {
  const rule = currentDomainRules[idx];
  if (!rule || !currentChildId) return;

  try {
    const res = await fetch(`/api/policy/${currentChildId}/delete-domain-rule`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ index: idx, domain: rule.domain })
    });
    if (res.ok) {
      showToast(`Đã gỡ bỏ tên miền "${rule.domain}"`, 'info');
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    }
  } catch (err) {
    showToast('Lỗi khi xóa quy tắc tên miền', 'error');
  }
}

/* =========================================================================
 * OVERALL POLICY SAVE (HMAC Push)
 * ========================================================================= */
async function savePolicy(e) {
  e.preventDefault();
  if (!currentChildId || !currentPolicy) return;

  const blockedCats = ['inappropriate'];
  if (document.getElementById('catSocial').checked) blockedCats.push('social_media');
  if (document.getElementById('catGaming').checked) blockedCats.push('gaming');

  const updatedPayload = {
    ...currentPolicy,
    daily_quota_minutes_weekday: parseInt(document.getElementById('weekdayQuota').value),
    daily_quota_minutes_weekend: parseInt(document.getElementById('weekendQuota').value),
    schedule: { matrix: scheduleMatrix },
    blocked_categories: blockedCats,
    safesearch_enforced: document.getElementById('safeSearchCheck').checked,
    app_rules: currentAppRules,
    domain_rules: currentDomainRules,
    app_group_budgets: {
      gaming: parseInt(document.getElementById('gamingBudget').value) || 45,
      education: -1
    }
  };

  try {
    const res = await fetch(`/api/policy/${currentChildId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedPayload)
    });
    if (res.ok) {
      showToast('Đã lưu và ký số HMAC cho chính sách mới thành công! Agent sẽ cập nhật tức thì.', 'success');
      await loadChildPolicy(currentChildId);
      await pollLiveStatus();
    } else {
      const err = await res.json();
      showToast('Lỗi lưu chính sách: ' + (err.detail || 'Không xác định'), 'error');
    }
  } catch (err) {
    showToast('Lỗi kết nối máy chủ.', 'error');
  }
}

/* =========================================================================
 * FAST COMMANDS (< 5s WebSocket Push)
 * ========================================================================= */
async function sendQuickCommand(action, payload = {}) {
  if (!currentChildId) return;
  const childRes = await fetch(`/api/children/${currentChildId}`);
  const childData = await childRes.json();
  const devices = childData.devices || [];

  if (devices.length === 0) {
    showToast('Con chưa có thiết bị nào được ghép đôi.', 'warning');
    return;
  }

  const actionLabels = {
    lock_now: 'Khóa máy ngay',
    unlock: 'Mở khóa máy (+15p)',
    add_time: `Cho thêm ${payload.minutes || 15} phút`
  };

  for (const d of devices) {
    await fetch('/api/commands/urgent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        device_id: d.id,
        action: action,
        payload: payload
      })
    });
  }

  showToast(`Đã gửi lệnh [${actionLabels[action] || action}] tức thì (< 5s) tới máy tính của con!`, 'success');
  await pollLiveStatus();
}

/* =========================================================================
 * PAIRING CODE MODAL (8-character code with 10-minute countdown)
 * ========================================================================= */
async function openEnrollModal() {
  if (!currentChildId) return;

  try {
    const res = await fetch('/api/enroll/create-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ child_id: currentChildId })
    });
    const data = await res.json();
    currentEnrollCode = data.code;

    // Display code formatted with spaces
    const formatted = currentEnrollCode.slice(0, 4) + ' - ' + currentEnrollCode.slice(4);
    document.getElementById('modalEnrollCode').innerText = formatted;

    // Start 10-minute countdown
    let remaining = Math.max(0, Math.floor(data.expires_at - (Date.now() / 1000)));
    updateEnrollCountdown(remaining);

    if (enrollCountdownInterval) clearInterval(enrollCountdownInterval);
    enrollCountdownInterval = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(enrollCountdownInterval);
        document.getElementById('modalEnrollCountdown').innerText = '⚠️ Mã đã hết hạn! Vui lòng đóng và mở lại để tạo mã mới.';
        document.getElementById('modalEnrollCountdown').style.color = '#ef4444';
      } else {
        updateEnrollCountdown(remaining);
      }
    }, 1000);

    document.getElementById('enrollModal').classList.add('active');
  } catch (err) {
    showToast('Không thể tạo mã ghép đôi', 'error');
  }
}

function updateEnrollCountdown(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  const str = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  document.getElementById('modalEnrollCountdown').innerText = `⏱️ Hiệu lực còn lại: ${str} (Hết hạn sau 10 phút)`;
  document.getElementById('modalEnrollCountdown').style.color = '#2563eb';
}

function closeEnrollModal() {
  document.getElementById('enrollModal').classList.remove('active');
  if (enrollCountdownInterval) clearInterval(enrollCountdownInterval);
}

function copyEnrollmentCode() {
  if (!currentEnrollCode) return;
  navigator.clipboard.writeText(currentEnrollCode).then(() => {
    showToast(`Đã sao chép mã ghép đôi: ${currentEnrollCode}`, 'info');
  }).catch(() => {
    showToast(`Mã ghép đôi: ${currentEnrollCode}`, 'info');
  });
}

/* =========================================================================
 * DEVICE REVOCATION & DATA RETENTION
 * ========================================================================= */
async function revokeDevice(deviceId) {
  if (!confirm('Bạn có chắc muốn thu hồi quyền truy cập của thiết bị này?')) return;
  await fetch(`/api/enroll/devices/${deviceId}/revoke`, { method: 'POST' });
  showToast('Đã thu hồi quyền thiết bị thành công.', 'info');
  selectChild(currentChildId);
}

async function confirmWipeChildData() {
  if (!confirm('CẢNH BÁO: Thao tác này sẽ xóa vĩnh viễn toàn bộ nhật ký sự kiện của con trên server và đồng bộ xóa sạch trên máy tính con! Bạn có chắc chắn muốn xóa?')) return;
  const res = await fetch(`/api/retention/wipe-child-data/${currentChildId}`, { method: 'POST' });
  const data = await res.json();
  showToast(data.message || 'Đã xóa dữ liệu thành công.', 'warning');
  await pollLiveStatus();
}

/* =========================================================================
 * REWARD & PROFILE MODALS
 * ========================================================================= */
function openRewardModal() {
  document.getElementById('rewardModal').classList.add('active');
}
function closeRewardModal() {
  document.getElementById('rewardModal').classList.remove('active');
}
async function submitRewardTime() {
  const taskName = document.getElementById('rewardTaskName').value;
  const minutes = parseInt(document.getElementById('rewardMinutes').value);
  await fetch(`/api/children/${currentChildId}/reward-time`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ minutes, task_name: taskName })
  });
  closeRewardModal();
  showToast(`Đã thưởng +${minutes} phút cho con vì: "${taskName}"! Lệnh đã gửi tức thì.`, 'success');
  await pollLiveStatus();
}

function openNewChildModal() {
  document.getElementById('newChildName').value = '';
  document.getElementById('childModal').classList.add('active');
  setTimeout(() => document.getElementById('newChildName').focus(), 100);
}
function closeNewChildModal() {
  document.getElementById('childModal').classList.remove('active');
}
async function submitNewChild() {
  const name = document.getElementById('newChildName').value.trim();
  const age = parseInt(document.getElementById('newChildAge').value);
  if (!name) {
    showToast('Vui lòng nhập tên của con.', 'warning');
    return;
  }
  const res = await fetch('/api/children', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, age })
  });
  const data = await res.json();
  closeNewChildModal();
  showToast(`Đã tạo hồ sơ cho bé ${name}!`, 'success');
  currentChildId = data.child_id;
  await loadChildren();
}
