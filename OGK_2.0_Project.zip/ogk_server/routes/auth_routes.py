"""Parent authentication routes.
Argon2id, 15-minute brute-force lockout after 5 fails, 12-hour session cookies, CSRF protection.
"""

import time
import re
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, field_validator
from sqlalchemy.orm import Session
from ogk_shared.crypto import hash_password, verify_password
from ogk_server.database import get_db, UserModel
from ogk_server.auth import (
    create_user_session, destroy_user_session, get_current_user, check_ip_rate_limit
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


class RegisterPayload(BaseModel):
    email: str
    password: str
    full_name: str

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        v = v.strip().lower()
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v):
            raise ValueError("Địa chỉ email không hợp lệ")
        return v


class LoginPayload(BaseModel):
    email: str
    password: str



@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterPayload, request: Request, db: Session = Depends(get_db)):
    client_ip = request.client.host if request.client else "127.0.0.1"
    check_ip_rate_limit(client_ip)

    existing = db.query(UserModel).filter(UserModel.email == payload.email.lower()).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email này đã được đăng ký trong hệ thống."
        )

    try:
        p_hash = hash_password(payload.password)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    user = UserModel(
        email=payload.email.lower(),
        password_hash=p_hash,
        full_name=payload.full_name,
        role="parent"
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return {"message": "Đăng ký tài khoản phụ huynh thành công", "user_id": user.id}


@router.post("/login")
def login(payload: LoginPayload, request: Request, response: Response, db: Session = Depends(get_db)):
    client_ip = request.client.host if request.client else "127.0.0.1"
    check_ip_rate_limit(client_ip)

    user = db.query(UserModel).filter(UserModel.email == payload.email.lower()).first()
    now = time.time()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email hoặc mật khẩu không chính xác."
        )

    # Check 15-minute temporary lockout
    if user.locked_until and user.locked_until > now:
        remaining_minutes = int((user.locked_until - now) / 60) + 1
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Tài khoản bị tạm khóa do nhập sai quá 5 lần. Vui lòng thử lại sau {remaining_minutes} phút."
        )

    # Verify Argon2id password
    if not verify_password(user.password_hash, payload.password):
        user.failed_login_attempts += 1
        if user.failed_login_attempts >= 5:
            user.locked_until = now + 900  # Lock 15 minutes (900 seconds)
            user.failed_login_attempts = 0
            db.commit()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Nhập sai mật khẩu 5 lần liên tiếp. Tài khoản đã bị tạm khóa 15 phút theo chính sách bảo mật F5."
            )
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Email hoặc mật khẩu không chính xác. Bạn còn {5 - user.failed_login_attempts} lần thử."
        )

    # Reset failed attempts upon successful login
    user.failed_login_attempts = 0
    user.locked_until = None
    db.commit()

    # Create 12-hour session
    session_id = create_user_session(db, user.id, duration_seconds=43200)

    # Set HttpOnly, Secure, SameSite=Lax cookie
    response.set_cookie(
        key="ogk_session",
        value=session_id,
        max_age=43200,
        httponly=True,
        samesite="lax",
        secure=False  # Set to True in production HTTPS
    )

    return {
        "message": "Đăng nhập thành công",
        "session_id": session_id,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role
        }
    }


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    session_id = request.cookies.get("ogk_session")
    if session_id:
        destroy_user_session(db, session_id)
    response.delete_cookie("ogk_session")
    return {"message": "Đăng xuất thành công"}


@router.get("/me")
def me(user: UserModel = Depends(get_current_user)):
    return {
        "id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role
    }
