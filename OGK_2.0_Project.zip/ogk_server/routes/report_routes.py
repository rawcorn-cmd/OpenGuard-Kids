"""Reporting and analytics routes.
Implements NT5 (Two-way Transparency: Trẻ được xem cùng bộ báo cáo mà phụ huynh xem).
"""

import time
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session
from ogk_shared.constants import EventType
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, EventModel, PolicyModel, ChildRequestModel
)
from ogk_server.auth import get_current_user, verify_child_ownership

router = APIRouter(prefix="/api/reports", tags=["Reports"])


class TestDNSQueryPayload(BaseModel):
    domain: str
    child_id: Optional[str] = None


@router.get("/live-status/{child_id}")
def get_child_live_status(
    child_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Real-time live status for dashboard:
    Active foreground application, window title, idle time, countdown, live DNS queries.
    """
    child = verify_child_ownership(db, current_user, child_id)
    from ogk_server.routes.command_routes import get_child_live_telemetry
    live_telem = get_child_live_telemetry(db, child.id)

    # Query pending requests count
    pending_requests = db.query(ChildRequestModel).filter(
        ChildRequestModel.child_id == child.id,
        ChildRequestModel.status == "pending"
    ).count()

    today_start = datetime.combine(date.today(), datetime.min.time()).timestamp()

    # Query top apps today from DB
    top_apps_today = db.query(
        EventModel.subject,
        func.sum(EventModel.duration_sec).label("total_sec")
    ).filter(
        EventModel.child_id == child.id,
        EventModel.ts >= today_start,
        EventModel.type.in_([EventType.APP_START.value, EventType.APP_STOP.value])
    ).group_by(EventModel.subject).order_by(func.sum(EventModel.duration_sec).desc()).limit(5).all()

    top_apps = [
        {"name": r.subject, "duration_minutes": round((r.total_sec or 0) / 60, 1)}
        for r in top_apps_today
    ]

    total_blocked_today = db.query(func.count(EventModel.id)).filter(
        EventModel.child_id == child.id,
        EventModel.ts >= today_start,
        EventModel.type.in_([EventType.BLOCKED_APP.value, EventType.BLOCKED_DOMAIN.value])
    ).scalar() or 0

    apps_list = []
    if live_telem and live_telem.get("all_apps_today"):
        apps_list = live_telem["all_apps_today"]
    elif top_apps:
        apps_list = [{"name": a["name"], "title": "", "duration_minutes": a["duration_minutes"], "duration_seconds": int(a["duration_minutes"] * 60)} for a in top_apps]

    return {
        "child_id": child.id,
        "child_name": child.name,
        "has_active_agent": bool(live_telem and live_telem.get("is_online")),
        "telemetry": live_telem,
        "pending_requests_count": pending_requests,
        "top_apps_today": apps_list,
        "total_blocked_today": total_blocked_today
    }


@router.post("/test-dns-filter")
def test_dns_filter(
    payload: TestDNSQueryPayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Test how a domain is handled by the DNS filter for a child."""
    from ogk_agent.dns_proxy import DNSFilterProxy
    from ogk_server.routes.policy_routes import get_or_create_child_policy

    proxy = DNSFilterProxy(device_id="test", child_id="test")
    if payload.child_id:
        policy_model = get_or_create_child_policy(db, payload.child_id)
        from ogk_server.routes.policy_routes import serialize_policy
        schema = serialize_policy(policy_model, "test_secret")
        proxy.update_policy(schema.model_dump())

    res = proxy.evaluate_domain(payload.domain)
    return {
        "domain": payload.domain,
        "action": res.get("action", "allow"),
        "reason": res.get("reason", ""),
        "category": res.get("category", ""),
        "cname": res.get("cname"),
        "ip": res.get("ip")
    }


@router.get("/summary/{child_id}")
def get_parent_child_report(
    child_id: str,
    days: int = Query(7, ge=1, le=90),
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent report: daily/weekly charts, top 10 apps, top 10 domains, block counts."""
    child = verify_child_ownership(db, current_user, child_id)
    return generate_child_metrics(db, child.id, days)


@router.get("/child-transparency/{child_id}")
def get_child_friendly_report(
    child_id: str,
    db: Session = Depends(get_db)
):
    """Child transparency report (NT5): 'Hôm nay em đã dùng gì'."""
    child = db.query(ChildModel).filter(ChildModel.id == child_id).first()
    if not child:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Không tìm thấy trẻ.")

    metrics = generate_child_metrics(db, child.id, days=1)

    # Format in friendly tone
    total_minutes = int(metrics["today_duration_seconds"] / 60)
    quota_minutes = metrics["daily_quota_minutes"]
    remaining_minutes = max(0, quota_minutes - total_minutes)

    encouragement = "Chúc con có một ngày học tập và vui chơi thật vui vẻ, an toàn!"
    if total_minutes >= quota_minutes:
        encouragement = "Hôm nay con đã dùng hết thời gian màn hình rồi, hãy nghỉ ngơi và vận động nhé!"
    elif total_minutes >= quota_minutes * 0.8:
        encouragement = "Sắp hết thời gian sử dụng hôm nay rồi, con nhớ lưu bài tập nhé!"

    return {
        "child_name": child.name,
        "age": child.age,
        "today_used_minutes": total_minutes,
        "daily_quota_minutes": quota_minutes,
        "remaining_minutes": remaining_minutes,
        "encouragement": encouragement,
        "top_apps": metrics["top_apps"][:5],
        "top_domains": metrics["top_domains"][:5],
        "blocked_count": metrics["total_blocked_today"],
        "recent_blocks": metrics["recent_blocks"][:5],
    }


def generate_child_metrics(db: Session, child_id: str, days: int = 7) -> Dict:
    now = time.time()
    cutoff_ts = now - (days * 86400)
    today_start = datetime.combine(date.today(), datetime.min.time()).timestamp()

    # Policy details
    policy = db.query(PolicyModel).filter(PolicyModel.child_id == child_id).first()
    is_weekend = datetime.now().weekday() in (5, 6)
    daily_quota = 90
    if policy:
        daily_quota = policy.daily_quota_minutes_weekend if is_weekend else policy.daily_quota_minutes_weekday

    # Today duration
    today_duration = db.query(func.sum(EventModel.duration_sec)).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= today_start,
        EventModel.type.in_([EventType.APP_START.value, EventType.APP_STOP.value])
    ).scalar() or 0

    # Top 10 Apps
    top_apps_query = db.query(
        EventModel.subject,
        func.sum(EventModel.duration_sec).label("total_sec"),
        func.count(EventModel.id).label("count")
    ).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= cutoff_ts,
        EventModel.type.in_([EventType.APP_START.value, EventType.APP_STOP.value])
    ).group_by(EventModel.subject).order_by(func.sum(EventModel.duration_sec).desc()).limit(10).all()

    top_apps = [
        {"app": r.subject, "duration_minutes": round((r.total_sec or 0) / 60, 1), "sessions": r.count}
        for r in top_apps_query
    ]

    # Top 10 Domains
    top_domains_query = db.query(
        EventModel.subject,
        func.count(EventModel.id).label("queries")
    ).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= cutoff_ts,
        EventModel.type == EventType.DOMAIN_QUERY.value
    ).group_by(EventModel.subject).order_by(func.count(EventModel.id).desc()).limit(10).all()

    top_domains = [{"domain": r.subject, "query_count": r.queries} for r in top_domains_query]

    # Blocked counts
    blocked_apps_count = db.query(func.count(EventModel.id)).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= cutoff_ts,
        EventModel.type == EventType.BLOCKED_APP.value
    ).scalar() or 0

    blocked_domains_count = db.query(func.count(EventModel.id)).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= cutoff_ts,
        EventModel.type == EventType.BLOCKED_DOMAIN.value
    ).scalar() or 0

    total_blocked_today = db.query(func.count(EventModel.id)).filter(
        EventModel.child_id == child_id,
        EventModel.ts >= today_start,
        EventModel.type.in_([EventType.BLOCKED_APP.value, EventType.BLOCKED_DOMAIN.value])
    ).scalar() or 0

    recent_blocks = db.query(EventModel).filter(
        EventModel.child_id == child_id,
        EventModel.type.in_([EventType.BLOCKED_APP.value, EventType.BLOCKED_DOMAIN.value])
    ).order_by(EventModel.ts.desc()).limit(10).all()

    recent_blocks_list = [
        {
            "type": r.type,
            "subject": r.subject,
            "time": datetime.fromtimestamp(r.ts).strftime("%H:%M:%S - %d/%m/%Y")
        }
        for r in recent_blocks
    ]

    # Daily breakdown for chart (last 7 days)
    daily_chart = []
    for d in range(days - 1, -1, -1):
        target_date = date.today() - timedelta(days=d)
        start_ts = datetime.combine(target_date, datetime.min.time()).timestamp()
        end_ts = start_ts + 86400

        dur = db.query(func.sum(EventModel.duration_sec)).filter(
            EventModel.child_id == child_id,
            EventModel.ts >= start_ts,
            EventModel.ts < end_ts,
            EventModel.type.in_([EventType.APP_START.value, EventType.APP_STOP.value])
        ).scalar() or 0

        blocks = db.query(func.count(EventModel.id)).filter(
            EventModel.child_id == child_id,
            EventModel.ts >= start_ts,
            EventModel.ts < end_ts,
            EventModel.type.in_([EventType.BLOCKED_APP.value, EventType.BLOCKED_DOMAIN.value])
        ).scalar() or 0

        daily_chart.append({
            "date": target_date.strftime("%d/%m"),
            "day_name": ["T2", "T3", "T4", "T5", "T6", "T7", "CN"][target_date.weekday()],
            "duration_minutes": round(dur / 60, 1),
            "blocks": blocks
        })

    return {
        "today_duration_seconds": today_duration,
        "daily_quota_minutes": daily_quota,
        "total_blocked_today": total_blocked_today,
        "blocked_apps_count": blocked_apps_count,
        "blocked_domains_count": blocked_domains_count,
        "top_apps": top_apps,
        "top_domains": top_domains,
        "recent_blocks": recent_blocks_list,
        "daily_chart": daily_chart
    }
