"""Policy management routes with HMAC integrity signing and audit logging.
Requirements:
- Version tracking & HMAC-SHA256 integrity signature
- Audit logging of every policy change (who, when, IP, old/new value)
- Automatic notification to connected devices
"""

import json
import time
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ogk_shared.constants import Category
from ogk_shared.crypto import sign_policy
from ogk_shared.schemas import PolicySchema, AppRule, DomainRule, ScheduleMatrix
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, PolicyModel, AuditLogModel
)
from ogk_server.auth import get_current_user, get_authenticated_device, verify_child_ownership

router = APIRouter(prefix="/api/policy", tags=["Policy"])


def get_default_matrix():
    """Default weekly schedule: 7x48 slots.
    Default: Allow all hours (1) so developers/parents aren't locked out accidentally at night.
    Parents can configure specific bedtime/school lock slots on the Dashboard.
    """
    return [[1] * 48 for _ in range(7)]



def get_or_create_child_policy(db: Session, child_id: str) -> PolicyModel:
    """Retrieve existing policy or create compliant default policy."""
    policy = db.query(PolicyModel).filter(PolicyModel.child_id == child_id).first()
    if not policy:
        default_app_rules = [
            {"name": "roblox.exe", "sha256": None, "action": "block", "category": Category.GAMING.value, "display_name": "Roblox", "reason": "Trò chơi trực tuyến bị giới hạn theo giờ"},
            {"name": "game.exe", "sha256": None, "action": "block", "category": Category.GAMING.value, "display_name": "Game Test", "reason": "Trò chơi bị hạn chế theo quy định gia đình"},
        ]
        default_domain_rules = [
            {"domain": "tiktok.com", "action": "block", "category": Category.SOCIAL_MEDIA.value, "reason": "Mạng xã hội không phù hợp với lứa tuổi 6-11"},
            {"domain": "roblox.com", "action": "block", "category": Category.GAMING.value, "reason": "Giới hạn truy cập trò chơi trực tuyến"},
        ]
        default_budgets = {
            Category.GAMING.value: 45,       # 45 minutes for games
            Category.EDUCATION.value: -1,     # Unlimited for study
            Category.ENTERTAINMENT.value: 30, # 30 minutes for entertainment
        }

        policy = PolicyModel(
            child_id=child_id,
            version=1,
            daily_quota_minutes_weekday=90,
            daily_quota_minutes_weekend=120,
            schedule_matrix_json=json.dumps(get_default_matrix()),
            blocked_categories_json=json.dumps([
                Category.INAPPROPRIATE.value,
                Category.SOCIAL_MEDIA.value,
                Category.GAMING.value
            ]),
            allowed_categories_json=json.dumps([
                Category.EDUCATION.value,
                Category.ENTERTAINMENT.value
            ]),
            app_rules_json=json.dumps(default_app_rules),
            domain_rules_json=json.dumps(default_domain_rules),
            app_group_budgets_json=json.dumps(default_budgets),
            safesearch_enforced=True,
            offline_expiry_days=7,
            fail_open_after_expiry=False,
            updated_at=time.time()
        )
        db.add(policy)
        db.commit()
        db.refresh(policy)
    return policy


def serialize_policy(policy_model: PolicyModel, secret_key: str) -> PolicySchema:
    """Convert DB model to PolicySchema and sign with HMAC-SHA256."""
    schedule_data = json.loads(policy_model.schedule_matrix_json)
    blocked_categories = json.loads(policy_model.blocked_categories_json)
    allowed_categories = json.loads(policy_model.allowed_categories_json)
    app_rules = [AppRule(**item) for item in json.loads(policy_model.app_rules_json)]
    domain_rules = [DomainRule(**item) for item in json.loads(policy_model.domain_rules_json)]
    app_group_budgets = json.loads(policy_model.app_group_budgets_json)

    schema = PolicySchema(
        policy_id=policy_model.id,
        version=policy_model.version,
        child_id=policy_model.child_id,
        daily_quota_minutes_weekday=policy_model.daily_quota_minutes_weekday,
        daily_quota_minutes_weekend=policy_model.daily_quota_minutes_weekend,
        schedule=ScheduleMatrix(matrix=schedule_data),
        blocked_categories=blocked_categories,
        allowed_categories=allowed_categories,
        app_rules=app_rules,
        domain_rules=domain_rules,
        app_group_budgets=app_group_budgets,
        safesearch_enforced=policy_model.safesearch_enforced,
        offline_expiry_days=policy_model.offline_expiry_days,
        fail_open_after_expiry=policy_model.fail_open_after_expiry,
    )

    # Calculate HMAC signature
    signature = sign_policy(schema.model_dump(), secret_key)
    schema.signature = signature
    return schema


@router.get("/{child_id}", response_model=PolicySchema)
def get_child_policy(
    child_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent retrieves active signed policy for their child."""
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)

    # Use first active device secret or parent key for signing
    device = db.query(DeviceModel).filter(
        DeviceModel.child_id == child.id,
        DeviceModel.is_revoked == False
    ).first()
    secret = device.secret_key if device else "default_parent_secret_key"

    return serialize_policy(policy_model, secret)


@router.put("/{child_id}", response_model=PolicySchema)
def update_child_policy(
    child_id: str,
    new_policy: PolicySchema,
    request: Request,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent updates policy for child.
    Increments version, records AuditLog, and dispatches refresh command to agents.
    """
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)
    client_ip = request.client.host if request.client else "127.0.0.1"

    old_summary = (
        f"v{policy_model.version}: Quota {policy_model.daily_quota_minutes_weekday}m/"
        f"{policy_model.daily_quota_minutes_weekend}m, Blocked: {policy_model.blocked_categories_json}"
    )

    # Increment version
    policy_model.version += 1
    policy_model.daily_quota_minutes_weekday = new_policy.daily_quota_minutes_weekday
    policy_model.daily_quota_minutes_weekend = new_policy.daily_quota_minutes_weekend
    policy_model.schedule_matrix_json = json.dumps(new_policy.schedule.matrix)
    policy_model.blocked_categories_json = json.dumps(new_policy.blocked_categories)
    policy_model.allowed_categories_json = json.dumps(new_policy.allowed_categories)
    policy_model.app_rules_json = json.dumps([r.model_dump() for r in new_policy.app_rules])
    policy_model.domain_rules_json = json.dumps([d.model_dump() for d in new_policy.domain_rules])
    policy_model.app_group_budgets_json = json.dumps(new_policy.app_group_budgets)
    policy_model.safesearch_enforced = new_policy.safesearch_enforced
    policy_model.offline_expiry_days = new_policy.offline_expiry_days
    policy_model.fail_open_after_expiry = new_policy.fail_open_after_expiry
    policy_model.updated_at = time.time()

    new_summary = (
        f"v{policy_model.version}: Quota {policy_model.daily_quota_minutes_weekday}m/"
        f"{policy_model.daily_quota_minutes_weekend}m, Blocked: {policy_model.blocked_categories_json}"
    )

    # NT5 & F4: Record in Audit Log
    audit_entry = AuditLogModel(
        child_id=child.id,
        operator=current_user.email,
        client_ip=client_ip,
        action="UPDATE_POLICY",
        target=f"Chính sách {child.name} (v{policy_model.version})",
        old_value=old_summary,
        new_value=new_summary,
        timestamp=time.time()
    )
    db.add(audit_entry)
    db.commit()
    db.refresh(policy_model)

    # Enqueue urgent command to notify agents to refresh policy immediately
    from ogk_server.routes.command_routes import broadcast_command_to_child_devices
    broadcast_command_to_child_devices(
        db, child.id, "refresh_policy", {"version": policy_model.version}
    )

    device = db.query(DeviceModel).filter(
        DeviceModel.child_id == child.id,
        DeviceModel.is_revoked == False
    ).first()
    secret = device.secret_key if device else "default_parent_secret_key"

    return serialize_policy(policy_model, secret)


class AddAppRulePayload(BaseModel):
    name: str
    display_name: Optional[str] = None
    category: str = "gaming"
    action: str = "block"
    reason: Optional[str] = "Ứng dụng bị giới hạn theo quy định cha mẹ"


class AddDomainRulePayload(BaseModel):
    domain: str
    category: str = "social_media"
    action: str = "block"
    reason: Optional[str] = "Trang web bị chặn theo chính sách gia đình"


class DeleteAppRulePayload(BaseModel):
    index: Optional[int] = None
    name: Optional[str] = None


class DeleteDomainRulePayload(BaseModel):
    index: Optional[int] = None
    domain: Optional[str] = None


class RuleIndexPayload(BaseModel):
    index: int


@router.post("/{child_id}/add-app-rule")
def add_app_rule_direct(
    child_id: str,
    payload: AddAppRulePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Directly add app rule, save to DB, and push to agent immediately."""
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)
    rules = json.loads(policy_model.app_rules_json)

    clean_name = payload.name.strip().lower()
    # Check if rule exists
    existing = next((r for r in rules if r.get("name") == clean_name), None)
    if existing:
        existing["action"] = payload.action
        existing["reason"] = payload.reason
        existing["display_name"] = payload.display_name or clean_name
        existing["category"] = payload.category
    else:
        rules.append({
            "name": clean_name,
            "display_name": payload.display_name or clean_name,
            "sha256": None,
            "category": payload.category,
            "action": payload.action,
            "reason": payload.reason
        })

    policy_model.app_rules_json = json.dumps(rules)
    policy_model.version += 1
    policy_model.updated_at = time.time()
    db.commit()

    from ogk_server.routes.command_routes import broadcast_command_to_child_devices
    broadcast_command_to_child_devices(db, child.id, "refresh_policy", {"version": policy_model.version})
    return {"status": "success", "message": f"Đã thêm quy tắc cho {clean_name}", "app_rules": rules}


@router.post("/{child_id}/delete-app-rule")
def delete_app_rule_direct(
    child_id: str,
    payload: DeleteAppRulePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)
    rules = json.loads(policy_model.app_rules_json)

    target_idx = -1
    if payload.name:
        clean_name = payload.name.strip().lower()
        for idx, r in enumerate(rules):
            if r.get("name") == clean_name:
                target_idx = idx
                break
    elif payload.index is not None and 0 <= payload.index < len(rules):
        target_idx = payload.index

    if target_idx >= 0:
        rules.pop(target_idx)
        policy_model.app_rules_json = json.dumps(rules)
        policy_model.version += 1
        policy_model.updated_at = time.time()
        db.commit()
        from ogk_server.routes.command_routes import broadcast_command_to_child_devices
        broadcast_command_to_child_devices(db, child.id, "refresh_policy", {"version": policy_model.version})
        return {"status": "success", "message": "Đã xóa quy tắc ứng dụng", "app_rules": rules}
    return {"status": "error", "message": "Không tìm thấy quy tắc ứng dụng"}


@router.post("/{child_id}/add-domain-rule")
def add_domain_rule_direct(
    child_id: str,
    payload: AddDomainRulePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Directly add domain rule, save to DB, and push to agent immediately."""
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)
    domains = json.loads(policy_model.domain_rules_json)

    clean_d = payload.domain.strip().lower()
    existing = next((d for d in domains if d.get("domain") == clean_d), None)
    if existing:
        existing["action"] = payload.action
        existing["reason"] = payload.reason
        existing["category"] = payload.category
    else:
        domains.append({
            "domain": clean_d,
            "category": payload.category,
            "action": payload.action,
            "reason": payload.reason
        })

    policy_model.domain_rules_json = json.dumps(domains)
    policy_model.version += 1
    policy_model.updated_at = time.time()
    db.commit()

    from ogk_server.routes.command_routes import broadcast_command_to_child_devices
    broadcast_command_to_child_devices(db, child.id, "refresh_policy", {"version": policy_model.version})
    return {"status": "success", "message": f"Đã cập nhật quy tắc cho {clean_d}", "domain_rules": domains}


@router.post("/{child_id}/delete-domain-rule")
def delete_domain_rule_direct(
    child_id: str,
    payload: DeleteDomainRulePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    child = verify_child_ownership(db, current_user, child_id)
    policy_model = get_or_create_child_policy(db, child.id)
    domains = json.loads(policy_model.domain_rules_json)

    target_idx = -1
    if payload.domain:
        clean_d = payload.domain.strip().lower()
        for idx, d in enumerate(domains):
            if d.get("domain") == clean_d:
                target_idx = idx
                break
    elif payload.index is not None and 0 <= payload.index < len(domains):
        target_idx = payload.index

    if target_idx >= 0:
        domains.pop(target_idx)
        policy_model.domain_rules_json = json.dumps(domains)
        policy_model.version += 1
        policy_model.updated_at = time.time()
        db.commit()
        from ogk_server.routes.command_routes import broadcast_command_to_child_devices
        broadcast_command_to_child_devices(db, child.id, "refresh_policy", {"version": policy_model.version})
        return {"status": "success", "message": "Đã xóa quy tắc tên miền", "domain_rules": domains}
    return {"status": "error", "message": "Không tìm thấy tên miền"}


@router.get("/agent/me", response_model=PolicySchema)
def agent_get_my_policy(
    device: DeviceModel = Depends(get_authenticated_device),
    db: Session = Depends(get_db)
):
    """Agent calls this endpoint with device access token to fetch its latest signed policy."""
    policy_model = get_or_create_child_policy(db, device.child_id)
    return serialize_policy(policy_model, device.secret_key)
