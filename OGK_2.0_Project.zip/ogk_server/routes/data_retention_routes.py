"""Data retention and Right-to-be-Forgotten routes.
Implements F3 (Thời hạn lưu trữ 90 ngày, xóa đồng thời trên server và agent).
"""

import time
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, EventModel, AuditLogModel, ChildRequestModel
)
from ogk_server.auth import get_current_user, verify_child_ownership
from ogk_server.routes.command_routes import broadcast_command_to_child_devices

router = APIRouter(prefix="/api/retention", tags=["Data Retention"])


def run_90_day_cleanup(db: Session) -> int:
    """Purge events older than 90 days per F3 requirements."""
    cutoff_ts = time.time() - (90 * 86400)
    deleted = db.query(EventModel).filter(EventModel.ts < cutoff_ts).delete()
    db.commit()
    return deleted


@router.post("/cleanup-90-days")
def trigger_data_cleanup(
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Trigger the 90-day retention cleanup task."""
    deleted_count = run_90_day_cleanup(db)
    return {
        "status": "success",
        "message": f"Đã tự động dọn dẹp {deleted_count} sự kiện cũ quá 90 ngày theo quy định F3."
    }


@router.post("/wipe-child-data/{child_id}")
def wipe_all_child_data(
    child_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Button 'Xóa toàn bộ dữ liệu của con tôi':
    Wipes all events and history from server database and dispatches wipe_cache command to agent!
    """
    child = verify_child_ownership(db, current_user, child_id)

    # 1. Delete events for this child
    deleted_events = db.query(EventModel).filter(EventModel.child_id == child.id).delete()

    # 2. Delete child requests
    deleted_requests = db.query(ChildRequestModel).filter(ChildRequestModel.child_id == child.id).delete()

    # 3. Dispatches urgent command to agent to wipe its local SQLite cache
    broadcast_command_to_child_devices(db, child.id, "wipe_cache", {"reason": "Parent requested full data wipe"})

    # 4. Record audit entry
    audit = AuditLogModel(
        child_id=child.id,
        operator=current_user.email,
        client_ip="127.0.0.1",
        action="WIPE_ALL_DATA",
        target=f"Dữ liệu của {child.name}",
        old_value=f"Đã xóa {deleted_events} sự kiện, {deleted_requests} yêu cầu",
        new_value="Đã xóa toàn bộ trên server và đồng bộ xóa cache agent",
        timestamp=time.time()
    )
    db.add(audit)
    db.commit()

    return {
        "status": "success",
        "message": f"Đã xóa toàn bộ dữ liệu của {child.name} trên máy chủ và phát lệnh xóa cache tại máy tính của con.",
        "deleted_events": deleted_events,
        "deleted_requests": deleted_requests
    }
