"""Child profile management routes for parents.
Supports 1 Parent : N Children : M Devices.
Includes Reward Time mechanism for completed tasks (CÓ THÌ TỐT).
"""

import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, PolicyModel, AuditLogModel
)
from ogk_server.auth import get_current_user, verify_child_ownership
from ogk_server.routes.policy_routes import get_or_create_child_policy
from ogk_server.routes.command_routes import broadcast_command_to_child_devices

router = APIRouter(prefix="/api/children", tags=["Children Management"])


class ChildCreatePayload(BaseModel):
    name: str
    age: int = 10
    avatar: str = "child_avatar.png"


class RewardTimePayload(BaseModel):
    minutes: int = 15
    task_name: str = "Hoàn thành bài tập về nhà"


@router.get("")
def list_children(
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all children under this parent profile."""
    children = db.query(ChildModel).filter(ChildModel.parent_id == current_user.id).all()
    results = []
    for c in children:
        devices = db.query(DeviceModel).filter(DeviceModel.child_id == c.id).all()
        policy = get_or_create_child_policy(db, c.id)
        results.append({
            "id": c.id,
            "name": c.name,
            "age": c.age,
            "avatar": c.avatar,
            "created_at": c.created_at,
            "device_count": len(devices),
            "devices": [
                {
                    "id": d.id,
                    "name": d.name,
                    "hostname": d.hostname,
                    "os_version": d.os_version,
                    "status": d.status,
                    "last_heartbeat": d.last_heartbeat,
                    "is_revoked": d.is_revoked
                }
                for d in devices
            ],
            "policy_version": policy.version
        })
    return results


@router.post("", status_code=status.HTTP_201_CREATED)
def create_child(
    payload: ChildCreatePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent creates a new child profile."""
    child = ChildModel(
        id=str(uuid.uuid4()),
        parent_id=current_user.id,
        name=payload.name,
        age=payload.age,
        avatar=payload.avatar,
        created_at=time.time()
    )
    db.add(child)
    db.commit()
    db.refresh(child)

    # Initialize default policy for child
    get_or_create_child_policy(db, child.id)

    return {"message": "Tạo hồ sơ trẻ thành công", "child_id": child.id, "name": child.name}


@router.get("/{child_id}")
def get_child_detail(
    child_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    child = verify_child_ownership(db, current_user, child_id)
    devices = db.query(DeviceModel).filter(DeviceModel.child_id == child.id).all()
    policy = get_or_create_child_policy(db, child.id)
    return {
        "id": child.id,
        "name": child.name,
        "age": child.age,
        "avatar": child.avatar,
        "devices": [
            {
                "id": d.id,
                "name": d.name,
                "status": d.status,
                "last_heartbeat": d.last_heartbeat
            } for d in devices
        ],
        "policy_version": policy.version
    }


@router.post("/{child_id}/reward-time")
def reward_time_for_task(
    child_id: str,
    payload: RewardTimePayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Reward child extra screen time for completing real-life tasks (CÓ THÌ TỐT)."""
    child = verify_child_ownership(db, current_user, child_id)
    minutes = max(1, min(120, payload.minutes))

    # Broadcast command to child's computers
    broadcast_command_to_child_devices(db, child.id, "add_time", {
        "minutes": minutes,
        "reason": f"Thưởng hoàn thành: {payload.task_name}"
    })

    # Audit log
    audit = AuditLogModel(
        child_id=child.id,
        operator=current_user.email,
        client_ip="127.0.0.1",
        action="REWARD_TIME",
        target=f"{child.name} (+{minutes} phút)",
        old_value=None,
        new_value=f"Nhiệm vụ: {payload.task_name}",
        timestamp=time.time()
    )
    db.add(audit)
    db.commit()

    return {
        "message": f"Đã thưởng +{minutes} phút cho {child.name} vì hoàn thành: {payload.task_name}!"
    }


@router.delete("/{child_id}")
def delete_child(
    child_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    child = verify_child_ownership(db, current_user, child_id)
    db.delete(child)
    db.commit()
    return {"message": "Đã xóa hồ sơ trẻ thành công"}
