"""Event ingestion and batch synchronization routes.
Strict enforcement of NT2 (Data Minimization) & offline deduplication (idempotency).
"""

from typing import List
from urllib.parse import urlparse
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from ogk_shared.schemas import BatchEventsPayload, EventRecord
from ogk_server.database import get_db, DeviceModel, EventModel
from ogk_server.auth import get_authenticated_device

router = APIRouter(prefix="/api/events", tags=["Events"])


def sanitize_subject(subject: str) -> str:
    """Ensure subject is only process name or second-level domain/FQDN.
    Never store full URLs, query parameters, or paths (NT2).
    """
    subject = subject.strip()
    if "://" in subject:
        parsed = urlparse(subject)
        return parsed.netloc.lower() or "unknown_domain"
    if "/" in subject or "\\" in subject:
        # Strip path if present, keep only executable file name
        import os
        return os.path.basename(subject).lower()
    return subject.lower()


@router.post("/batch", status_code=status.HTTP_200_OK)
def ingest_event_batch(
    payload: BatchEventsPayload,
    device: DeviceModel = Depends(get_authenticated_device),
    db: Session = Depends(get_db)
):
    """Batch event synchronization with idempotency key deduplication."""
    inserted = 0
    skipped = 0

    for item in payload.events:
        # Enforce idempotency key deduplication
        if item.idempotency_key:
            existing = db.query(EventModel).filter(
                EventModel.idempotency_key == item.idempotency_key
            ).first()
            if existing:
                skipped += 1
                continue

        # NT2: Data minimization sanitization
        clean_subject = sanitize_subject(item.subject)

        event = EventModel(
            ts=item.ts,
            device_id=device.id,
            child_id=device.child_id,
            type=item.type.value if hasattr(item.type, "value") else str(item.type),
            subject=clean_subject,
            duration_sec=max(0, item.duration_sec),
            policy_id=item.policy_id,
            idempotency_key=item.idempotency_key
        )
        db.add(event)
        inserted += 1

    db.commit()

    return {
        "status": "success",
        "processed": inserted,
        "skipped_duplicate": skipped
    }
