"""Audit logging routes.
Implements NT5 (Trẻ được xem nhật ký thay đổi luật của phụ huynh).
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from ogk_shared.schemas import AuditLogResponse
from ogk_server.database import get_db, ChildModel, AuditLogModel

router = APIRouter(prefix="/api/audit", tags=["Audit Log"])


@router.get("/{child_id}", response_model=List[AuditLogResponse])
def get_audit_log(
    child_id: str,
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db)
):
    """View audit logs of parent changes.
    Accessible to both parents and children for full transparency (NT5).
    """
    child = db.query(ChildModel).filter(ChildModel.id == child_id).first()
    if not child:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Không tìm thấy trẻ.")

    logs = db.query(AuditLogModel).filter(
        AuditLogModel.child_id == child_id
    ).order_by(AuditLogModel.timestamp.desc()).limit(limit).all()

    return [
        AuditLogResponse(
            id=log.id,
            timestamp=log.timestamp,
            operator=log.operator,
            client_ip=log.client_ip,
            action=log.action,
            target=log.target,
            old_value=log.old_value,
            new_value=log.new_value
        )
        for log in logs
    ]
