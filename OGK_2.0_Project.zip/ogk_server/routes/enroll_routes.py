"""Enrollment and device management routes.
- 8-character enrollment codes with 10-minute expiration
- Device fingerprinting and token issuance (15-min access + refresh)
- Device unpairing and revocation
"""

import time
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ogk_shared.crypto import generate_enrollment_code, generate_device_secret, generate_token, sign_policy
from ogk_shared.schemas import (
    EnrollmentCreate, EnrollmentCodeInfo, EnrollmentAgentRequest,
    EnrollmentAgentResponse, PolicySchema
)
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, EnrollmentCodeModel, PolicyModel
)
from ogk_server.auth import get_current_user, verify_child_ownership, verify_device_ownership

router = APIRouter(prefix="/api/enroll", tags=["Enrollment"])


@router.post("/create-code", response_model=EnrollmentCodeInfo)
def create_enrollment_code(
    payload: EnrollmentCreate,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent generates an 8-character enrollment code valid for 10 minutes."""
    child = verify_child_ownership(db, current_user, payload.child_id)
    code = generate_enrollment_code()
    expires_at = time.time() + 600  # 10 minutes

    # Invalidate prior unused codes for this child
    db.query(EnrollmentCodeModel).filter(
        EnrollmentCodeModel.child_id == child.id,
        EnrollmentCodeModel.is_used == False
    ).delete()

    record = EnrollmentCodeModel(
        code=code,
        child_id=child.id,
        expires_at=expires_at,
        is_used=False
    )
    db.add(record)
    db.commit()

    return EnrollmentCodeInfo(
        code=code,
        child_id=child.id,
        expires_at=expires_at
    )


@router.post("/agent", response_model=EnrollmentAgentResponse)
def enroll_agent(
    payload: EnrollmentAgentRequest,
    db: Session = Depends(get_db)
):
    """Agent sends the 8-character code and device fingerprint to pair."""
    code_record = db.query(EnrollmentCodeModel).filter(
        EnrollmentCodeModel.code == payload.code.upper(),
        EnrollmentCodeModel.is_used == False
    ).first()

    now = time.time()
    if not code_record:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Mã ghép đôi không tồn tại hoặc đã được sử dụng."
        )

    if code_record.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Mã ghép đôi đã hết hạn sau 10 phút. Vui lòng tạo mã mới trên bảng điều khiển phụ huynh."
        )

    child = db.query(ChildModel).filter(ChildModel.id == code_record.child_id).first()
    if not child:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Không tìm thấy thông tin trẻ.")

    # Mark code as used (Nghị định 13/2023 parent consent checkpoint)
    code_record.is_used = True

    # Check if this fingerprint already exists for this child, or create new device
    device = db.query(DeviceModel).filter(
        DeviceModel.child_id == child.id,
        DeviceModel.device_fingerprint == payload.device_fingerprint
    ).first()

    secret_key = generate_device_secret()
    access_token = generate_token()
    refresh_token = generate_token()
    access_expires = now + 900  # 15 minutes per F5

    if not device:
        device = DeviceModel(
            id=str(uuid.uuid4()),
            child_id=child.id,
            name=f"{payload.hostname} ({child.name})",
            hostname=payload.hostname,
            os_version=payload.os_version,
            device_fingerprint=payload.device_fingerprint,
            secret_key=secret_key,
            access_token=access_token,
            access_token_expires_at=access_expires,
            refresh_token=refresh_token,
            status="active",
            last_heartbeat=now
        )
        db.add(device)
    else:
        device.secret_key = secret_key
        device.access_token = access_token
        device.access_token_expires_at = access_expires
        device.refresh_token = refresh_token
        device.is_revoked = False
        device.status = "active"
        device.last_heartbeat = now

    db.commit()
    db.refresh(device)

    # Get or create policy for child
    from ogk_server.routes.policy_routes import get_or_create_child_policy, serialize_policy
    policy_model = get_or_create_child_policy(db, child.id)
    policy_schema = serialize_policy(policy_model, secret_key)

    return EnrollmentAgentResponse(
        device_id=device.id,
        child_id=child.id,
        access_token=access_token,
        refresh_token=refresh_token,
        secret_key=secret_key,
        policy=policy_schema
    )


class RefreshTokenPayload(BaseModel):
    device_id: str
    refresh_token: str


@router.post("/refresh-token")
def refresh_device_token(payload: RefreshTokenPayload, db: Session = Depends(get_db)):
    """Exchange refresh token for a new 15-minute access token."""
    device = db.query(DeviceModel).filter(
        DeviceModel.id == payload.device_id,
        DeviceModel.refresh_token == payload.refresh_token
    ).first()

    if not device or device.is_revoked:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token không hợp lệ hoặc thiết bị đã bị thu hồi."
        )

    now = time.time()
    new_access_token = generate_token()
    device.access_token = new_access_token
    device.access_token_expires_at = now + 900
    db.commit()

    return {
        "access_token": new_access_token,
        "expires_in": 900
    }


@router.post("/devices/{device_id}/revoke")
def revoke_device(
    device_id: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent revokes a child's device."""
    device, child = verify_device_ownership(db, current_user, device_id)
    device.is_revoked = True
    device.access_token = None
    device.refresh_token = None
    device.status = "revoked"
    db.commit()
    return {"message": f"Đã thu hồi quyền truy cập của thiết bị {device.name}"}
