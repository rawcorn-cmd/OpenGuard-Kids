"""Child request management routes (NT3: Trẻ có tiếng nói).
Handles 'Xin thêm giờ' (Extra time) and 'Con nghĩ trang này bị chặn nhầm' (False positive report).
"""

import json
import time
import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ogk_shared.constants import RequestStatus, RequestType
from ogk_shared.schemas import ChildRequestCreate, ChildRequestResponse
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, ChildRequestModel, PolicyModel, AuditLogModel
)
from ogk_server.auth import (
    get_current_user, get_authenticated_device, verify_child_ownership
)
from ogk_server.routes.command_routes import (
    queue_command_in_db, send_command_to_ws, dispatch_command_to_device, broadcast_command_to_child_devices
)

router = APIRouter(prefix="/api/requests", tags=["Child Requests"])


class RequestRespondPayload(BaseModel):
    action: str  # approve, reject
    response_note: Optional[str] = "Phụ huynh đã duyệt yêu cầu của con"
    extra_minutes: Optional[int] = 15  # For extra_time


@router.post("/create", response_model=ChildRequestResponse)
def create_child_request(
    payload: ChildRequestCreate,
    device: DeviceModel = Depends(get_authenticated_device),
    db: Session = Depends(get_db)
):
    """Child submits request from Tray UI ('Xin thêm giờ' or 'Báo chặn nhầm')."""
    req = ChildRequestModel(
        id=str(uuid.uuid4()),
        child_id=device.child_id,
        device_id=device.id,
        request_type=payload.request_type.value if hasattr(payload.request_type, "value") else str(payload.request_type),
        subject=payload.subject,
        reason=payload.reason,
        status=RequestStatus.PENDING.value,
        created_at=time.time()
    )
    db.add(req)
    db.commit()
    db.refresh(req)

    return ChildRequestResponse(
        id=req.id,
        child_id=req.child_id,
        device_id=req.device_id,
        request_type=RequestType(req.request_type),
        subject=req.subject,
        reason=req.reason,
        status=RequestStatus(req.status),
        parent_response=req.parent_response,
        created_at=req.created_at,
        updated_at=req.updated_at
    )


@router.get("", response_model=List[ChildRequestResponse])
def list_parent_child_requests(
    child_id: Optional[str] = None,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent lists requests submitted by their children."""
    query = db.query(ChildRequestModel).join(ChildModel).filter(
        ChildModel.parent_id == current_user.id
    )
    if child_id:
        verify_child_ownership(db, current_user, child_id)
        query = query.filter(ChildRequestModel.child_id == child_id)

    records = query.order_by(ChildRequestModel.created_at.desc()).all()
    results = []
    for r in records:
        results.append(ChildRequestResponse(
            id=r.id,
            child_id=r.child_id,
            device_id=r.device_id,
            request_type=RequestType(r.request_type),
            subject=r.subject,
            reason=r.reason,
            status=RequestStatus(r.status),
            parent_response=r.parent_response,
            created_at=r.created_at,
            updated_at=r.updated_at
        ))
    return results


@router.post("/{request_id}/respond")
async def respond_to_request(
    request_id: str,
    payload: RequestRespondPayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent approves or rejects a request.
    If extra time is approved, immediately dispatches 'add_time' command to the child's PC.
    If false positive is approved, automatically adds the domain to the allowed list.
    """
    req = db.query(ChildRequestModel).filter(ChildRequestModel.id == request_id).first()
    if not req:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Không tìm thấy yêu cầu.")

    child = verify_child_ownership(db, current_user, req.child_id)
    now = time.time()
    req.updated_at = now
    req.parent_response = payload.response_note

    if payload.action == "approve":
        req.status = RequestStatus.APPROVED.value

        if req.request_type == RequestType.EXTRA_TIME.value:
            # Enqueue urgent command to add time
            minutes = payload.extra_minutes or 15
            cmd = queue_command_in_db(db, req.device_id, "add_time", {"minutes": minutes})
            pushed = dispatch_command_to_device(req.device_id, {
                "command_id": cmd.id,
                "device_id": req.device_id,
                "action": "add_time",
                "payload": {"minutes": minutes},
                "created_at": cmd.created_at
            })
            if pushed:
                cmd.is_executed = True
                db.commit()

        elif req.request_type == RequestType.FALSE_POSITIVE.value:
            from ogk_server.routes.policy_routes import get_or_create_child_policy
            policy = get_or_create_child_policy(db, child.id)
            raw_sub = req.subject.strip()

            # Clean name (remove http/https/trailing slashes if present)
            clean_sub = raw_sub.lower().replace("https://", "").replace("http://", "").split("/")[0].strip()

            app_rules = json.loads(policy.app_rules_json)
            domain_rules = json.loads(policy.domain_rules_json)

            is_app = clean_sub.endswith(".exe") or any(ar.get("name", "").lower() in (clean_sub, clean_sub + ".exe") for ar in app_rules)

            if is_app:
                # Target is an application
                app_name = clean_sub if clean_sub.endswith(".exe") else f"{clean_sub}.exe"
                found = False
                for ar in app_rules:
                    if ar.get("name", "").lower() == app_name:
                        ar["action"] = "allow"
                        ar["reason"] = f"Cha mẹ đã duyệt mở khóa theo kiến nghị của con ({payload.response_note or 'Đồng ý mở'})"
                        found = True
                        break
                if not found:
                    app_rules.append({
                        "name": app_name,
                        "display_name": app_name.replace(".exe", ""),
                        "sha256": None,
                        "action": "allow",
                        "category": "education",
                        "reason": "Cha mẹ đã duyệt mở khóa theo kiến nghị của con"
                    })
                policy.app_rules_json = json.dumps(app_rules)
            else:
                # Target is a domain
                found = False
                for dr in domain_rules:
                    if dr.get("domain", "").lower() == clean_sub:
                        dr["action"] = "allow"
                        dr["reason"] = f"Cha mẹ đã duyệt mở khóa theo kiến nghị của con ({payload.response_note or 'Đồng ý mở'})"
                        found = True
                        break
                if not found:
                    domain_rules.append({
                        "domain": clean_sub,
                        "action": "allow",
                        "category": "education",
                        "reason": "Cha mẹ đã duyệt mở khóa theo kiến nghị của con"
                    })
                policy.domain_rules_json = json.dumps(domain_rules)

            policy.version += 1
            policy.updated_at = now
            db.commit()

            # Broadcast policy refresh to all child devices via WebSocket immediately
            from ogk_server.routes.command_routes import broadcast_command_to_child_devices
            broadcast_command_to_child_devices(db, child.id, "refresh_policy", {
                "version": policy.version,
                "unblocked": clean_sub
            })

    else:
        req.status = RequestStatus.REJECTED.value

    # Audit log
    audit = AuditLogModel(
        child_id=child.id,
        operator=current_user.email,
        client_ip="127.0.0.1",
        action=f"REQUEST_{payload.action.upper()}",
        target=f"Yêu cầu {req.request_type}: {req.subject}",
        old_value=None,
        new_value=payload.response_note,
        timestamp=now
    )
    db.add(audit)
    db.commit()

    return {"message": f"Đã {payload.action} yêu cầu của con.", "status": req.status}


@router.get("/child/{child_id}", response_model=List[ChildRequestResponse])
def get_child_requests_transparency(child_id: str, db: Session = Depends(get_db)):
    """Public/Child endpoint to view requests and parent responses (NT3 & NT5)."""
    records = db.query(ChildRequestModel).filter(
        ChildRequestModel.child_id == child_id
    ).order_by(ChildRequestModel.created_at.desc()).all()

    results = []
    for r in records:
        results.append(ChildRequestResponse(
            id=r.id,
            child_id=r.child_id,
            device_id=r.device_id,
            request_type=RequestType(r.request_type),
            subject=r.subject,
            reason=r.reason,
            status=RequestStatus(r.status),
            parent_response=r.parent_response,
            created_at=r.created_at,
            updated_at=r.updated_at
        ))
    return results
