"""Urgent command dispatching (WebSocket + Heartbeat fallback).
Ensures urgent commands (lock_now, unlock, add_time) execute within 5 seconds!
"""

import asyncio
import json
import time
import uuid
from typing import Any, Dict, List
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ogk_shared.schemas import UrgentCommand, HeartbeatRequest, HeartbeatResponse
from ogk_server.database import (
    get_db, UserModel, ChildModel, DeviceModel, UrgentCommandModel, AuditLogModel, SessionLocal
)
from ogk_server.auth import get_current_user, get_authenticated_device, verify_device_ownership

router = APIRouter(tags=["Commands & Heartbeat"])

# Active WebSocket connections: device_id -> WebSocket
_active_agent_websockets: Dict[str, WebSocket] = {}

# Server event loop for threadsafe async task dispatch
_server_event_loop: Optional[asyncio.AbstractEventLoop] = None

# In-memory real-time telemetry cache: device_id -> dict
_device_live_telemetry: Dict[str, dict] = {}


def set_server_event_loop(loop: asyncio.AbstractEventLoop):
    global _server_event_loop
    _server_event_loop = loop


def get_child_live_telemetry(db: Session, child_id: str) -> Optional[dict]:
    """Retrieve the most recent live telemetry for any active device belonging to child."""
    devices = db.query(DeviceModel).filter(
        DeviceModel.child_id == child_id,
        DeviceModel.is_revoked == False
    ).all()
    now = time.time()
    for d in devices:
        telem = _device_live_telemetry.get(d.id)
        if telem:
            is_recent = (now - telem.get("last_heartbeat", 0)) < 15.0
            telem_copy = dict(telem)
            telem_copy["is_online"] = is_recent
            telem_copy["ws_connected"] = d.id in _active_agent_websockets
            return telem_copy
        elif d.last_heartbeat and (now - d.last_heartbeat) < 15.0:
            return {
                "device_id": d.id,
                "child_id": child_id,
                "device_name": d.name,
                "last_heartbeat": d.last_heartbeat,
                "status": d.status,
                "is_online": True,
                "ws_connected": d.id in _active_agent_websockets,
                "screen_locked": False,
                "idle_seconds": 0.0,
                "is_idle": False,
                "quota_used_seconds": 0,
                "remaining_seconds": None,
                "quota_seconds": None,
                "current_app": None,
                "window_title": None,
                "recent_domains": [],
                "all_apps_today": []
            }
    return None


class UrgentCommandPayload(BaseModel):
    device_id: str
    action: str  # lock_now, unlock, add_time, refresh_policy, wipe_cache
    payload: Dict[str, Any] = {}


async def send_command_to_ws(device_id: str, command_dict: dict) -> bool:
    """Send command to agent over WebSocket if connected."""
    ws = _active_agent_websockets.get(device_id)
    if ws:
        try:
            await ws.send_text(json.dumps(command_dict))
            return True
        except Exception:
            _active_agent_websockets.pop(device_id, None)
    return False


def dispatch_command_to_device(device_id: str, command_dict: dict) -> bool:
    """Thread-safe WebSocket command dispatch from any thread or async handler."""
    global _server_event_loop
    if device_id not in _active_agent_websockets:
        return False

    if _server_event_loop and _server_event_loop.is_running():
        try:
            try:
                curr = asyncio.get_running_loop()
            except RuntimeError:
                curr = None

            if curr is _server_event_loop:
                asyncio.create_task(send_command_to_ws(device_id, command_dict))
            else:
                asyncio.run_coroutine_threadsafe(
                    send_command_to_ws(device_id, command_dict),
                    _server_event_loop
                )
            return True
        except Exception as e:
            print(f"[-] Lỗi phát lệnh WebSocket: {e}")
    return False


def queue_command_in_db(db: Session, device_id: str, action: str, payload: dict) -> UrgentCommandModel:
    cmd = UrgentCommandModel(
        id=str(uuid.uuid4()),
        device_id=device_id,
        action=action,
        payload_json=json.dumps(payload),
        is_executed=False,
        created_at=time.time()
    )
    db.add(cmd)
    db.commit()
    db.refresh(cmd)
    return cmd


def broadcast_command_to_child_devices(db: Session, child_id: str, action: str, payload: dict):
    """Queue command for all devices of a child and push immediately over WebSocket."""
    devices = db.query(DeviceModel).filter(
        DeviceModel.child_id == child_id,
        DeviceModel.is_revoked == False
    ).all()
    for d in devices:
        cmd = queue_command_in_db(db, d.id, action, payload)
        pushed = dispatch_command_to_device(d.id, {
            "command_id": cmd.id,
            "device_id": d.id,
            "action": action,
            "payload": payload,
            "created_at": cmd.created_at
        })
        if pushed:
            cmd.is_executed = True
            db.commit()


@router.post("/api/commands/urgent")
async def dispatch_urgent_command(
    payload: UrgentCommandPayload,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Parent dispatches urgent command (lock_now, unlock, add_time).
    Delivered in < 5 seconds over WebSocket or next heartbeat.
    """
    device, child = verify_device_ownership(db, current_user, payload.device_id)

    # Queue command in database
    cmd = queue_command_in_db(db, device.id, payload.action, payload.payload)

    # Record in Audit Log
    audit = AuditLogModel(
        child_id=child.id,
        operator=current_user.email,
        client_ip="127.0.0.1",
        action=f"COMMAND_{payload.action.upper()}",
        target=f"{device.name} ({child.name})",
        old_value=None,
        new_value=json.dumps(payload.payload, ensure_ascii=False),
        timestamp=time.time()
    )
    db.add(audit)
    db.commit()

    # Deliver instantly if WebSocket is connected
    delivered_live = await send_command_to_ws(device.id, {
        "command_id": cmd.id,
        "device_id": device.id,
        "action": cmd.action,
        "payload": payload.payload,
        "created_at": cmd.created_at
    })

    if delivered_live:
        cmd.is_executed = True
        db.commit()

    return {
        "message": f"Đã phát lệnh {payload.action} tới thiết bị",
        "command_id": cmd.id,
        "delivered_instantly": delivered_live
    }


@router.websocket("/ws/agent/{device_id}")
async def agent_websocket_endpoint(websocket: WebSocket, device_id: str, token: str = ""):
    """Persistent WebSocket for instant urgent commands (< 5s latency)."""
    await websocket.accept()

    # Authenticate token
    db = SessionLocal()
    try:
        device = db.query(DeviceModel).filter(
            DeviceModel.id == device_id,
            DeviceModel.access_token == token
        ).first()

        if not device or device.is_revoked:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return

        device.status = "online"
        device.last_heartbeat = time.time()
        db.commit()
        _active_agent_websockets[device_id] = websocket

        # Check and send any pending commands immediately
        pending = db.query(UrgentCommandModel).filter(
            UrgentCommandModel.device_id == device_id,
            UrgentCommandModel.is_executed == False
        ).all()
        for p in pending:
            payload = json.loads(p.payload_json) if p.payload_json else {}
            await websocket.send_text(json.dumps({
                "command_id": p.id,
                "device_id": device_id,
                "action": p.action,
                "payload": payload,
                "created_at": p.created_at
            }))
            p.is_executed = True
        db.commit()

        # Listen loop
        while True:
            data = await websocket.receive_text()
            # Agent can send ping/telemetry json
            now_ts = time.time()
            device.last_heartbeat = now_ts
            try:
                msg_json = json.loads(data)
                if isinstance(msg_json, dict) and "type" in msg_json and msg_json["type"] == "telemetry":
                    _device_live_telemetry[device_id] = {
                        "device_id": device_id,
                        "child_id": device.child_id,
                        "device_name": device.name,
                        "last_heartbeat": now_ts,
                        "status": msg_json.get("status", "active"),
                        "screen_locked": msg_json.get("screen_locked", False),
                        "idle_seconds": float(msg_json.get("idle_seconds", 0.0)),
                        "is_idle": bool(msg_json.get("is_idle", False)),
                        "quota_used_seconds": int(msg_json.get("quota_used_seconds", 0)),
                        "remaining_seconds": msg_json.get("remaining_seconds"),
                        "quota_seconds": msg_json.get("quota_seconds"),
                        "current_app": msg_json.get("current_app"),
                        "window_title": msg_json.get("window_title"),
                        "recent_domains": msg_json.get("recent_domains", [])
                    }
            except Exception:
                pass
            db.commit()
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        _active_agent_websockets.pop(device_id, None)
        try:
            device = db.query(DeviceModel).filter(DeviceModel.id == device_id).first()
            if device:
                device.status = "offline"
                db.commit()
        except Exception:
            pass
        db.close()


@router.post("/api/agent/heartbeat", response_model=HeartbeatResponse)
def agent_heartbeat(
    payload: HeartbeatRequest,
    device: DeviceModel = Depends(get_authenticated_device),
    db: Session = Depends(get_db)
):
    """Fallback heartbeat & telemetry ingestion (every 3-60s).
    Reports agent status, active app, idle time, and returns pending commands.
    """
    now = time.time()
    device.last_heartbeat = now
    device.status = payload.status

    # Record real-time telemetry in memory
    _device_live_telemetry[device.id] = {
        "device_id": device.id,
        "child_id": device.child_id,
        "device_name": device.name,
        "last_heartbeat": now,
        "status": payload.status,
        "screen_locked": payload.screen_locked,
        "idle_seconds": payload.idle_seconds,
        "is_idle": payload.is_idle,
        "quota_used_seconds": payload.quota_used_seconds,
        "remaining_seconds": payload.remaining_seconds,
        "quota_seconds": payload.quota_seconds,
        "current_app": payload.current_app,
        "window_title": payload.window_title,
        "recent_domains": payload.recent_domains or [],
        "all_apps_today": payload.all_apps_today or []
    }

    # Check child's latest policy version
    from ogk_server.routes.policy_routes import get_or_create_child_policy
    policy = get_or_create_child_policy(db, device.child_id)

    # Fetch unexecuted commands
    pending_records = db.query(UrgentCommandModel).filter(
        UrgentCommandModel.device_id == device.id,
        UrgentCommandModel.is_executed == False
    ).all()

    pending_commands: List[UrgentCommand] = []
    for p in pending_records:
        pending_commands.append(UrgentCommand(
            command_id=p.id,
            device_id=device.id,
            action=p.action,
            payload=json.loads(p.payload_json) if p.payload_json else {},
            created_at=p.created_at
        ))
        p.is_executed = True

    db.commit()

    return HeartbeatResponse(
        latest_policy_version=policy.version,
        pending_commands=pending_commands,
        override_seconds=0
    )
