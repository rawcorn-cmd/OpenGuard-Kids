"""Database configuration and ORM models for OGK-Server.
SQLite with WAL mode and strict relational integrity.
"""

import json
import os
import time
import uuid
from typing import Generator
from sqlalchemy import (
    create_engine, Column, String, Integer, Float, Boolean, Text, ForeignKey,
    Index, UniqueConstraint, event
)
from sqlalchemy.orm import declarative_base, sessionmaker, relationship, Session

DB_PATH = os.environ.get("OGK_DB_PATH", os.path.abspath("ogk_server.sqlite3"))
DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

# Enable WAL mode and foreign keys for SQLite
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class UserModel(Base):
    """Parent or Admin user account."""
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(32), default="parent", nullable=False)  # parent, child-view, admin
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(Float, nullable=True)
    created_at = Column(Float, default=time.time)

    children = relationship("ChildModel", back_populates="parent", cascade="all, delete-orphan")
    sessions = relationship("SessionModel", back_populates="user", cascade="all, delete-orphan")


class SessionModel(Base):
    """Parent session storage for 12-hour session management."""
    __tablename__ = "sessions"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    expires_at = Column(Float, nullable=False)
    created_at = Column(Float, default=time.time)

    user = relationship("UserModel", back_populates="sessions")


class ChildModel(Base):
    """Child profile managed by a parent."""
    __tablename__ = "children"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    parent_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(128), nullable=False)
    age = Column(Integer, nullable=False, default=10)
    avatar = Column(String(64), default="default_avatar.png")
    created_at = Column(Float, default=time.time)

    parent = relationship("UserModel", back_populates="children")
    devices = relationship("DeviceModel", back_populates="child", cascade="all, delete-orphan")
    policy = relationship("PolicyModel", back_populates="child", uselist=False, cascade="all, delete-orphan")
    events = relationship("EventModel", back_populates="child", cascade="all, delete-orphan")
    requests = relationship("ChildRequestModel", back_populates="child", cascade="all, delete-orphan")


class DeviceModel(Base):
    """Child's device enrolled into OGK."""
    __tablename__ = "devices"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    child_id = Column(String(36), ForeignKey("children.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(128), nullable=False, default="Máy tính của con")
    hostname = Column(String(128), nullable=False, default="DESKTOP-CHILD")
    os_version = Column(String(128), default="Windows 11 x64")
    device_fingerprint = Column(String(128), nullable=False)
    secret_key = Column(String(128), nullable=False)  # 256-bit hex for HMAC & token auth
    access_token = Column(String(128), nullable=True)
    access_token_expires_at = Column(Float, nullable=True)
    refresh_token = Column(String(128), nullable=True)
    is_revoked = Column(Boolean, default=False)
    last_heartbeat = Column(Float, nullable=True)
    status = Column(String(32), default="offline")
    created_at = Column(Float, default=time.time)

    child = relationship("ChildModel", back_populates="devices")
    events = relationship("EventModel", back_populates="device", cascade="all, delete-orphan")
    commands = relationship("UrgentCommandModel", back_populates="device", cascade="all, delete-orphan")


class EnrollmentCodeModel(Base):
    """8-character enrollment code valid for 10 minutes."""
    __tablename__ = "enrollment_codes"

    code = Column(String(8), primary_key=True)
    child_id = Column(String(36), ForeignKey("children.id", ondelete="CASCADE"), nullable=False)
    expires_at = Column(Float, nullable=False)
    is_used = Column(Boolean, default=False)
    created_at = Column(Float, default=time.time)


class PolicyModel(Base):
    """Active policy configuration per child."""
    __tablename__ = "policies"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    child_id = Column(String(36), ForeignKey("children.id", ondelete="CASCADE"), unique=True, nullable=False)
    version = Column(Integer, default=1, nullable=False)
    daily_quota_minutes_weekday = Column(Integer, default=90)
    daily_quota_minutes_weekend = Column(Integer, default=120)
    schedule_matrix_json = Column(Text, nullable=False)  # 7x48 matrix
    blocked_categories_json = Column(Text, nullable=False)
    allowed_categories_json = Column(Text, nullable=False)
    app_rules_json = Column(Text, nullable=False)
    domain_rules_json = Column(Text, nullable=False)
    app_group_budgets_json = Column(Text, nullable=False)
    safesearch_enforced = Column(Boolean, default=True)
    offline_expiry_days = Column(Integer, default=7)
    fail_open_after_expiry = Column(Boolean, default=False)
    updated_at = Column(Float, default=time.time)

    child = relationship("ChildModel", back_populates="policy")


class EventModel(Base):
    """Activity event strictly matching F3 specification:
    ts, device_id, child_id, type, subject, duration_sec, policy_id.
    """
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ts = Column(Float, nullable=False, index=True)
    device_id = Column(String(36), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, index=True)
    child_id = Column(String(36), ForeignKey("children.id", ondelete="CASCADE"), nullable=False, index=True)
    type = Column(String(32), nullable=False, index=True)
    subject = Column(String(255), nullable=False, index=True)  # Process name or domain
    duration_sec = Column(Integer, default=0)
    policy_id = Column(String(36), nullable=False)
    idempotency_key = Column(String(64), unique=True, nullable=True, index=True)

    child = relationship("ChildModel", back_populates="events")
    device = relationship("DeviceModel", back_populates="events")


class ChildRequestModel(Base):
    """Child requests: 'Xin thêm giờ' or 'Báo chặn nhầm'."""
    __tablename__ = "child_requests"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    child_id = Column(String(36), ForeignKey("children.id", ondelete="CASCADE"), nullable=False, index=True)
    device_id = Column(String(36), nullable=False)
    request_type = Column(String(32), nullable=False)  # extra_time, false_positive
    subject = Column(String(255), nullable=False)
    reason = Column(Text, nullable=False)
    status = Column(String(32), default="pending", index=True)  # pending, approved, rejected
    parent_response = Column(Text, nullable=True)
    created_at = Column(Float, default=time.time)
    updated_at = Column(Float, nullable=True)

    child = relationship("ChildModel", back_populates="requests")


class AuditLogModel(Base):
    """Audit log of all parent modifications. Viewable by child (NT5)."""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    child_id = Column(String(36), nullable=True, index=True)
    operator = Column(String(255), nullable=False)
    client_ip = Column(String(64), nullable=False)
    action = Column(String(128), nullable=False)
    target = Column(String(255), nullable=False)
    old_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    timestamp = Column(Float, default=time.time, index=True)


class UrgentCommandModel(Base):
    """Urgent command queue for agents (WebSocket and fallback heartbeat)."""
    __tablename__ = "urgent_commands"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    device_id = Column(String(36), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(64), nullable=False)
    payload_json = Column(Text, default="{}")
    is_executed = Column(Boolean, default=False)
    created_at = Column(Float, default=time.time)

    device = relationship("DeviceModel", back_populates="commands")


def init_db():
    """Create all tables in SQLite database."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Generator[Session, None, None]:
    """Dependency for obtaining a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
