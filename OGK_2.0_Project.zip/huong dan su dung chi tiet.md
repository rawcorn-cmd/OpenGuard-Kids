# HƯỚNG DẪN SỬ DỤNG CHI TIẾT HỆ THỐNG OGK 2.0
## (Open Guardian for Kids — Ứng Dụng Hỗ Trợ Quản Lý Máy Tính Trẻ Em Minh Bạch)

> **Triết lý cốt lõi:** *"Công cụ đồng hành, không phải phần mềm theo dõi lén"*  
> **Tuân thủ pháp lý:** Nghị định số 13/2023/NĐ-CP về Bảo vệ dữ liệu cá nhân & Luật Trẻ em 2016  
> **Tiêu chuẩn thiết kế:** 6 Nguyên tắc minh bạch NT1 – NT6  

---

## MỤC LỤC
1. [Giới Thiệu Tổng Quan](#1-giới-thiệu-tổng-quan)
2. [Yêu Cầu Hệ Thống & Chuẩn Bị Môi Trường](#2-yêu-cầu-hệ-thống--chuẩn-bị-môi-trường)
3. [Hướng Dẫn Cài Đặt Từ Đầu](#3-hướng-dẫn-cài-đặt-từ-đầu)
4. [Hướng Dẫn Khởi Chạy Hệ Thống](#4-hướng-dẫn-khởi-chạy-hệ-thống)
   - [4.1. Khởi chạy Máy chủ Quản lý (OGK-Server)](#41-khởi-chạy-máy-chủ-quản-lý-ogk-server)
   - [4.2. Khởi chạy Ứng dụng Agent trên Máy Con (OGK-Agent)](#42-khởi-chạy-ứng-dụng-agent-trên-máy-con-ogk-agent)
5. [Hướng Dẫn Chi Tiết Các Tính Năng Dành Cho Phụ Huynh (Parent Dashboard)](#5-hướng-dẫn-chi-tiết-các-tính-năng-dành-cho-phụ-huynh-parent-dashboard)
   - [5.1. Bảng điều khiển giám sát trực tiếp (Live Telemetry)](#51-bảng-điều-khiển-giám-sát-trực-tiếp-live-telemetry)
   - [5.2. Các nút lệnh khẩn cấp tức thì (< 5 giây)](#52-các-nút-lệnh-khẩn-cấp-tức-thì--5-giây)
   - [5.3. Xử lý yêu cầu xin thêm giờ & Báo chặn nhầm (NT3)](#53-xử-lý-yêu-cầu-xin-thêm-giờ--báo-chặn-nhầm-nt3)
   - [5.4. Cấu hình hạn mức và Ma trận lịch tuần 7×48](#54-cấu-hình-hạn-mức-và-ma-trận-lịch-tuần-748)
   - [5.5. Quản lý quy tắc chặn ứng dụng (Tên + SHA-256)](#55-quản-lý-quy-tắc-chặn-ứng-dụng-tên--sha-256)
   - [5.6. Quản lý bộ lọc tên miền (DNS Filter Proxy)](#56-quản-lý-bộ-lọc-tên-miền-dns-filter-proxy)
   - [5.7. Ghép đôi thiết bị mới bằng mã 8 ký tự (Enrollment)](#57-ghép-đôi-thiết-bị-mới-bằng-mã-8-ký-tự-enrollment)
   - [5.8. Báo cáo, Biểu đồ và Quyền được lãng quên (F3)](#58-báo-cáo-biểu-đồ-và-quyền-được-lãng-quên-f3)
6. [Hướng Dẫn Chi Tiết Giao Diện Dành Cho Con (Child Agent & Tray UI)](#6-hướng-dẫn-chi-tiết-giao-diện-dành-cho-con-child-agent--tray-ui)
   - [6.1. Biểu tượng khay hệ thống (System Tray)](#61-biểu-tượng-khay-hệ-thống-system-tray)
   - [6.2. Các cửa sổ thông báo native theo ngữ cảnh](#62-các-cửa-sổ-thông-báo-native-theo-ngữ-cảnh)
   - [6.3. Gửi yêu cầu xin thêm giờ hoặc báo chặn nhầm](#63-gửi-yêu-cầu-xin-thêm-giờ-hoặc-báo-chặn-nhầm)
   - [6.4. Màn hình minh bạch hai chiều "Hôm nay em đã dùng gì" (NT5)](#64-màn-hình-minh-bạch-hai-chiều-hôm-nay-em-đã-dùng-gì-nt5)
7. [Kịch Bản Kiểm Thử Thực Tế (Testing Scenarios)](#7-kịch-bản-kiểm-thử-thực-tế-testing-scenarios)
8. [Bộ Kiểm Thử Tự Động (Automated Test Suite)](#8-bộ-kiểm-thử-tự-động-automated-test-suite)
9. [Xử Lý Sự Cố Thường Gặp (Troubleshooting / FAQ)](#9-xử-lý-sự-cố-thường-gặp-troubleshooting--faq)

---

## 1. GIỚI THIỆU TỔNG QUAN

**OGK 2.0 (Open Guardian for Kids)** là giải pháp toàn diện hỗ trợ các bậc cha mẹ quản lý và đồng hành cùng con trẻ khi sử dụng máy tính Windows. Khác với các phần mềm giám sát bí mật (spyware/stalkerware), OGK 2.0 được xây dựng dựa trên sự tôn trọng, minh bạch và tuân thủ tuyệt đối quy định pháp luật:

* **NT1 — Trẻ luôn biết mình được hỗ trợ:** Luôn có biểu tượng khay hệ thống; Agent sẽ tự động tắt nếu bị ép chạy ẩn.
* **NT2 — Tối thiểu hóa dữ liệu thu thập:** Chỉ lưu thời lượng sử dụng và tên tiến trình/tên miền. **Tuyệt đối không lưu URL chi tiết, không chụp ảnh màn hình, không đọc tin nhắn, không keylogger.**
* **NT3 — Trẻ có tiếng nói:** Trẻ có thể bấm nút xin thêm giờ học hoặc báo cho cha mẹ khi một website/ứng dụng bị chặn nhầm.
* **NT4 — Hành động phải giải thích được:** Khi một trang web hay ứng dụng bị khóa, màn hình sẽ hiển thị lý do rõ ràng và tên cha mẹ đã đặt luật đó.
* **NT5 — Minh bạch hai chiều:** Trẻ có một trang web riêng (*"Hôm nay em đã dùng gì"*) và được quyền xem Nhật ký kiểm toán (Audit Log) về mọi thay đổi luật của cha mẹ.
* **NT6 — An toàn tuyệt đối:** Miễn chặn vĩnh viễn Tổng đài quốc gia bảo vệ trẻ em **111** (`tongdai111.vn`), các dịch vụ khẩn cấp 113/114/115 và toàn bộ tên miền giáo dục `.edu.vn`.

### Kiến Trúc Hệ Thống:
* **OGK-Server:** Máy chủ web FastAPI phục vụ Dashboard quản lý phụ huynh trên máy tính và điện thoại di động (Responsive 100%), lưu trữ cơ sở dữ liệu SQLite chế độ WAL, đẩy lệnh khẩn cấp qua WebSocket (< 5 giây).
* **OGK-Agent:** Dịch vụ chạy ngầm trên máy con (Service + System Tray), thực thi đếm giờ màn hình thực tế (dừng đếm khi máy nghỉ/không chạm chuột), lọc tên miền qua DNS Proxy cục bộ, chặn ứng dụng theo tên và mã băm SHA-256.

---

## 2. YÊU CẦU HỆ THỐNG & CHUẨN BỊ MÔI TRƯỜNG

* **Hệ điều hành:** Windows 10 hoặc Windows 11 (phiên bản 64-bit).
* **Python:** Phiên bản 3.11 trở lên (Khuyến nghị Python 3.11 hoặc 3.12).
* **Quyền Administrator (Quản trị viên):** Cần thiết khi thực hiện chuyển hướng DNS của Card mạng Windows sang `127.0.0.1` hoặc cài đặt chính sách hệ thống.
* **Mạng nội bộ:** Máy tính con và thiết bị của phụ huynh (điện thoại/máy tính) kết nối chung một mạng Wi-Fi hoặc có thể kết nối IP đến máy chủ.

---

## 3. HƯỚNG DẪN CÀI ĐẶT TỪ ĐẦU

### Bước 1: Giải nén mã nguồn dự án
Giải nén file `OGK_2.0_Project.zip` vào một thư mục trên máy (ví dụ: `D:\Projects\OGK2.0`).

### Bước 2: Mở Terminal PowerShell và tạo môi trường ảo
Mở PowerShell (Run as Administrator khuyến nghị để sẵn sàng cấp quyền DNS) và chuyển vào thư mục:
```powershell
cd D:\Projects\OGK2.0
```

Nếu chưa có môi trường ảo `.venv`, tạo và kích hoạt:
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```
*(Nếu gặp lỗi PowerShell chặn script, chạy lệnh: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` rồi kích hoạt lại).*

### Bước 3: Cài đặt các thư viện phụ thuộc
```powershell
pip install -r requirements.txt
```

### Bước 4: Khởi tạo cơ sở dữ liệu mẫu ban đầu
Chạy script nạp tài khoản phụ huynh, hồ sơ trẻ em và bộ dữ liệu 209 tên miền mẫu:
```powershell
python scripts/seed_database.py
```
Sau khi hoàn tất, hệ thống sẽ cấp sẵn thông tin:
* **Tài khoản Phụ Huynh mặc định:** `parent@ogk.local`
* **Mật khẩu Phụ Huynh:** `ParentPass1234!`
* **Hồ sơ con mẫu:** Bé Nam (9 tuổi), Bé Mai (12 tuổi)
* **Thiết bị đã liên kết sẵn:** `Máy tính học tập của Nam`

---

## 4. HƯỚNG DẪN KHỞI CHẠY HỆ THỐNG

Để trải nghiệm toàn bộ hệ thống hoạt động thực tế, bạn sẽ mở **2 hoặc 3 cửa sổ terminal**:

### 4.1. Khởi chạy Máy chủ Quản lý (OGK-Server)
Tại terminal 1:
```powershell
python scripts/run_server.py
```
Terminal sẽ hiển thị:
```text
============================================================
  OGK 2.0 - HỆ THỐNG QUẢN LÝ MÁY TÍNH TRẺ EM MINH BẠCH
============================================================
[+] Server đang hoạt động trên cổng: 8000
[+] Truy cập Dashboard trên máy tính:
    👉 http://127.0.0.1:8000
    👉 http://localhost:8000
[+] Truy cập Dashboard trên ĐIỆN THOẠI (cùng mạng WiFi):
    👉 http://192.168.1.x:8000
```

* Mở trình duyệt Web (Chrome, Edge, Firefox, Cốc Cốc, Safari trên điện thoại...) truy cập vào: **`http://127.0.0.1:8000`** (hoặc IP mạng LAN trên điện thoại).
* Đăng nhập bằng tài khoản: `parent@ogk.local` / `ParentPass1234!`.

---

### 4.2. Khởi chạy Ứng dụng Agent trên Máy Con (OGK-Agent)
Tại terminal 2 (Khuyến nghị **Run as Administrator** để tự động gán DNS Card mạng):
```powershell
python scripts/run_agent.py
```
Agent sẽ lập tức khởi chạy:
1. Nạp cấu hình bảo vệ đã ký số HMAC.
2. Khởi động **DNS Proxy cục bộ** tại `127.0.0.1:53` (tự động chuyển DNS của Card mạng Windows về `127.0.0.1` và cấu hình chính sách tắt DoH trình duyệt).
3. Kết nối WebSocket thời gian thực tới Server (`/ws/agent/{device_id}`).
4. Bắt đầu bộ đếm giờ màn hình và kiểm soát tiến trình ứng dụng.

Tại terminal 3 (Chạy Khay hệ thống cho trẻ):
```powershell
python scripts/run_tray.py
```
Biểu tượng tấm khiên xanh lá **🛡️ OGK 2.0** sẽ xuất hiện ở góc phải thanh Taskbar của Windows. Đồng thời một thông báo chào mừng thân thiện sẽ hiển thị cho trẻ biết phần mềm bảo vệ đang đồng hành.

---

## 5. HƯỚNG DẪN CHI TIẾT CÁC TÍNH NĂNG DÀNH CHO PHỤ HUYNH (PARENT DASHBOARD)

Giao diện Bảng điều khiển phụ huynh được thiết kế **hoàn toàn tự động co giãn (Responsive)**, hỗ trợ tối ưu trên mọi màn hình máy tính và điện thoại di động:

### 5.1. Bảng điều khiển giám sát trực tiếp (Live Telemetry)
* **🖥️ Kết nối Thiết bị:** Chấm xanh nhấp nháy hiển thị `Trực tuyến (Live)` khi con đang dùng máy, hoặc `Trực tuyến (Đang nghỉ)` kèm tên máy tính của con.
* **⏳ Thời gian màn hình hôm nay:** Hiển thị số phút/giờ còn lại của con trong ngày và thanh tiến trình phần trăm đã dùng trực quan.
* **💻 Ứng dụng tiền cảnh (Foreground):** Hiển thị chính xác tên phần mềm con đang mở ngay trước mắt (vd: `chrome.exe`, `roblox.exe`, `notepad.exe`) kèm tiêu đề cửa sổ, không bao giờ bị cắt mất chữ.
* **🖱️ Trạng thái chuột & bàn phím (Idle Detection):**
  * Khi con đang gõ phím hoặc di chuột: Hiển thị badge xanh `🟢 Đang hoạt động`.
  * Khi con đứng dậy đi chơi hoặc không chạm máy tính quá 10 giây: Hiển thị badge vàng `⏸️ ĐÃ TẠM DỪNG`, đồng hồ đếm giờ sẽ lập tức **ngừng trừ giờ** của con.
* **🌐 Giám sát Truy cập Web Trực tiếp:** Cập nhật liên tục mỗi 2 giây nhật ký tên miền con vừa truy cập kèm trạng thái `✅ CHO PHÉP`, `🚫 ĐÃ CHẶN` hoặc `🔍 SAFESEARCH`.

---

### 5.2. Các nút lệnh khẩn cấp tức thì (< 5 giây qua WebSocket)
Nhóm 4 nút lệnh nằm ở góc trái bảng điều khiển:
* **🔒 Khóa máy ngay:** Lập tức phát lệnh khóa máy con sau dưới 1 giây qua WebSocket, màn hình máy con sẽ chuyển sang trạng thái khóa Windows (`LockWorkStation`).
* **🔓 Mở khóa máy (+15p):** Mở khóa máy tính cho con và tự động cộng thêm 15 phút sử dụng.
* **⏱️ Cho thêm 15p / ⏱️ Cho thêm 30p:** Lập tức gia hạn thêm thời gian sử dụng vào hạn mức trong ngày của con.
* **🏆 Thưởng giờ khi con làm việc tốt:** Mở hộp thoại chọn nhiệm vụ (vd: *Làm xong bài tập về nhà*, *Dọn phòng sạch sẽ*) và cộng thưởng từ 15 đến 60 phút. Máy con sẽ nhận được thông báo chúc mừng màu xanh lá tuyệt đẹp: *"✨ Cha mẹ đã thưởng thêm giờ!"*.

---

### 5.3. Xử lý yêu cầu xin thêm giờ & Báo chặn nhầm (NT3)
* Khi con bấm nút từ khay hệ thống, yêu cầu sẽ lập tức xuất hiện trong mục **"📬 Yêu cầu từ con"** trên Dashboard.
* Phụ huynh có 2 nút lựa chọn:
  * **✓ Duyệt mở khóa / Duyệt thêm giờ:** Phụ huynh nhập lời nhắn yêu thương gửi con. Hệ thống sẽ **tự động thêm tên miền/ứng dụng đó vào danh sách Cho phép (Whitelist) và gửi lệnh mở khóa tức thì xuống máy con** mà không cần phụ huynh phải thao tác thủ công thêm bất kỳ bước nào!
  * **✕ Từ chối:** Nhập lý do giải thích minh bạch để gửi về máy con.

---

### 5.4. Cấu hình hạn mức và Ma trận lịch tuần 7×48
* **Hạn mức ngày thường & cuối tuần:** Nhập số phút tối đa con được dùng mỗi ngày (mặc định: 90 phút ngày thường, 120 phút cuối tuần).
* **Ngân sách ứng dụng độc lập:** Giới hạn riêng cho từng nhóm (vd: Trò chơi tối đa 45 phút/ngày, Học tập không giới hạn).
* **Ma trận lịch tuần 7×48 (Độ phân giải 30 phút):**
  * Bảng gồm 7 ngày (Thứ 2 đến Chủ nhật) và 48 ô nửa tiếng (từ 00h đến 24h).
  * **Màu xanh lá:** Khung giờ con được phép dùng máy.
  * **Màu xám:** Khung giờ khóa máy (ngoài giờ học tập/giờ ngủ).
  * Bạn có thể kéo thả chuột trực tiếp trên bảng để bật/tắt từng khung giờ, hoặc dùng 2 nút bấm nhanh: **"Mở toàn bộ 24h"** hoặc **"Mặc định học sinh (07h-21h)"**.
  * *Trên điện thoại di động: Cột tên thứ ngày được giữ cố định bên trái khi cuộn ngang, giúp bạn dễ dàng thao tác.*

---

### 5.5. Quản lý quy tắc chặn ứng dụng (Tên + SHA-256)
* Bấm **"+ Thêm ứng dụng"**:
  * Nhập tên file thực thi (vd: `roblox.exe`, `discord.exe`, `tiktok.exe`...) hoặc chọn từ danh sách gợi ý thông minh.
  * Đặt tên thân thiện và lý do giải thích minh bạch cho con (NT4).
  * Chọn hành động: `🚫 Chặn hoàn toàn` hoặc `✅ Luôn cho phép`.
* **Cơ chế chống qua mặt:** Nếu trẻ thông minh tìm cách đổi tên file từ `roblox.exe` thành `notepad.exe` hay `word.exe`, hệ thống sẽ quét mã băm **SHA-256** của file thực thi và lập tức chặn đứng tiến trình.

---

### 5.6. Quản lý bộ lọc tên miền (DNS Filter Proxy)
* Bấm **"+ Thêm tên miền"**:
  * Nhập tên miền muốn kiểm soát (vd: `tiktok.com`, `facebook.com`, `game.io`...).
  * Hệ thống tự động áp dụng quy tắc cho cả tên miền chính và toàn bộ tên miền con (`*.tiktok.com`).
  * Chọn hành động:
    * `🚫 Chặn truy cập`: Chặn phân giải DNS, trả về IP `127.0.0.1`.
    * `✅ Mở khóa (Whitelist)`: Luôn cho phép truy cập.
    * `🔍 SafeSearch bắt buộc`: Tự động ép kết quả tìm kiếm sang chế độ an toàn nghiêm ngặt của Google/Bing.
* **Công cụ thử nghiệm nhanh (Diagnostic Tester):**
  * Có sẵn ô nhập tên miền để kiểm tra trước kết quả xử lý của bộ lọc mà không cần mở trình duyệt.

---

### 5.7. Ghép đôi thiết bị mới bằng mã 8 ký tự (Enrollment)
Để kết nối thêm một máy tính con mới vào tài khoản:
1. Trên Dashboard, bấm nút **"🔑 Ghép đôi máy mới"**.
2. Một mã số an toàn gồm 8 chữ cái/số (vd: `A7B9XYZ2`) sẽ xuất hiện cùng đồng hồ đếm ngược hiệu lực 10 phút.
3. Trên máy con, chạy lệnh:
   ```powershell
   python scripts/enroll_agent.py
   ```
4. Nhập mã 8 ký tự vào terminal máy con. Máy con sẽ tự động nhận diện tài khoản phụ huynh, tạo khóa bảo mật riêng và kết nối bảo vệ ngay lập tức!

---

### 5.8. Báo cáo, Biểu đồ và Quyền được lãng quên (F3)
* **Báo cáo sử dụng (`/reports`):** Xem biểu đồ cột trực quan thời lượng sử dụng 7 ngày gần nhất, số lần vi phạm bị chặn, Top 10 ứng dụng dùng nhiều nhất và Top 10 tên miền truy cập nhiều nhất.
* **Nhật ký kiểm toán (`/audit`):** Ghi nhận chi tiết mọi hành vi thay đổi luật của cha mẹ (Ai đổi, lúc nào, từ địa chỉ IP nào, giá trị cũ và mới).
* **Quyền được lãng quên (Right to be Forgotten):** Tại chân trang Dashboard có nút đỏ **"Xóa toàn bộ dữ liệu của con tôi"**. Khi phụ huynh xác nhận, toàn bộ lịch sử sử dụng, sự kiện, nhật ký của con sẽ bị xóa vĩnh viễn khỏi máy chủ đồng thời xóa sạch cache cục bộ trên máy con.

---

## 6. HƯỚNG DẪN CHI TIẾT GIAO DIỆN DÀNH CHO CON (CHILD AGENT & TRAY UI)

### 6.1. Biểu tượng khay hệ thống (System Tray)
* Biểu tượng tấm khiên xanh lá **🛡️ OGK 2.0** nằm tại thanh Taskbar Windows.
* Rê chuột vào biểu tượng khay: Hiển thị tooltip thời gian thực:
  * Thời gian còn lại hôm nay (vd: `Còn lại: 68 phút`).
  * Trạng thái hoạt động: `Đang đếm giờ` hoặc `Tạm dừng (máy nghỉ)`.
* Nhấp chuột phải vào biểu tượng khay: Mở menu chức năng:
  * ⏱️ Xin thêm giờ sử dụng (+15 phút)
  * ⏱️ Xin thêm giờ sử dụng (+30 phút)
  * 🌐 Con nghĩ trang này bị chặn nhầm
  * 👀 Xem hôm nay em đã dùng gì (Minh bạch)
  * 📞 Trợ giúp khẩn cấp: Tổng đài 111

---

### 6.2. Các cửa sổ thông báo Native theo ngữ cảnh
Mọi thông báo gửi tới trẻ đều là **cửa sổ Windows Tkinter Native hiện đại**, được thiết kế thân thiện, màu sắc phân định rõ ràng theo từng tình huống:
1. **🎉 Tin Vui Từ Cha Mẹ (Thẻ Xanh Lá):** Xuất hiện khi cha mẹ duyệt yêu cầu xin giờ hoặc tặng thưởng giờ.
2. **⏳ Nhắc Nhở Thời Gian (Thẻ Vàng Hổ Phách):** Xuất hiện khi thời gian còn lại 10 phút, 5 phút hoặc 1 phút để trẻ chủ động lưu bài học.
3. **🔒 Hết Giờ Sử Dụng (Thẻ Xám Đậm):** Xuất hiện khi hết hạn mức ngày hoặc vào khung giờ khóa ma trận. Có 60 giây ân hạn để trẻ lưu bài tập trước khi khóa máy.
4. **🌐 Trang Web Bị Hạn Chế (Thẻ Đỏ):** Xuất hiện khi trẻ vào web bị chặn. Nêu rõ tên trang web, lý do cha mẹ chặn và có sẵn nút bấm *"Con nghĩ trang này bị chặn nhầm"*.
5. **🚫 Ứng Dụng Bị Hạn Chế (Thẻ Đỏ):** Xuất hiện khi mở game hoặc ứng dụng bị khóa.

---

### 6.3. Gửi yêu cầu xin thêm giờ hoặc báo chặn nhầm
* Khi bị chặn, trẻ chỉ cần bấm trực tiếp vào nút **"Con nghĩ trang này bị chặn nhầm"** trên popup.
* Một hộp thoại nhỏ hiện lên để trẻ gõ lời nhắn gửi cha mẹ (ví dụ: *"Trang này là bài tập tiếng Anh cô giáo giao, con xin bố mẹ mở giúp con ạ"*).
* Bấm **Gửi yêu cầu** -> Yêu cầu lập tức xuất hiện trên điện thoại của cha mẹ!

---

### 6.4. Màn hình minh bạch hai chiều "Hôm nay em đã dùng gì" (NT5)
* Trẻ bấm vào mục **"Xem hôm nay em đã dùng gì"** trên khay hệ thống hoặc truy cập trình duyệt tại: `http://127.0.0.1:8000/child/{child_id}`.
* Trẻ được xem toàn bộ dữ liệu mà cha mẹ thấy:
  * Đồng hồ thời gian đã dùng và thời gian còn lại.
  * Danh sách các ứng dụng em đã mở hôm nay.
  * Danh sách các trang web bị chặn kèm giải thích lý do.
  * Toàn bộ Nhật ký kiểm toán cha mẹ đã đổi luật gì gần đây.
  * Nút gọi khẩn cấp miễn cước đến **Tổng đài 111** (`tongdai111.vn`).

---

## 7. KỊCH BẢN KIỂM THỬ THỰC TẾ (TESTING SCENARIOS)

Để kiểm chứng toàn diện các tiêu chí đánh giá của đồ án, bạn có thể lần lượt thực hiện các kịch bản sau:

### Kịch bản 1: Kiểm thử Chặn Tên Miền Thực Tế trên Trình Duyệt Web
1. Đảm bảo Agent đang chạy (`python scripts/run_agent.py`).
2. Trên Dashboard phụ huynh, thêm tên miền `tiktok.com` vào danh sách chặn (hoặc kiểm tra các tên miền có sẵn trong `test_dataset.json`).
3. Mở trình duyệt Chrome/Edge trên máy tính và truy cập `tiktok.com`:
   * Trang web sẽ bị chặn kết nối ngay lập tức.
   * Trên Dashboard phụ huynh (mục Live DNS Stream), tên miền `tiktok.com` hiện lên ngay với badge đỏ `🚫 ĐÃ CHẶN`.
   * Trên máy con, một cửa sổ popup màu đỏ xuất hiện giải thích rõ: *"Trang web bị chặn theo quy định bảo vệ gia đình"*.

### Kịch bản 2: Kiểm thử Chặn Ứng Dụng Đổi Tên (Chống Vượt Rào bằng SHA-256)
1. Thêm quy tắc chặn `notepad.exe` trên Dashboard.
2. Mở ứng dụng Notepad: Phần mềm sẽ bị đóng ngay lập tức kèm hộp thoại giải thích.
3. Thử copy file `notepad.exe` ra Desktop và đổi tên thành `game_hoc_tap.exe` rồi mở lên:
   * Hệ thống sẽ tính toán mã băm SHA-256 của file thực thi, nhận diện đây chính là ứng dụng bị hạn chế và lập tức tắt tiến trình.

### Kịch bản 3: Kiểm thử Quy Trình Báo Chặn Nhầm và Mở Khóa Tức Thì
1. Khi máy con bị chặn một trang web, trên popup bấm **"🌐 Con nghĩ trang này bị chặn nhầm"**.
2. Nhập nội dung: *"Con cần tra từ điển học bài"*, bấm Gửi.
3. Trên điện thoại/máy tính phụ huynh, mục **"Yêu cầu từ con"** lập tức nhảy số thông báo.
4. Phụ huynh bấm **"✓ Duyệt mở khóa"**:
   * Hệ thống tự động thêm tên miền vào danh sách Cho phép và gửi lệnh `refresh_policy` qua WebSocket.
   * Ngay lập tức trên máy con, một thông báo màu xanh lá chúc mừng hiện lên: *"🎉 Tin Vui Từ Cha Mẹ: Cha mẹ đã phê duyệt yêu cầu của con!"*.
   * Trẻ tải lại trang web trên trình duyệt và vào học bình thường!

### Kịch bản 4: Kiểm thử Dừng Đếm Giờ Khi Không Dùng Máy (Idle Detection)
1. Nhìn vào thẻ thời gian màn hình trên Dashboard hoặc rê chuột vào khay hệ thống.
2. Buông chuột và bàn phím, không chạm vào máy tính trong 10 giây.
3. Dashboard sẽ chuyển trạng thái sang `⏸️ ĐÃ TẠM DỪNG (Không chạm chuột/phím > 10s: Đồng hồ đếm giờ đã tạm dừng!)`.
4. Khi chạm nhẹ vào chuột, hệ thống ngay lập tức chuyển lại `🟢 Đang hoạt động` và tiếp tục đếm giờ bình thường.
*(Có thể chạy riêng script minh họa: `python scripts/test_idle_detection.py`)*.

### Kịch bản 5: Kiểm thử Lệnh Khẩn Cấp Dưới 5 Giây
1. Trên Dashboard, bấm nút đỏ **"🔒 Khóa máy ngay"**.
2. Quan sát máy tính của con: Màn hình Windows lập tức bị khóa (`LockWorkStation`) sau chưa đầy 1 giây.
3. Trên Dashboard, bấm **"🔓 Mở khóa (+15p)"**: Máy con lập tức nhận lệnh mở khóa và cộng thêm 15 phút.

---

## 8. BỘ KIỂM THỬ TỰ ĐỘNG (AUTOMATED TEST SUITE)

Hệ thống đi kèm bộ kiểm thử tự động toàn diện bao phủ 100% các yêu cầu kỹ thuật:

### 1. Chạy toàn bộ 25 bài kiểm thử đơn vị & tích hợp:
```powershell
python run_tests.py
```
*Thời gian chạy: ~6.5 giây. Kết quả: **25/25 Tests PASSED (100%)**.*

### 2. Chạy kịch bản Demo Nghiệm thu Tự động (6 Giai đoạn):
```powershell
python demo_quickstart.py
```
Script sẽ tự động kiểm chứng:
* [1/6] Nạp dữ liệu và kiểm tra toàn vẹn tài khoản.
* [2/6] Quota 3 phút, lùi đồng hồ 3 giờ không bị qua mặt, cảnh báo ân hạn 60s.
* [3/6] 0 dương tính giả trên 20 miền giáo dục, chặn 100% trên 50 miền mẫu, cưỡng chế SafeSearch, miễn chặn 111 vĩnh viễn, nhận diện file đổi tên bằng SHA-256.
* [4/6] Ghép đôi mã 8 ký tự, chữ ký số HMAC-SHA256, băm mật khẩu Argon2id.
* [5/6] Khởi động các tiến trình dịch vụ.
* [6/6] Báo cáo nghiệm thu hoàn tất.

### 3. Dừng toàn bộ các dịch vụ OGK đang chạy:
Khi muốn tắt sạch toàn bộ các tiến trình máy chủ, Agent, DNS Proxy và khay hệ thống, chạy lệnh:
```powershell
python scripts/stop_all.py
```

---

## 9. XỬ LÝ SỰ CỐ THƯỜNG GẶP (TROUBLESHOOTING / FAQ)

### 1. Trình duyệt Chrome hoặc Edge không chặn được tên miền do tính năng Secure DNS (DoH)?
* **Nguyên nhân:** Các trình duyệt hiện đại tự kích hoạt DoH (DNS over HTTPS), gửi truy vấn mã hóa thẳng lên máy chủ của Google/Cloudflare thay vì hỏi card mạng Windows.
* **Cách khắc phục:**
  1. Khi chạy `python scripts/run_agent.py` dưới quyền Administrator, Agent đã tự động cấu hình Registry tắt DoH của Chrome và Edge (`DnsOverHttpsMode = "off"`).
  2. Nếu chạy không có quyền Admin, phụ huynh có thể tự tắt bằng tay:
     * **Chrome:** Vào `chrome://settings/security` -> Tắt mục *"Sử dụng hệ thống tên miền (DNS) an toàn"*.
     * **Edge:** Vào `edge://settings/privacy` -> Tắt mục *"Dùng DNS an toàn"*.

### 2. Card mạng bị mất mạng sau khi tắt đột ngột Agent?
* **Cách khắc phục:** Chạy script khôi phục DNS tự động (DHCP):
  ```powershell
  python scripts/configure_dns.py disable
  ```
  Lệnh này sẽ chuyển toàn bộ card mạng Windows về chế độ nhận DNS tự động từ router Wi-Fi gia đình và flush DNS sạch sẽ.

### 3. Máy con bị khóa ngay khi vừa bật Agent?
* **Nguyên nhân:** Khung giờ hiện tại rơi vào ô màu xám (ngoài giờ cho phép) trong Ma trận lịch tuần 7×48 hoặc hạn mức hôm nay đã dùng hết.
* **Cách khắc phục:**
  1. Mở Dashboard phụ huynh tại `http://127.0.0.1:8000`.
  2. Bấm nút **"🔓 Mở khóa (+15p)"** hoặc bấm **"Mở toàn bộ 24h"** trong bảng ma trận lịch tuần rồi bấm Lưu chính sách.
  3. Máy con sẽ tự động đồng bộ và mở khóa ngay lập tức.

### 4. Quên mật khẩu đăng nhập phụ huynh?
* **Cách khắc phục:** Chạy lại lệnh nạp cơ sở dữ liệu để reset mật khẩu về mặc định:
  ```powershell
  python scripts/seed_database.py
  ```
  Tài khoản sẽ là: `parent@ogk.local` / `ParentPass1234!`.

---

**OGK 2.0 — Giải pháp công nghệ nhân văn, đồng hành an toàn và minh bạch cùng thế hệ trẻ Việt Nam!**
